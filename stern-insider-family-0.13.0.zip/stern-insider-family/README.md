# Family Pinball: Stern Insider dashboard for Home Assistant

Shows Insider Connected games, quests, real Stern badges, milestone progress, per-game achievements and machine high scores for each signed-in family member.

This is an unofficial community project and is not made or supported by Stern Pinball.

## Files
| File | Copy to |
|---|---|
| `custom_components/stern_insider_family/` (whole folder) | `/config/custom_components/stern_insider_family/` |
| `custom_templates/stern_family.jinja` | `/config/custom_templates/stern_family.jinja` |
| `packages/stern_family.yaml` | `/config/packages/stern_family.yaml` |
| `dashboards/stern_family_dashboard.yaml` | Paste into the dashboard's raw configuration editor |

## Setup
1. Copy the files above.
2. If you haven't already, add this to `configuration.yaml`:
   ```yaml
   homeassistant:
     packages: !include_dir_named packages
   ```
3. Restart Home Assistant.
4. Go to **Settings → Devices & services → Add integration → Stern Insider Family**.
5. Enter the person's name and open the **Stern sign-in** link. Use a private window if someone else is already signed in to Stern.
6. After signing in you land on a dark page with a spinner. That is expected. Right away, copy the full address and paste it into Home Assistant. It expires within minutes.
7. Repeat steps 4–6 for each family member.
8. Create a dashboard and paste in `stern_family_dashboard.yaml`: **Settings → Dashboards → Add dashboard → New dashboard from scratch**, then ⋮ → Edit → ⋮ → Raw configuration editor.

The main page is one `custom:stern-home-card`. It includes Keep playing suggestions, game filters, a **Refresh** button and a View menu. The **Quests** tab lists every current and upcoming quest Stern lists, grouped by round, with who has earned each one and Stern's help guide. Ended quests are hidden. It shows every current and upcoming quest group Stern lists, including monthly game quests, tours and events, and every published Insider Connected game, including games nobody in the family has played. Its **Family** and **High scores** switches are remembered in each browser. If your dashboard's URL is not `stern-insider`, change `/stern-insider/` in each page's `back_path`.

## How it behaves
- **Updates:** once a day, around 3:00 AM US Central, and whenever Home Assistant starts. Tap **Refresh** on the main page to update every account right away. New games, achievements, badges, quests and progress are picked up automatically, and open dashboard pages refresh themselves.
- **Images:** Stern's badge image links expire, so Home Assistant saves a copy of each one under `/config/.cache/stern_insider_family/badge-images/` and keeps showing it between updates.
- **Sign-in:** Home Assistant never sees a password. It stores only Stern's renewable sign-in token, and renews it at each update. If Home Assistant is off for about 4 weeks, or Stern ends the sign-in, Home Assistant asks that person to sign in again.
- **Machines:** a machine shared by several accounts is only fetched once. Archived machines are skipped.
- **Privacy:** email, location, serial numbers and machine addresses are read past and never stored.
- **Notifications:** new family high scores and new badges appear as Home Assistant notifications.

## Game achievements card
The dashboard includes `type: custom:stern-achievements-card`, which the integration installs automatically.

- Click a game to see its achievements.
- Choose **Everyone** or one person.
- Switch between **Open**, **Earned** and **All**. With **Everyone**, each achievement shows who has earned it.

Achievement details are fetched for each game a person has played. A game is fetched again at each daily update or manual refresh when its totals change or its details are more than about 11 hours old.

## All badges page
The **All badges** button opens every badge for each person, grouped into regular badges and milestone tracks. Filter by **Earned**, **Not earned** or **All**. Choose **Everyone** to see who has each badge.

## Game progress page
The **Game progress** button lists games where Stern has a progress page for a family member. Click a game to see its levels, characters, unlocks, speed runs and collections. Pages are refreshed at each update, and other played games are checked for new progress pages at each daily update.

## Backglass images
Stern publishes one backglass per game, so its edition varies. The achievements card shows that image and labels the edition. To use your own image, put it in `/config/www/stern/` and add it by game ID:

```yaml
- type: custom:stern-achievements-card
  backglasses:
    102: /local/stern/jurassic-park-le.webp
```

### Updating from an earlier version
1. Replace `/config/custom_components/stern_insider_family/` with the new folder and restart Home Assistant.
2. In the raw dashboard editor, replace the whole `Game progress` markdown card with:
   ```yaml
   - type: custom:stern-achievements-card
   ```
3. Refresh the browser. If Home Assistant says the card type is unknown, do a hard refresh.

## Entities
- **Each person:** Insider profile (`connected` or `partial`), Stern XP, Plays, Days played, Day streak, Week streak, Achievements, Badges, Milestone badges, Game progress.
- **Each machine:** Online, Grand Champion, High Score 1–4.
- **Events:** `stern_insider_family_new_high_score`, `stern_insider_family_new_badge`.

## Limits
- Quest pages such as the Holiday Quest and the Godzilla tour are read from the content service Stern's own pages use, with the access key built into those pages. Stern can change that at any time. If it fails, those quests fall back to one tile with an **Open on Stern** link.
- This is unofficial and reads Stern's private website data. A site change can break it. If a page can't be read, the profile shows `partial` and the last good data stays.
- Badge counts may differ slightly from the number on your Stern profile, because the integration counts the badges listed on the Trophy Room page and keeps milestone badges separate.
- The machine Online status is whatever Stern reports.
