"""Stern Insider Family integration."""
from __future__ import annotations

from pathlib import Path

from homeassistant.components.frontend import add_extra_js_url
from homeassistant.components.http import StaticPathConfig
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers import config_validation as cv
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.dispatcher import async_dispatcher_send
from homeassistant.helpers.typing import ConfigType

from .api import SternClient
from .const import (
    CARD_FILE,
    CARD_URL,
    DOMAIN,
    IMAGE_URL,
    SIGNAL_UPDATED,
    VERSION,
)
from .coordinator import SternCoordinator
from .images import ImageCache
from .websocket import async_register_commands

CONFIG_SCHEMA = cv.config_entry_only_config_schema(DOMAIN)
PLATFORMS = [Platform.BINARY_SENSOR, Platform.SENSOR]
type SternConfigEntry = ConfigEntry[SternCoordinator]


async def async_setup(hass: HomeAssistant, config: ConfigType) -> bool:
    """Register the achievements card and its data commands."""
    hass.data.setdefault(DOMAIN, {"machine_owners": {}})
    images = ImageCache(hass)
    await images.async_load()
    hass.data[DOMAIN]["images"] = images
    async_register_commands(hass)
    await hass.http.async_register_static_paths(
        [
            StaticPathConfig(CARD_URL, str(Path(__file__).parent / CARD_FILE), True),
            StaticPathConfig(IMAGE_URL, str(images.directory), True),
        ]
    )
    if "frontend" in hass.config.components:
        add_extra_js_url(hass, f"{CARD_URL}?v={VERSION}")
    return True


async def async_setup_entry(hass: HomeAssistant, entry: SternConfigEntry) -> bool:
    """Set up one person's Stern account."""
    client = SternClient(async_get_clientsession(hass))
    coordinator = SternCoordinator(hass, entry, client)
    await coordinator.async_config_entry_first_refresh()
    entry.runtime_data = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(await coordinator.async_start_daily_updates())
    entry.async_on_unload(
        coordinator.async_add_listener(
            lambda: async_dispatcher_send(hass, SIGNAL_UPDATED)
        )
    )
    return True


async def async_unload_entry(hass: HomeAssistant, entry: SternConfigEntry) -> bool:
    """Unload an account and release its machines for other accounts."""
    unloaded = await hass.config_entries.async_unload_platforms(entry, PLATFORMS)
    if unloaded:
        owners = hass.data.get(DOMAIN, {}).get("machine_owners", {})
        for machine_id in [k for k, v in owners.items() if v == entry.entry_id]:
            owners.pop(machine_id)
    return unloaded
