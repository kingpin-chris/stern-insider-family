/* Stern Insider Family: clickable game achievements card. */
const DOMAIN = "stern_insider_family";

const BADGE_DIALOG_STYLE = `
button, summary, [role="button"] { touch-action: manipulation; -webkit-tap-highlight-color: transparent; }
button.badge { width: 100%; background: none; color: inherit; font: inherit; cursor: pointer; transition: transform .14s ease, border-color .14s ease, background .14s ease; }
button.badge:active { border-color: var(--primary-color); background: var(--secondary-background-color); transform: scale(.985); }
[role="button"].detail-trigger { cursor: pointer; transition: border-color .14s ease, background .14s ease; }
[role="button"].detail-trigger:active { border-color: var(--primary-color); background: var(--secondary-background-color); }
[role="button"].detail-trigger:focus-visible { outline: 2px solid var(--primary-color); outline-offset: 2px; }
.badge-facts { display: grid; grid-template-columns: 1fr auto; gap: 6px 14px; margin: 0 0 16px; padding: 12px; border-radius: 12px; background: rgba(255,255,255,.06); font-size: .9rem; }
.badge-facts span:nth-child(odd) { color: #a2adbf; text-transform: capitalize; }
.badge-facts span:nth-child(even) { text-align: right; overflow-wrap: anywhere; }
.badge-row button { padding: 0; border: 0; border-radius: 8px; background: none; cursor: pointer; }
.badge-dialog { width: min(92vw, 460px); max-height: 90vh; box-sizing: border-box; overflow: auto; padding: 24px; border: 1px solid rgba(255,255,255,.14); border-radius: 22px; background: #141923; color: #f5f7fb; box-shadow: 0 28px 80px rgba(0,0,0,.6); }
.badge-dialog::backdrop { background: rgba(4,7,12,.76); backdrop-filter: blur(5px); }
.badge-close { position: absolute; top: 12px; right: 12px; width: 44px; height: 44px; border: 0; border-radius: 50%; background: rgba(255,255,255,.1); color: inherit; font-size: 1.35rem; cursor: pointer; }
.badge-large { display: block; width: min(68vw, 300px); height: min(68vw, 300px); margin: 4px auto 16px; object-fit: contain; }
.badge-kicker { color: #7dd3fc; font-size: .74rem; font-weight: 700; letter-spacing: .1em; text-align: center; text-transform: uppercase; }
.badge-dialog h2 { margin: 5px 0 8px; font-size: 1.45rem; line-height: 1.2; text-align: center; overflow-wrap: anywhere; }
.badge-full { margin: 0 0 16px; color: #c7d0dd; line-height: 1.45; text-align: center; overflow-wrap: anywhere; }
.badge-help { margin-top: 14px; text-align: left; }
.badge-help h3 { margin: 0 0 8px; font-size: 1rem; }
.badge-help h4 { margin: 10px 0 4px; font-size: .9rem; color: #c7d0dd; }
.badge-help p { margin: 0 0 8px; color: #c7d0dd; line-height: 1.45; white-space: pre-line; }
.badge-help img { display: block; width: 100%; max-width: 360px; margin: 6px auto 0; border-radius: 10px; }
.badge-gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(58px, 1fr)); gap: 8px; margin-top: 14px; }
.badge-gallery img { width: 100%; aspect-ratio: 1; object-fit: contain; }
.badge-link { display: inline-flex; min-height: 44px; align-items: center; margin: 12px 0 4px; color: var(--primary-color); font-weight: 650; }
.badge-owner { display: flex; justify-content: space-between; gap: 12px; padding: 10px 0; border-top: 1px solid rgba(255,255,255,.11); }
.badge-owner span:last-child { color: #a2adbf; text-align: right; }
.badge-owner.missing { opacity: .55; }
@media (prefers-reduced-motion: reduce) { button.badge { transition: none; } button.badge:active { transform: none; } }
`;

const STYLE = `
${BADGE_DIALOG_STYLE}
:host { display: block; }
ha-card { padding: 16px; }
h2 { margin: 0; font: inherit; font-size: 1.25rem; font-weight: 500; line-height: 1.3; overflow-wrap: anywhere; }
h3 { margin: 18px 0 6px; font: inherit; font-size: .95rem; font-weight: 600; }
button { font: inherit; color: inherit; cursor: pointer; }
button:focus-visible { outline: 2px solid var(--primary-color); outline-offset: 2px; }
.muted { color: var(--secondary-text-color); font-size: .85rem; }
.chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 12px 0; }
.chip { min-height: 44px; padding: 4px 12px; border-radius: 18px; background: none; border: 1px solid var(--divider-color); }
.chip[aria-pressed="true"] { background: var(--primary-color); border-color: var(--primary-color); color: var(--text-primary-color); }
.game { display: block; width: 100%; padding: 10px 4px; text-align: left; background: none; border: 0; border-top: 1px solid var(--divider-color); }
.game:active { background: var(--secondary-background-color); }
.game-row { display: grid; grid-template-columns: 88px 1fr; gap: 12px; align-items: center; }
.game-body { display: block; min-width: 0; }
.thumb { width: 88px; height: 66px; object-fit: contain; border-radius: 4px; background: var(--secondary-background-color); }
.hero { display: block; width: 100%; max-height: 340px; margin: 12px 0 4px; object-fit: contain; border-radius: 8px; background: var(--secondary-background-color); }
.game-name { display: flex; justify-content: space-between; gap: 8px; font-weight: 500; }
.row { display: grid; grid-template-columns: minmax(48px, 88px) 1fr auto; gap: 8px; align-items: center; margin-top: 5px; font-size: .85rem; }
.who { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.bar { height: 6px; border-radius: 3px; overflow: hidden; background: var(--divider-color); }
.bar i { display: block; height: 100%; background: var(--primary-color); }
.back { min-height: 44px; margin: -6px 0 8px -8px; padding: 4px 8px; background: none; border: 0; color: var(--primary-color); }
.item { display: grid; grid-template-columns: 44px 1fr auto; gap: 10px; padding: 9px 0; border-top: 1px solid var(--divider-color); }
.icon { width: 44px; height: 44px; border-radius: 6px; object-fit: contain; background: var(--secondary-background-color); }
.open .icon { filter: grayscale(1); opacity: .55; }
.name { font-weight: 500; overflow-wrap: anywhere; }
.desc { font-size: .85rem; color: var(--secondary-text-color); overflow-wrap: anywhere; }
.meta { text-align: right; font-size: .8rem; color: var(--secondary-text-color); white-space: nowrap; }
.people { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 5px; }
.person { padding: 1px 7px; border-radius: 9px; font-size: .75rem; border: 1px solid var(--divider-color); color: var(--secondary-text-color); }
.person.yes { background: var(--success-color, #2e7d32); border-color: transparent; color: #fff; }
.badge-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(132px, 1fr)); gap: 12px; }
.badge { min-width: 0; padding: 10px; text-align: center; border: 1px solid var(--divider-color); border-radius: 8px; }
.badge img, .badge .blank { display: block; width: 72px; height: 72px; margin: 0 auto 8px; object-fit: contain; }
.badge.locked img { filter: grayscale(1); opacity: .4; }
.badge .people { justify-content: center; }
.badge .desc { display: -webkit-box; -webkit-box-orient: vertical; -webkit-line-clamp: 3; overflow: hidden; }
.progress-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(190px, 1fr)); gap: 10px; margin: 8px 0; }
.pcard { min-width: 0; padding: 12px; border: 1px solid var(--divider-color); border-radius: 8px; }
.pcard.wide { grid-column: 1 / -1; }
.pcard.locked { opacity: .55; }
.pcard img.art { display: block; width: 72px; height: 72px; margin-bottom: 8px; object-fit: contain; }
.pcard.character img.art { width: 100%; height: 150px; }
.value { font-size: 1.5rem; font-weight: 500; line-height: 1.3; overflow-wrap: anywhere; }
.stats { display: grid; grid-template-columns: 1fr auto; gap: 2px 10px; margin-top: 8px; font-size: .85rem; }
.stats span:nth-child(odd) { color: var(--secondary-text-color); text-transform: capitalize; }
.gear { display: flex; align-items: center; gap: 6px; margin-top: 6px; font-size: .8rem; }
.gear img { width: 28px; height: 28px; object-fit: contain; }
.lead { margin: 4px 0; color: var(--secondary-text-color); }
.state { padding: 18px 0; color: var(--secondary-text-color); }
`;

const el = (tag, props = {}, ...children) => {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === "class") node.className = value;
    else if (key === "on") node.addEventListener("click", value);
    else if (value !== undefined && value !== null) node.setAttribute(key, value);
  }
  node.append(...children.flat(Infinity).filter((c) => c !== null && c !== undefined && c !== false));
  return node;
};

const safeImage = (url) =>
  typeof url === "string" && (url.startsWith("https://") || url.startsWith("/local/") || url.startsWith(`/${DOMAIN}/badge-images/`)) ? url : null;
const longDate = (value) => {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Earned"
    : date.toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" });
};

const showBadgeDialog = (root, badge) => {
  root.querySelector(".badge-dialog")?.remove();
  const image = safeImage(badge.image);
  const owners = [...badge.owners].sort((a, b) => Number(b.earned) - Number(a.earned) || a.person.localeCompare(b.person));
  const closeButton = el("button", { class: "badge-close", type: "button", "aria-label": "Close" }, "×");
  const dialog = el(
    "dialog",
    { class: "badge-dialog", "aria-labelledby": "badge-dialog-title" },
    closeButton,
    image && el("img", { class: "badge-large", src: image, alt: "" }),
    el("div", { class: "badge-kicker" }, badge.kicker || badge.track || "Badge"),
    el("h2", { id: "badge-dialog-title" }, badge.name),
    badge.description && el("p", { class: "badge-full" }, badge.description),
    badge.facts && badge.facts.length > 0 &&
      el("div", { class: "badge-facts" }, badge.facts.flatMap(([label, value]) => [el("span", {}, label), el("span", {}, String(value))])),
    badge.gallery?.length > 0 &&
      el("div", { class: "badge-gallery", "aria-label": "Badges in this quest" }, badge.gallery.filter((item) => safeImage(item.image)).map((item) => el("img", { src: safeImage(item.image), alt: item.name, title: item.name, loading: "lazy" }))),
    badge.help?.length > 0 &&
      el("section", { class: "badge-help", "aria-label": "How to earn it" }, el("h3", {}, "How to earn it"),
        badge.help.map((slide) => el("div", { class: "help-slide" },
          slide.title && el("h4", {}, slide.title),
          slide.text && el("p", {}, slide.text),
          safeImage(slide.image) && el("img", { src: safeImage(slide.image), alt: slide.title || "Help guide", loading: "lazy" })))),
    badge.link && el("a", { class: "badge-link", href: badge.link, target: "_blank", rel: "noopener noreferrer" }, "Open on Stern"),
    owners.map((owner) =>
      el(
        "div",
        { class: `badge-owner ${owner.earned ? "" : "missing"}` },
        el("span", {}, `${owner.earned ? "✓" : "○"} ${owner.person}`),
        el("span", {}, owner.detail ?? (owner.earned ? (owner.date ? longDate(owner.date) : "Earned") : "Not earned"))
      )
    )
  );
  const closeDialog = () => {
    dialog.close();
    dialog.remove();
  };
  closeButton.addEventListener("click", closeDialog);
  dialog.addEventListener("click", (event) => {
    const box = dialog.getBoundingClientRect();
    const outside = event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom;
    if (event.target === dialog && outside) closeDialog();
  });
  dialog.addEventListener("close", () => dialog.remove());
  root.append(dialog);
  dialog.showModal();
  closeButton.focus();
};

const makeClickable = (node, label, onOpen) => {
  node.classList.add("detail-trigger");
  node.setAttribute("role", "button");
  node.setAttribute("tabindex", "0");
  node.setAttribute("aria-label", `View ${label}`);
  node.addEventListener("click", onOpen);
  node.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onOpen();
    }
  });
  return node;
};

const hasOpenDialog = (card) => Boolean(card.shadowRoot.querySelector("dialog[open]"));

const watchUpdates = (card) => {
  if (card._embeddedGame || card._updateWatch || !card.isConnected || !card._hass?.connection) return;
  card._updateWatch = card._hass.connection.subscribeMessage(
    () => {
      clearTimeout(card._updateTimer);
      card._updateTimer = setTimeout(() => card._refresh(), 3000);
    },
    { type: `${DOMAIN}/subscribe_updates` }
  );
  card._updateWatch.catch(() => {
    card._updateWatch = null;
  });
};

const stopWatchingUpdates = (card) => {
  clearTimeout(card._updateTimer);
  card._updateWatch?.then((unsubscribe) => unsubscribe()).catch(() => {});
  card._updateWatch = null;
};

const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;

class SternAchievementsCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._person = "all";
    this._filter = "open";
    this._gameId = null;
    this._details = {};
  }

  setConfig(config) {
    this._title = (config && config.title) || "Game achievements";
    this._backglasses = (config && config.backglasses) || {};
    this._embeddedGame = config && config.game_id ? String(config.game_id) : null;
    if (config && config.person) this._person = config.person;
  }

  connectedCallback() {
    watchUpdates(this);
    if (this._detached) {
      this._detached = false;
      this._refresh();
    }
  }

  disconnectedCallback() {
    this._detached = !this._embeddedGame;
    stopWatchingUpdates(this);
  }

  async _refresh() {
    if (hasOpenDialog(this)) {
      this._updateTimer = setTimeout(() => this._refresh(), 30000);
      return;
    }
    try {
      this._people = (await this._hass.callWS({ type: `${DOMAIN}/overview` })).people;
      this._details = {};
      if (this._gameId) await this._loadGame(this._gameId);
      this._render();
    } catch (err) {
      /* Keep showing the last good data. */
    }
  }

  getCardSize() {
    return 8;
  }

  static getStubConfig() {
    return {};
  }

  set hass(hass) {
    this._hass = hass;
    if (!this._started) {
      this._started = true;
      this._load();
    }
    watchUpdates(this);
  }

  async _load() {
    try {
      const data = await this._hass.callWS({ type: `${DOMAIN}/overview` });
      this._people = data.people;
      this._error = null;
    } catch (err) {
      this._error = "Could not load achievements. Check that Stern Insider Family is set up.";
    }
    if (this._embeddedGame && this._people) {
      this._openGame(this._embeddedGame);
      return;
    }
    this._render();
  }

  _gameFor(person, id = this._gameId) {
    return person.games.find((game) => game.title_id === id);
  }

  _allGames() {
    const games = new Map();
    for (const person of this._people) {
      for (const game of person.games) {
        if (this._person === "all" || this._person === person.entry_id) {
          if (!games.has(game.title_id)) games.set(game.title_id, game.game);
        }
      }
    }
    return [...games].map(([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name));
  }

  _backglass(id) {
    const custom = this._backglasses[id];
    if (custom) return { url: safeImage(custom), edition: null };
    for (const person of this._people) {
      const game = this._gameFor(person, id);
      if (game && game.backglass) return { url: safeImage(game.backglass), edition: game.backglass_edition };
    }
    return { url: null, edition: null };
  }

  _visiblePeople() {
    return this._people.filter((p) => this._person === "all" || p.entry_id === this._person);
  }

  async _openGame(id) {
    this._gameId = id;
    this._filter = "open";
    this._render();
    await this._loadGame(id);
    if (this._gameId === id) this._render();
  }

  async _loadGame(id) {
    const key = (person) => `${person.entry_id}:${id}`;
    await Promise.all(
      this._people
        .filter((person) => this._gameFor(person, id) && !this._details[key(person)])
        .map(async (person) => {
          try {
            this._details[key(person)] = await this._hass.callWS({
              type: `${DOMAIN}/game`,
              entry_id: person.entry_id,
              title_id: id,
            });
          } catch (err) {
            this._details[key(person)] = { groups: null };
          }
        })
    );
  }

  _chip(label, pressed, onClick) {
    return el("button", { class: "chip", "aria-pressed": String(pressed), type: "button", on: onClick }, label);
  }

  _personChips(people) {
    return el(
      "div",
      { class: "chips", role: "group", "aria-label": "Family member" },
      this._people.length > 1 &&
        this._chip("Everyone", this._person === "all", () => this._setPerson("all")),
      people.map((p) => this._chip(p.person, this._person === p.entry_id, () => this._setPerson(p.entry_id)))
    );
  }

  _setPerson(id) {
    this._person = id;
    this._render();
  }

  _progressRow(person, game) {
    const percent = game ? game.percent : 0;
    return el(
      "div",
      { class: "row" },
      el("span", { class: "who" }, person.person),
      el("span", { class: "bar" }, el("i", { style: `width:${percent}%` })),
      el("span", { class: "muted" }, game ? `${game.earned}/${game.total}` : "Not played")
    );
  }

  _renderList() {
    const games = this._allGames();
    const people = this._visiblePeople();
    return [
      el("h2", {}, this._title),
      this._personChips(this._people),
      games.length
        ? games.map((game) =>
            el(
              "button",
              { class: "game", type: "button", on: () => this._openGame(game.id) },
              el(
                "span",
                { class: "game-row" },
                this._backglass(game.id).url
                  ? el("img", { class: "thumb", src: this._backglass(game.id).url, alt: "", loading: "lazy" })
                  : el("span", { class: "thumb" }),
                el(
                  "span",
                  { class: "game-body" },
                  el("span", { class: "game-name" }, el("span", {}, game.name), el("span", { "aria-hidden": "true" }, "›")),
                  people.map((person) => this._progressRow(person, this._gameFor(person, game.id)))
                )
              )
            )
          )
        : el("div", { class: "state" }, "No game achievements yet.")
    ];
  }

  _merged(people) {
    const groups = new Map();
    for (const person of people) {
      const detail = this._details[`${person.entry_id}:${this._gameId}`];
      for (const group of (detail && detail.groups) || []) {
        if (!groups.has(group.name)) groups.set(group.name, { name: group.name, levels: new Map() });
        const target = groups.get(group.name);
        for (const level of group.levels) {
          if (!target.levels.has(level.name)) target.levels.set(level.name, { ...level, group: group.name, by: new Map() });
          target.levels.get(level.name).by.set(person.entry_id, level);
        }
      }
    }
    return [...groups.values()].map((group) => ({ name: group.name, levels: [...group.levels.values()] }));
  }

  _renderLevel(level, people) {
    const earnedBy = people.filter((p) => level.by.get(p.entry_id)?.earned);
    const complete = earnedBy.length === people.length;
    const single = people.length === 1;
    const date = single && level.by.get(people[0].entry_id)?.date;
    const icon = safeImage(level.icon);
    return makeClickable(el(
      "div",
      { class: `item ${earnedBy.length ? "earned" : "open"}` },
      icon ? el("img", { class: "icon", src: icon, alt: "", loading: "lazy" }) : el("span", { class: "icon" }),
      el(
        "div",
        {},
        el("div", { class: "name" }, level.name),
        el("div", { class: "desc" }, level.description),
        !single &&
          el(
            "div",
            { class: "people" },
            people.map((p) =>
              el(
                "span",
                { class: `person ${level.by.get(p.entry_id)?.earned ? "yes" : ""}` },
                `${level.by.get(p.entry_id)?.earned ? "✓" : "○"} ${p.person}`
              )
            )
          )
      ),
      el(
        "div",
        { class: "meta" },
        el("div", {}, `${level.points} XP`),
        el("div", {}, `${level.rarity}% of players`),
        el("div", {}, date ? new Date(date).toLocaleDateString() : single ? (complete ? "Earned" : "Open") : "")
      )
    ), level.name, () => this._openLevel(level));
  }

  _openLevel(level) {
    const players = this._people.filter((person) => this._gameFor(person));
    const group = this._merged(players).find((item) => item.name === level.group);
    const full = group?.levels.find((item) => item.name === level.name) || level;
    showBadgeDialog(this.shadowRoot, {
      kicker: level.group,
      name: full.name,
      description: full.description,
      image: full.icon,
      facts: [["XP", full.points], ["Players with this", `${full.rarity}%`]],
      owners: players.filter((person) => full.by.has(person.entry_id)).map((person) => {
        const owned = full.by.get(person.entry_id);
        return { person: person.person, earned: owned.earned, date: owned.date };
      })
    });
  }

  _renderDetail() {
    const players = this._people.filter((p) => this._gameFor(p));
    if (this._person !== "all" && !players.some((p) => p.entry_id === this._person)) this._person = "all";
    const people = players.filter((p) => this._person === "all" || p.entry_id === this._person);
    const name = this._gameFor(players[0]).game;
    const keys = people.map((p) => `${p.entry_id}:${this._gameId}`);
    const loading = keys.some((key) => !this._details[key]);
    const missing = keys.every((key) => this._details[key] && !this._details[key].groups);
    const groups = this._merged(people);
    const isEarned = (level) => people.every((p) => level.by.get(p.entry_id)?.earned);
    const anyEarned = (level) => people.some((p) => level.by.get(p.entry_id)?.earned);
    const levels = groups.flatMap((g) => g.levels);
    const counts = {
      open: levels.filter((l) => !isEarned(l)).length,
      earned: levels.filter(anyEarned).length,
      all: levels.length
    };
    const show = (level) =>
      this._filter === "all" || (this._filter === "open" ? !isEarned(level) : anyEarned(level));
    const visible = groups
      .map((group) => ({ ...group, levels: group.levels.filter(show) }))
      .filter((group) => group.levels.length);
    const label = { open: "Open", earned: "Earned", all: "All" };
    const backglass = this._backglass(this._gameId);
    const easiest = levels.filter((level) => !isEarned(level)).sort((a, b) => b.rarity - a.rarity || a.points - b.points).slice(0, 3);
    return [
      !this._embeddedGame &&
        el("button", { class: "back", type: "button", on: () => { this._gameId = null; this._render(); } }, "‹ All games"),
      !this._embeddedGame && el("h2", {}, name),
      !this._embeddedGame && backglass.url &&
        el("img", { class: "hero", src: backglass.url, alt: `${name} backglass` }),
      !this._embeddedGame && backglass.edition && el("div", { class: "muted" }, `${backglass.edition} backglass`),
      el("div", { class: "muted" }, people.length === 1
        ? `${plural(counts.earned, "achievement")} earned · ${counts.open} open`
        : `${plural(people.length, "player")} · ${counts.open} not finished by everyone`),
      this._personChips(players),
      el(
        "div",
        { class: "chips", role: "group", "aria-label": "Show" },
        ["open", "earned", "all"].map((key) =>
          this._chip(`${label[key]} (${counts[key]})`, this._filter === key, () => {
            this._filter = key;
            this._render();
          })
        )
      ),
      this._filter === "open" && easiest.length > 0 && [
        el("h3", {}, "Next easiest"),
        el("div", { class: "muted" }, "The open achievements earned by the most players."),
        easiest.map((level) => this._renderLevel(level, people))
      ],
      loading && !levels.length
        ? el("div", { class: "state" }, "Loading achievements…")
        : missing
          ? el("div", { class: "state" }, "These details will appear after the next Stern update.")
          : visible.length
            ? visible.map((group) => [el("h3", {}, group.name), group.levels.map((l) => this._renderLevel(l, people))])
            : el("div", { class: "state" }, this._filter === "open" ? "Nothing left to earn here." : "Nothing earned here yet.")
    ];
  }

  _render() {
    let content;
    if (this._error) content = el("div", { class: "state" }, this._error);
    else if (!this._people) content = el("div", { class: "state" }, "Loading…");
    else if (!this._people.length) content = el("div", { class: "state" }, "Add a family member to Stern Insider Family first.");
    else content = this._gameId ? this._renderDetail() : this._renderList();
    const card = el(this._embeddedGame ? "div" : "ha-card", {}, content);
    this.shadowRoot.replaceChildren(el("style", {}, STYLE), card);
  }
}

const BADGE_SECTIONS = ["Badges", "Games Played", "Days Played", "Day Streak", "Week Streak"];

class SternBadgesCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._filter = "earned";
    this._badges = {};
  }

  setConfig(config) {
    this._title = (config && config.title) || "All badges";
  }

  connectedCallback() {
    watchUpdates(this);
    if (this._detached) {
      this._detached = false;
      this._refresh();
    }
  }

  disconnectedCallback() {
    this._detached = !this._embeddedGame;
    stopWatchingUpdates(this);
  }

  async _refresh() {
    if (hasOpenDialog(this)) {
      this._updateTimer = setTimeout(() => this._refresh(), 30000);
      return;
    }
    try {
      const people = (await this._hass.callWS({ type: `${DOMAIN}/overview` })).people;
      const badges = {};
      await Promise.all(people.map(async (person) => {
        try {
          badges[person.entry_id] = (await this._hass.callWS({ type: `${DOMAIN}/badges`, entry_id: person.entry_id })).badges;
        } catch (err) {
          badges[person.entry_id] = this._badges[person.entry_id] || null;
        }
      }));
      this._people = people;
      this._badges = badges;
      if (this._person !== "all" && !people.some((person) => person.entry_id === this._person)) this._person = people[0]?.entry_id || "all";
      this._render();
    } catch (err) {
      /* Keep showing the last good data. */
    }
  }

  getCardSize() {
    return 10;
  }

  static getStubConfig() {
    return {};
  }

  set hass(hass) {
    this._hass = hass;
    if (!this._started) {
      this._started = true;
      this._load();
    }
    watchUpdates(this);
  }

  async _load() {
    try {
      const data = await this._hass.callWS({ type: `${DOMAIN}/overview` });
      this._people = data.people;
      this._person = data.people.length ? data.people[0].entry_id : "all";
      this._render();
      await Promise.all(
        data.people.map(async (person) => {
          try {
            const result = await this._hass.callWS({ type: `${DOMAIN}/badges`, entry_id: person.entry_id });
            this._badges[person.entry_id] = result.badges;
          } catch (err) {
            this._badges[person.entry_id] = null;
          }
        })
      );
      this._error = null;
    } catch (err) {
      this._error = "Could not load badges. Check that Stern Insider Family is set up.";
    }
    this._render();
  }

  _chip(label, pressed, onClick) {
    return el("button", { class: "chip", "aria-pressed": String(pressed), type: "button", on: onClick }, label);
  }

  _merged(people) {
    const items = new Map();
    for (const person of people) {
      const seen = new Map();
      for (const badge of this._badges[person.entry_id] || []) {
        const count = seen.get(badge.name) || 0;
        seen.set(badge.name, count + 1);
        const key = `${badge.name}#${count}`;
        if (!items.has(key)) items.set(key, { ...badge, key, by: new Map() });
        const item = items.get(key);
        item.by.set(person.entry_id, badge);
        if (!item.image && badge.image) item.image = badge.image;
      }
    }
    return [...items.values()];
  }

  _openBadge(item) {
    const full = this._merged(this._people).find((candidate) => candidate.key === item.key) || item;
    showBadgeDialog(this.shadowRoot, {
      ...full,
      owners: this._people
        .filter((person) => full.by.has(person.entry_id))
        .map((person) => {
          const badge = full.by.get(person.entry_id);
          return { person: person.person, earned: badge.earned, date: badge.date };
        })
    });
  }

  _renderBadge(item, people) {
    const earnedBy = people.filter((p) => item.by.get(p.entry_id)?.earned);
    const single = people.length === 1;
    const date = single && item.by.get(people[0].entry_id)?.date;
    const image = safeImage(item.image);
    return el(
      "button",
      {
        class: `badge ${earnedBy.length ? "earned" : "locked"}`,
        type: "button",
        title: `View ${item.name}`,
        on: () => this._openBadge(item)
      },
      image ? el("img", { src: image, alt: "", loading: "lazy" }) : el("span", { class: "blank" }),
      el("div", { class: "name" }, item.name),
      item.description && el("div", { class: "desc" }, item.description),
      single
        ? el("div", { class: "muted" }, date ? new Date(date).toLocaleDateString() : earnedBy.length ? "Earned" : "Not earned")
        : el(
            "div",
            { class: "people" },
            people.map((p) =>
              el(
                "span",
                { class: `person ${item.by.get(p.entry_id)?.earned ? "yes" : ""}` },
                `${item.by.get(p.entry_id)?.earned ? "✓" : "○"} ${p.person}`
              )
            )
          )
    );
  }

  _renderBody() {
    const people = this._people.filter((p) => this._person === "all" || p.entry_id === this._person);
    const loading = people.some((p) => !(p.entry_id in this._badges));
    const items = this._merged(people);
    const earnedByAny = (item) => people.some((p) => item.by.get(p.entry_id)?.earned);
    const earnedByAll = (item) => people.every((p) => item.by.get(p.entry_id)?.earned);
    const counts = {
      earned: items.filter(earnedByAny).length,
      locked: items.filter((item) => !earnedByAll(item)).length,
      all: items.length
    };
    const show = (item) =>
      this._filter === "all" || (this._filter === "earned" ? earnedByAny(item) : !earnedByAll(item));
    const newest = (item) =>
      people.map((p) => item.by.get(p.entry_id)?.date || "").sort().pop() || "";
    const sections = BADGE_SECTIONS.map((name) => {
      const list = items.filter((item) => (item.track || "Badges") === name && show(item));
      list.sort((a, b) =>
        name === "Badges"
          ? newest(b).localeCompare(newest(a)) || a.name.localeCompare(b.name)
          : (a.milestone || 0) - (b.milestone || 0)
      );
      return { name, list };
    }).filter((section) => section.list.length);
    const labels = { earned: "Earned", locked: "Not earned", all: "All" };
    return [
      el(
        "div",
        { class: "chips", role: "group", "aria-label": "Show" },
        ["earned", "locked", "all"].map((key) =>
          this._chip(`${labels[key]} (${counts[key]})`, this._filter === key, () => {
            this._filter = key;
            this._render();
          })
        )
      ),
      loading && !items.length
        ? el("div", { class: "state" }, "Loading badges…")
        : sections.length
          ? sections.map((section) => [
              el("h3", {}, section.name),
              el("div", { class: "badge-grid" }, section.list.map((item) => this._renderBadge(item, people)))
            ])
          : el("div", { class: "state" }, "No badges to show here yet.")
    ];
  }

  _render() {
    let content;
    if (this._error) content = el("div", { class: "state" }, this._error);
    else if (!this._people) content = el("div", { class: "state" }, "Loading…");
    else if (!this._people.length) content = el("div", { class: "state" }, "Add a family member to Stern Insider Family first.");
    else {
      content = [
        el("h2", {}, this._title),
        el(
          "div",
          { class: "chips", role: "group", "aria-label": "Family member" },
          this._people.length > 1 &&
            this._chip("Everyone", this._person === "all", () => {
              this._person = "all";
              this._render();
            }),
          this._people.map((p) =>
            this._chip(p.person, this._person === p.entry_id, () => {
              this._person = p.entry_id;
              this._render();
            })
          )
        ),
        this._renderBody()
      ];
    }
    this.shadowRoot.replaceChildren(el("style", {}, STYLE), el("ha-card", {}, content));
  }
}

const number = (value) =>
  typeof value === "number" ? value.toLocaleString() : value === null || value === undefined ? "—" : String(value);

class SternProgressCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._gameId = null;
    this._person = null;
    this._blocks = {};
    this._itemFilters = {};
  }

  setConfig(config) {
    this._title = (config && config.title) || "Game progress";
    this._backglasses = (config && config.backglasses) || {};
    this._embeddedGame = config && config.game_id ? String(config.game_id) : null;
    this._preferredPerson = config && config.person;
  }

  getCardSize() {
    return 10;
  }

  static getStubConfig() {
    return {};
  }

  set hass(hass) {
    this._hass = hass;
    if (!this._started) {
      this._started = true;
      this._load();
    }
    watchUpdates(this);
  }

  connectedCallback() {
    watchUpdates(this);
    if (this._detached) {
      this._detached = false;
      this._refresh();
    }
  }

  disconnectedCallback() {
    this._detached = !this._embeddedGame;
    stopWatchingUpdates(this);
  }

  async _refresh() {
    if (hasOpenDialog(this)) {
      this._updateTimer = setTimeout(() => this._refresh(), 30000);
      return;
    }
    try {
      this._people = (await this._hass.callWS({ type: `${DOMAIN}/overview` })).people;
      const previous = this._blocks;
      this._blocks = {};
      if (this._gameId) await this._loadBlocks();
      if (!Object.keys(this._blocks).length && this._gameId) this._blocks = previous;
      this._render();
    } catch (err) {
      /* Keep showing the last good data. */
    }
  }

  async _load() {
    try {
      this._people = (await this._hass.callWS({ type: `${DOMAIN}/overview` })).people;
      this._error = null;
    } catch (err) {
      this._error = "Could not load progress. Check that Stern Insider Family is set up.";
    }
    const embedded = this._people && this._games().find((game) => game.title_id === this._embeddedGame);
    if (embedded) {
      this._openGame(embedded);
      return;
    }
    this._render();
  }

  _games() {
    const games = new Map();
    for (const person of this._people) {
      for (const game of person.games.filter((item) => item.has_progress)) {
        if (!games.has(game.title_id)) games.set(game.title_id, { ...game, players: [] });
        games.get(game.title_id).players.push(person);
      }
    }
    return [...games.values()].sort((a, b) => a.game.localeCompare(b.game));
  }

  _image(game) {
    return safeImage(this._backglasses[game.title_id] || game.backglass);
  }

  _openGame(game) {
    this._gameId = game.title_id;
    const preferred = game.players.find((person) => person.entry_id === this._preferredPerson);
    this._person = (preferred || game.players[0]).entry_id;
    this._render();
    this._loadBlocks();
  }

  async _loadBlocks() {
    const game = this._games().find((item) => item.title_id === this._gameId);
    if (!game) return;
    const missing = game.players.filter((person) => !this._blocks[`${person.entry_id}:${game.title_id}`]);
    if (!missing.length) return;
    await Promise.all(missing.map(async (person) => {
      const key = `${person.entry_id}:${game.title_id}`;
      try {
        this._blocks[key] = await this._hass.callWS({ type: `${DOMAIN}/progress`, entry_id: person.entry_id, title_id: game.title_id });
      } catch (err) {
        this._blocks[key] = { blocks: null };
      }
    }));
    if (this._gameId === game.title_id) this._render();
  }

  _peerBlocks(person) {
    return this._blocks[`${person.entry_id}:${this._gameId}`]?.blocks || [];
  }

  _currentPlayers() {
    return this._games().find((item) => item.title_id === this._gameId)?.players || [];
  }

  _blockStatus(block) {
    if (block.type === "unlock") return { earned: !block.locked, detail: block.locked ? "Locked" : "Unlocked" };
    if (block.type === "mode") return { earned: Number(block.played) > 0, detail: `Played ${number(block.played)}` };
    if (block.type === "meter") return { earned: Number(block.current) > 0, detail: number(block.current) };
    if (block.type === "stat") return { earned: Number(block.value) > 0, detail: number(block.value) };
    if (block.type === "pair") return { earned: block.values.some((item) => Number(item.value) > 0), detail: block.values.map((item) => number(item.value)).join(" / ") };
    if (block.type === "character") return { earned: !block.locked, detail: block.locked ? "Locked" : block.level || "Unlocked" };
    return { earned: false, detail: "—" };
  }

  _blockFacts(block) {
    if (block.type === "meter") return [["Current", number(block.current)], ["Next", number(block.maximum)]];
    if (block.type === "mode") return [["Cost", `${number(block.cost)} ${block.cost_label}`.trim()], ["Played", number(block.played)], ["Status", block.available ? "Available" : "Locked"]];
    if (block.type === "pair") return block.values.map((item) => [item.label, number(item.value)]);
    if (block.type === "character") return [["Level", block.level || "—"], ...(block.next ? [["Next", block.next]] : []), ...block.stats.map((item) => [item.label, number(item.value)]), ...block.equipment.map((item) => ["Gear", item.name])];
    return [];
  }

  _openBlock(block) {
    const owners = this._currentPlayers().flatMap((person) => {
      const match = this._peerBlocks(person).find((item) => item.type === block.type && item.title === block.title);
      return match ? [{ person: person.person, ...this._blockStatus(match) }] : [];
    });
    showBadgeDialog(this.shadowRoot, {
      kicker: "Progress",
      name: block.title,
      description: block.description || block.subtitle || "",
      image: block.image,
      facts: this._blockFacts(block),
      owners
    });
  }

  _openItem(item) {
    const owners = this._currentPlayers().flatMap((person) => {
      const match = this._peerBlocks(person).filter((block) => block.type === "items").flatMap((block) => block.items).find((entry) => entry.name === item.name);
      return match ? [{ person: person.person, earned: match.count > 0, detail: match.count > 0 ? `Collected: ${match.count}` : "Missing" }] : [];
    });
    showBadgeDialog(this.shadowRoot, {
      kicker: "Collection",
      name: item.name,
      description: item.description,
      image: item.image,
      facts: item.effect ? [["Effect", item.effect]] : [],
      owners
    });
  }

  _chip(label, pressed, onClick) {
    return el("button", { class: "chip", "aria-pressed": String(pressed), type: "button", on: onClick }, label);
  }

  _bar(percent) {
    const width = Math.max(0, Math.min(100, Number(percent) || 0));
    return el("span", { class: "bar", style: "display:block;margin-top:8px" }, el("i", { style: `width:${width}%` }));
  }

  _art(url) {
    const image = safeImage(url);
    return image ? el("img", { class: "art", src: image, alt: "", loading: "lazy" }) : null;
  }

  _card(block) {
    if (block.type === "stat") {
      return el("div", { class: "pcard" }, this._art(block.image), el("div", { class: "name" }, block.title),
        el("div", { class: "value" }, number(block.value)), block.description && el("div", { class: "desc" }, block.description));
    }
    if (block.type === "meter") {
      const span = Number(block.maximum) - Number(block.minimum);
      const percent = span > 0 ? ((Number(block.current) - Number(block.minimum)) / span) * 100 : 0;
      return el("div", { class: "pcard" }, this._art(block.image), el("div", { class: "name" }, block.title),
        block.subtitle && el("div", { class: "desc" }, block.subtitle), el("div", { class: "value" }, number(block.current)),
        span > 0 && this._bar(percent), span > 0 && el("div", { class: "muted" }, `Next: ${number(block.maximum)}`),
        block.description && el("div", { class: "desc" }, block.description));
    }
    if (block.type === "unlock") {
      return el("div", { class: `pcard ${block.locked ? "locked" : ""}` }, this._art(block.image), el("div", { class: "name" }, block.title),
        el("div", { class: "muted" }, block.locked ? "Locked" : "✓ Unlocked"), block.description && el("div", { class: "desc" }, block.description));
    }
    if (block.type === "pair") {
      return el("div", { class: "pcard" }, el("div", { class: "name" }, block.title),
        el("div", { class: "stats" }, block.values.flatMap((item) => [el("span", {}, item.label), el("span", {}, number(item.value))])));
    }
    if (block.type === "mode") {
      return el("div", { class: `pcard ${block.available ? "" : "locked"}` }, this._art(block.image), el("div", { class: "name" }, block.title),
        block.description && el("div", { class: "desc" }, block.description),
        el("div", { class: "stats" }, el("span", {}, "Cost"), el("span", {}, `${number(block.cost)} ${block.cost_label}`.trim()), el("span", {}, "Played"), el("span", {}, number(block.played))));
    }
    if (block.type === "character") {
      return el("div", { class: `pcard character ${block.locked ? "locked" : ""}` }, this._art(block.image), el("div", { class: "name" }, block.title),
        block.subtitle && el("div", { class: "desc" }, block.subtitle),
        block.locked && el("div", { class: "muted" }, "Locked"),
        block.level && el("div", { class: "muted" }, block.next ? `${block.level} → ${block.next}` : block.level),
        block.percent !== null && block.percent !== undefined && this._bar(block.percent),
        block.stats.length > 0 && el("div", { class: "stats" }, block.stats.flatMap((item) => [el("span", {}, item.label), el("span", {}, number(item.value))])),
        block.equipment.map((item) => el("div", { class: "gear" }, safeImage(item.image) && el("img", { src: safeImage(item.image), alt: "", loading: "lazy" }), el("span", {}, item.name))));
    }
    return null;
  }

  _clickableCard(block) {
    const card = this._card(block);
    return card ? makeClickable(card, block.title, () => this._openBlock(block)) : null;
  }

  _items(block, index) {
    const key = `${this._person}:${this._gameId}:${index}`;
    const filter = this._itemFilters[key] || "collected";
    const collected = block.items.filter((item) => item.count > 0);
    const missing = block.items.filter((item) => item.count <= 0);
    const shown = filter === "collected" ? collected : filter === "missing" ? missing : block.items;
    const choose = (value) => () => {
      this._itemFilters[key] = value;
      this._render();
    };
    return [
      el("div", { class: "chips", role: "group", "aria-label": "Items" },
        this._chip(`Collected (${collected.length})`, filter === "collected", choose("collected")),
        this._chip(`Missing (${missing.length})`, filter === "missing", choose("missing")),
        this._chip(`All (${block.items.length})`, filter === "all", choose("all"))),
      shown.length
        ? el("div", { class: "badge-grid" }, shown.map((item) => {
            const image = safeImage(item.image);
            return makeClickable(el("div", { class: `badge ${item.count > 0 ? "earned" : "locked"}` },
              image ? el("img", { src: image, alt: "", loading: "lazy" }) : el("span", { class: "blank" }),
              el("div", { class: "name" }, item.name),
              item.description && el("div", { class: "desc" }, item.description),
              item.effect && el("div", { class: "desc" }, item.effect),
              el("div", { class: "muted" }, item.count > 0 ? (item.max > 1 || item.count > 1 ? `Collected: ${item.count}` : "Collected") : "Missing")), item.name, () => this._openItem(item));
          }))
        : el("div", { class: "state" }, "Nothing to show here.")
    ];
  }

  _renderBlocks(blocks) {
    const nodes = [];
    let grid = [];
    const flush = () => {
      if (grid.length) nodes.push(el("div", { class: "progress-grid" }, grid));
      grid = [];
    };
    blocks.forEach((block, index) => {
      if (block.type === "heading" || block.type === "subheading" || block.type === "text") {
        flush();
        if (block.type === "heading") nodes.push(el("h3", {}, block.text));
        else nodes.push(el("div", { class: block.type === "text" ? "lead" : "name" }, block.text));
      } else if (block.type === "items") {
        flush();
        nodes.push(this._items(block, index));
      } else {
        const card = this._clickableCard(block);
        if (card) grid.push(card);
      }
    });
    flush();
    return nodes;
  }

  _renderDetail(game) {
    const data = this._blocks[`${this._person}:${this._gameId}`];
    const image = this._image(game);
    return [
      !this._embeddedGame &&
        el("button", { class: "back", type: "button", on: () => { this._gameId = null; this._render(); } }, "‹ All games"),
      !this._embeddedGame && el("h2", {}, game.game),
      !this._embeddedGame && image && el("img", { class: "hero", src: image, alt: `${game.game} backglass` }),
      el("div", { class: "chips", role: "group", "aria-label": "Family member" },
        game.players.map((person) => this._chip(person.person, person.entry_id === this._person, () => {
          this._person = person.entry_id;
          this._render();
          this._loadBlocks();
        }))),
      !data
        ? el("div", { class: "state" }, "Loading progress…")
        : data.blocks
          ? this._renderBlocks(data.blocks)
          : el("div", { class: "state" }, "Progress will appear after the next Stern update.")
    ];
  }

  _renderList(games) {
    return [
      el("h2", {}, this._title),
      games.length
        ? games.map((game) => {
            const image = this._image(game);
            return el("button", { class: "game", type: "button", on: () => this._openGame(game) },
              el("span", { class: "game-row" },
                image ? el("img", { class: "thumb", src: image, alt: "", loading: "lazy" }) : el("span", { class: "thumb" }),
                el("span", { class: "game-body" },
                  el("span", { class: "game-name" }, el("span", {}, game.game), el("span", { "aria-hidden": "true" }, "›")),
                  el("span", { class: "people" }, game.players.map((person) => el("span", { class: "person yes" }, person.person))))));
          })
        : el("div", { class: "state" }, "No game progress is available yet.")
    ];
  }

  _render() {
    let content;
    if (this._error) content = el("div", { class: "state" }, this._error);
    else if (!this._people) content = el("div", { class: "state" }, "Loading…");
    else {
      const games = this._games();
      const game = games.find((item) => item.title_id === this._gameId);
      content = game ? this._renderDetail(game) : this._renderList(games);
    }
    this.shadowRoot.replaceChildren(el("style", {}, STYLE), el(this._embeddedGame ? "div" : "ha-card", {}, content));
  }
}

const HOME_COLORS = ["#38bdf8", "#f472b6", "#a3e635", "#fbbf24", "#c084fc", "#fb7185", "#2dd4bf", "#fb923c"];
const HOME_STYLE = `
${BADGE_DIALOG_STYLE}
.quests { margin-bottom: 20px; }
.quest-head { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: baseline; justify-content: space-between; margin-bottom: 10px; }
.quest-head h2 { margin: 0; font-size: 1.2rem; }
.quest-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 250px), 1fr)); gap: 12px; }
.quest-name { font-weight: 650; overflow-wrap: anywhere; }
:host { display: block; }
ha-card { background: none; border: 0; box-shadow: none; border-radius: 0; overflow: visible; }
.home {
  --primary-text-color: #f5f7fb; --secondary-text-color: #a2adbf; --divider-color: rgba(255,255,255,.11);
  --secondary-background-color: rgba(255,255,255,.07); --primary-color: #38bdf8; --text-primary-color: #06131c;
  --success-color: #16a34a; --panel: rgba(255,255,255,.055); --panel-strong: rgba(255,255,255,.09);
  max-width: 1680px; margin: 0 auto; padding: 20px clamp(16px, 3vw, 40px) 56px; color: var(--primary-text-color);
}
button, input, select { font: inherit; color: inherit; }
button { cursor: pointer; }
button:focus-visible, input:focus-visible, select:focus-visible { outline: 2px solid var(--primary-color); outline-offset: 2px; }
.eyebrow { color: #7dd3fc; font-size: .76rem; font-weight: 700; letter-spacing: .13em; text-transform: uppercase; }
h1 { margin: 6px 0 8px; font-size: clamp(2.1rem, 5vw, 3.6rem); font-weight: 750; letter-spacing: -.035em; line-height: 1.02; }
.champ { color: #dbe4f0; font-size: 1rem; }
.champ b { color: #fde68a; }
.totals { display: flex; flex-wrap: wrap; gap: 10px; }
.total { min-width: 96px; padding: 11px 14px; border: 1px solid rgba(255,255,255,.13); border-radius: 14px; background: rgba(12,16,24,.56); backdrop-filter: blur(14px); }
.total b { display: block; font-size: 1.45rem; line-height: 1.15; }
.total span { color: var(--secondary-text-color); font-size: .75rem; }
.sort option { color: #111; }
.switch { display: inline-flex; align-items: center; gap: 7px; min-height: 44px; padding: 0 8px; border: 0; background: none; color: var(--secondary-text-color); font-size: .86rem; }
.switch i { position: relative; width: 34px; height: 20px; border-radius: 10px; background: rgba(255,255,255,.2); transition: background .16s; }
.switch i::after { content: ""; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%; background: #fff; transition: transform .16s; }
.switch[aria-checked="true"] { color: var(--primary-text-color); }
.switch[aria-checked="true"] i { background: var(--primary-color); }
.switch[aria-checked="true"] i::after { transform: translateX(14px); }
.meter { display: block; height: 5px; margin-top: 6px; overflow: hidden; border-radius: 3px; background: rgba(255,255,255,.2); }
.meter i { display: block; height: 100%; border-radius: inherit; background: var(--c, var(--primary-color)); }
.masthead { position: relative; overflow: hidden; display: flex; flex-wrap: wrap; gap: 18px; align-items: center; justify-content: space-between; min-height: 132px; padding: 22px clamp(20px, 3vw, 32px); border-radius: 20px; background: #151a24; isolation: isolate; }
.mast-art { position: absolute; inset: 0; z-index: -2; width: 100%; height: 100%; object-fit: cover; object-position: center 30%; opacity: .55; }
.masthead::after { content: ""; position: absolute; inset: 0; z-index: -1; background: linear-gradient(90deg, rgba(10,13,20,.97) 0%, rgba(10,13,20,.78) 52%, rgba(10,13,20,.42) 100%); }
.masthead h1 { font-size: clamp(1.9rem, 3.4vw, 2.8rem); }
.total { display: grid; grid-template-columns: auto 1fr; gap: 0 9px; align-items: center; min-width: 118px; max-width: 245px; }
.total img { grid-row: span 2; width: 38px; height: 38px; object-fit: contain; }
.total b { overflow: hidden; font-size: 1.02rem; white-space: nowrap; text-overflow: ellipsis; }
.total span { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.toolbar { position: sticky; top: var(--header-height, 56px); z-index: 4; display: grid; gap: 8px; margin: 12px 0 20px; padding: 9px; border: 1px solid var(--divider-color); border-radius: 16px; background: rgba(17,21,30,.9); backdrop-filter: blur(18px); }
.toolbar-row { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: space-between; }
.nav-tabs, .pills, .tools, .switches, .filters { display: flex; flex-wrap: wrap; gap: 6px; align-items: center; }
.nav-tab, .pill, .tab, .filter, .summary-button { min-height: 44px; padding: 6px 13px; border: 1px solid transparent; border-radius: 999px; background: transparent; color: var(--secondary-text-color); }
.nav-tab:active, .pill:active, .tab:active, .filter:active, .summary-button:active { background: var(--panel-strong); color: var(--primary-text-color); }
.nav-tab[aria-current="page"], .pill[aria-pressed="true"], .tab[aria-selected="true"], .filter[aria-pressed="true"] { background: #f5f7fb; color: #0d1118; font-weight: 600; }
.search, .sort { height: 44px; box-sizing: border-box; border: 1px solid var(--divider-color); border-radius: 999px; background: var(--panel); padding: 0 13px; }
.search { width: 190px; }
.text-button { display: inline-flex; min-height: 44px; align-items: center; padding: 0 4px; border: 0; background: none; color: var(--primary-color); font: inherit; font-weight: 600; text-decoration: none; cursor: pointer; }
.quests-page { margin: 4px 0 14px; }
.quests-page h1 { margin: 2px 0 4px; font-size: 2rem; }
.quest-group { margin: 0 0 26px; }
.group-head { display: flex; flex-wrap: wrap; gap: 6px 14px; align-items: flex-end; justify-content: space-between; margin-bottom: 6px; }
.group-head h2 { margin: 0; font-size: 1.35rem; }
.group-desc { max-width: 900px; margin: 0 0 12px; color: var(--secondary-text-color); line-height: 1.45; }
.zone { margin: 14px 0 0; }
.zone-head { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: baseline; margin-bottom: 8px; }
.zone-head h3 { margin: 0; font-size: 1.05rem; }
.zone-count { color: var(--secondary-text-color); font-size: .8rem; }
.quest-stack { display: grid; grid-template-columns: 1fr 1fr; gap: 2px; align-self: start; }
.quest-stack img { width: 100% !important; height: auto !important; aspect-ratio: 1; object-fit: contain; }
.refresh-button { border-color: var(--divider-color); color: var(--primary-text-color); white-space: nowrap; }
.refresh-button:disabled { opacity: .62; }
.updated { margin-top: 5px; color: var(--secondary-text-color); font-size: .78rem; }
.view-menu { position: relative; }
.view-menu summary { display: inline-flex; align-items: center; box-sizing: border-box; border-color: var(--divider-color); color: var(--primary-text-color); cursor: pointer; list-style: none; }
.view-menu summary::-webkit-details-marker { display: none; }
.view-panel { position: absolute; z-index: 8; top: 51px; right: 0; display: grid; gap: 9px; width: 230px; padding: 12px; border: 1px solid var(--divider-color); border-radius: 14px; background: #171c27; box-shadow: 0 18px 44px rgba(0,0,0,.45); }
.view-panel label { display: grid; gap: 5px; color: var(--secondary-text-color); font-size: .78rem; }
.view-panel .sort { width: 100%; }
.section-head { display: flex; flex-wrap: wrap; gap: 4px 12px; align-items: baseline; justify-content: space-between; margin-bottom: 10px; }
.section-head h2 { margin: 0; font-size: 1.2rem; }
.keep-playing { margin-bottom: 22px; }
.next-row { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 270px), 1fr)); gap: 12px; }
.next-card { display: grid; grid-template-columns: 76px 1fr; gap: 12px; align-items: center; min-width: 0; padding: 10px; border: 1px solid var(--divider-color); border-radius: 15px; background: linear-gradient(135deg, rgba(56,189,248,.1), rgba(255,255,255,.04)); text-align: left; }
.next-card img, .next-card .blank { width: 76px; height: 58px; border-radius: 9px; object-fit: cover; background: var(--panel); }
.next-card.quest-next img, .next-card.track-next img { object-fit: contain; }
.next-kicker { color: #7dd3fc; font-size: .72rem; font-weight: 700; }
.next-title { overflow-wrap: anywhere; font-weight: 650; line-height: 1.2; }
.games-head { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; justify-content: space-between; margin-bottom: 12px; }
.games-head h2 { margin: 0; font-size: 1.2rem; }
.games { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 270px), 1fr)); gap: 16px; }
.tile { display: flex; flex-direction: column; width: 100%; overflow: hidden; padding: 0; border: 1px solid rgba(255,255,255,.11); border-radius: 16px; background: #141923; text-align: left; box-shadow: 0 12px 28px rgba(0,0,0,.25); transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease; }
.tile:active { transform: scale(.985); border-color: rgba(255,255,255,.42); }
.tile-art { position: relative; display: block; aspect-ratio: 16 / 10; overflow: hidden; background: linear-gradient(135deg, var(--a, #243047), var(--b, #111722)); }
.tile img.art { display: block; width: 100%; height: 100%; object-fit: cover; transition: transform .3s ease, filter .18s ease; }
.tile.unplayed img.art { filter: saturate(.38) brightness(.58); }
.tag { position: absolute; z-index: 1; top: 9px; right: 9px; padding: 4px 8px; border-radius: 999px; background: rgba(8,12,18,.78); color: #dbeafe; font-size: .68rem; font-weight: 700; }
.tile-info { display: grid; gap: 8px; min-height: 76px; padding: 11px 13px 12px; }
.tile-title { color: #fff; font-size: 1rem; font-weight: 700; line-height: 1.2; overflow-wrap: anywhere; }
.tile-line { display: flex; gap: 10px; align-items: center; justify-content: space-between; min-width: 0; color: #cbd5e1; font-size: .78rem; }
.rings { display: grid; grid-template-columns: repeat(auto-fit, minmax(54px, 1fr)); gap: 7px; }
.ring-item { display: grid; justify-items: center; gap: 2px; min-width: 0; color: #dbe4f0; font-size: .68rem; text-align: center; }
.ring-name { width: 100%; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.ring { display: grid; width: 34px; height: 34px; place-items: center; border-radius: 50%; background: conic-gradient(var(--c) calc(var(--p) * 1%), rgba(255,255,255,.18) 0); }
.ring > span { display: grid; width: 27px; height: 27px; overflow: hidden; place-items: center; border-radius: 50%; background: #0c1119; color: #fff; font-size: .62rem; font-weight: 800; }
.player-marker { position: relative; display: grid; width: 100%; height: 100%; overflow: hidden; place-items: center; border-radius: 50%; background: color-mix(in srgb, var(--c, #334155) 45%, #0c1119); }
.player-marker img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; filter: brightness(.72); }
.player-marker b { position: relative; color: #fff; font-size: .78rem; font-weight: 800; line-height: 1; text-shadow: 0 1px 3px #000, 0 0 2px #000; }
.avatar .player-marker b { font-size: 1.05rem; }
.solo { display: flex; justify-content: space-between; color: #dbe4f0; font-size: .8rem; }
.quest { display: grid; grid-template-columns: 62px 1fr; gap: 11px; align-items: center; min-width: 0; padding: 11px; border: 1px solid var(--divider-color); border-radius: 15px; background: var(--panel); }
.quest.urgent { border-color: rgba(251,191,36,.72); background: linear-gradient(135deg, rgba(251,191,36,.16), rgba(255,255,255,.05)); }
.quest img { width: 62px; height: 62px; object-fit: contain; }
.quest-state { display: inline-flex; margin-top: 2px; color: var(--secondary-text-color); font-size: .78rem; font-weight: 650; }
.quest-state.active { color: #86efac; }
.quest-state.upcoming { color: #7dd3fc; }
.quest.urgent .quest-state { color: #fde68a; }
.quest-games { margin-top: 3px; font-size: .78rem; overflow-wrap: anywhere; }
.quest-need { margin-top: 3px; color: var(--secondary-text-color); font-size: .76rem; }
.quest-people { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px; }
.quest-person { display: grid; width: 25px; height: 25px; overflow: hidden; place-items: center; box-sizing: border-box; border: 1px solid var(--c); border-radius: 50%; color: var(--c); font-size: .58rem; font-weight: 800; }
.quest-person .player-marker b { font-size: .68rem; }
.quest-person.done { box-shadow: 0 0 0 1px var(--c); }
.quest-person.done { background: var(--c); color: #071018; }
.quest-person:not(.done) .player-marker { opacity: .55; }
.family-summary { margin: -2px 0 8px; color: #dbe4f0; font-size: 1rem; }
.skeleton { position: relative; overflow: hidden; border-radius: 16px; background: rgba(255,255,255,.07); }
.skeleton::after { content: ""; position: absolute; inset: 0; transform: translateX(-100%); background: linear-gradient(90deg, transparent, rgba(255,255,255,.08), transparent); animation: shimmer 1.3s infinite; }
.skeleton.hero { height: 132px; margin-bottom: 14px; }
.skeleton.bar { height: 58px; margin-bottom: 20px; }
.skeleton.game { aspect-ratio: 4 / 3; }
@keyframes shimmer { to { transform: translateX(100%); } }
.message { display: grid; justify-items: center; gap: 12px; padding: 52px 16px; border: 1px solid var(--divider-color); border-radius: 18px; background: var(--panel); text-align: center; }
.retry { min-height: 44px; padding: 0 16px; border: 0; border-radius: 999px; background: #f5f7fb; color: #0d1118; font-weight: 650; }
.panel { margin-bottom: 20px; padding: 18px; border: 1px solid var(--divider-color); border-radius: 18px; background: var(--panel); }
.panel h2 { margin: 0 0 14px; font-size: 1.15rem; }
.family { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr)); gap: 14px; }
.person-card { padding: 15px; border-radius: 14px; background: var(--panel); }
.who-line { display: flex; gap: 10px; align-items: center; margin-bottom: 11px; }
.avatar { display: grid; flex: none; width: 42px; height: 42px; place-items: center; overflow: hidden; border-radius: 50%; background: var(--c); color: #071018; font-weight: 800; }
.avatar img { width: 100%; height: 100%; object-fit: cover; }
.strong { font-weight: 650; }
.muted { color: var(--secondary-text-color); font-size: .82rem; }
.mini-stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 12px; }
.mini-stats b { display: block; font-size: 1.05rem; }
.track { margin-top: 8px; font-size: .78rem; }
.track div { display: flex; justify-content: space-between; color: var(--secondary-text-color); }
.badge-row { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 12px; }
.badge-row img { width: 44px; height: 44px; object-fit: contain; }
.score-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(min(100%, 280px), 1fr)); gap: 10px; }
.score-card { padding: 13px; border-radius: 14px; background: var(--panel); }
.score { display: grid; grid-template-columns: 26px 1fr auto; gap: 8px; padding: 6px 0; border-top: 1px solid var(--divider-color); font-size: .86rem; }
.score.family-score { color: #fde68a; font-weight: 650; }
.detail-hero { position: relative; display: grid; grid-template-columns: minmax(0, 1.25fr) minmax(280px, .75fr); gap: clamp(18px, 3vw, 38px); overflow: hidden; padding: clamp(16px, 3vw, 30px); border-radius: 22px; background: #121722; isolation: isolate; }
.detail-glow { position: absolute; inset: -40px; z-index: -1; width: calc(100% + 80px); height: calc(100% + 80px); object-fit: cover; filter: blur(42px) saturate(1.35); opacity: .36; }
.detail-art { width: 100%; max-height: 560px; border-radius: 14px; object-fit: contain; box-shadow: 0 22px 54px rgba(0,0,0,.45); }
.detail-copy { align-self: center; min-width: 0; }
.detail-copy h1 { font-size: clamp(2rem, 4vw, 3.3rem); }
.logo { display: block; max-width: 72%; max-height: 74px; margin-bottom: 14px; object-fit: contain; object-position: left; }
.back-link { min-height: 44px; margin: 0 0 12px; padding: 0 13px; border: 1px solid var(--divider-color); border-radius: 999px; background: var(--panel); }
.player-line { margin-top: 12px; font-size: .86rem; }
.player-line div { display: flex; justify-content: space-between; gap: 8px; }
.tabs { display: flex; flex-wrap: wrap; gap: 6px; margin: 16px 0; }
.tab-body { min-height: 180px; padding: 18px; border: 1px solid var(--divider-color); border-radius: 18px; background: var(--panel); }
.empty { padding: 42px 12px; color: var(--secondary-text-color); text-align: center; }
@media (max-width: 760px) {
  .home { padding: 10px 10px 42px; }
  .masthead { min-height: 0; gap: 12px; padding: 16px; border-radius: 16px; }
  .masthead h1 { font-size: 1.9rem; }
  .totals { display: grid; width: 100%; grid-template-columns: 1fr 1fr; gap: 6px; }
  .total { min-width: 0; max-width: none; padding: 8px 10px; border-radius: 10px; }
  .toolbar { position: static; margin: 10px 0 14px; padding: 8px; }
  .toolbar-row { flex-wrap: nowrap; }
  .nav-tabs, .pills, .filters { flex-wrap: nowrap; overflow-x: auto; scrollbar-width: none; }
  .nav-tabs::-webkit-scrollbar, .pills::-webkit-scrollbar, .filters::-webkit-scrollbar { display: none; }
  .nav-tab, .pill, .filter { flex: none; }
  .tools { flex: 1 0 100%; flex-wrap: nowrap; }
  .toolbar-row.primary { flex-wrap: wrap; }
  .search { flex: 1 1 auto; width: auto; min-width: 0; }
  .view-panel { right: 0; }
  .total:first-child { grid-column: 1 / -1; }
  .next-row, .quest-row { display: flex; gap: 10px; overflow-x: auto; padding-bottom: 4px; scroll-snap-type: x proximity; scrollbar-width: none; }
  .next-row::-webkit-scrollbar, .quest-row::-webkit-scrollbar { display: none; }
  .next-card, .quest { flex: 0 0 min(82vw, 300px); scroll-snap-align: start; }
  .quest-group .quest-row { display: grid; grid-template-columns: 1fr; overflow: visible; }
  .quest-group .quest { flex: none; }
  .keep-playing, .quests { margin-bottom: 16px; }
  .games { grid-template-columns: 1fr; }
  .detail-hero { grid-template-columns: 1fr; }
}
@media (prefers-reduced-motion: reduce) { .tile, .tile img.art, .switch i, .switch i::after { transition: none; } .tile:active { transform: none; } .skeleton::after { animation: none; } }
`;

const storedFlag = (key) => {
  try {
    return window.localStorage.getItem(`stern-home-${key}`) === "1";
  } catch (err) {
    return false;
  }
};
const storeFlag = (key, value) => {
  try {
    window.localStorage.setItem(`stern-home-${key}`, value ? "1" : "0");
  } catch (err) {
    /* Private browsing can block storage; the switch still works for this visit. */
  }
};
const safeColor = (value) => (typeof value === "string" && /^#[0-9a-f]{3,8}$/i.test(value) ? value : null);

class SternHomeCard extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._person = "all";
    this._query = "";
    this._sort = "progress";
    this._gameId = null;
    this._tab = "achievements";
    this._show = { family: storedFlag("family"), scores: storedFlag("scores") };
    this._gameFilter = "all";
    this._detailPerson = null;
    this._viewOpen = false;
  }

  setConfig(config) {
    this._config = config || {};
    this._backglasses = this._config.backglasses || {};
  }

  getCardSize() {
    return 12;
  }

  static getStubConfig() {
    return {};
  }

  set hass(hass) {
    this._hass = hass;
    if (this._child) this._child.hass = hass;
    if (!this._started) {
      this._started = true;
      this._load();
    }
    watchUpdates(this);
  }

  connectedCallback() {
    watchUpdates(this);
    if (this._detached) {
      this._detached = false;
      this._refresh();
    }
  }

  disconnectedCallback() {
    this._detached = !this._embeddedGame;
    stopWatchingUpdates(this);
  }

  _setData(data) {
    this._data = data;
    this._colors = Object.fromEntries(data.people.map((p, i) => [p.entry_id, HOME_COLORS[i % HOME_COLORS.length]]));
    this._peopleById = Object.fromEntries(data.people.map((person) => [person.entry_id, person]));
  }

  async _refresh() {
    if (this._gameId || hasOpenDialog(this)) {
      this._stale = true;
      return;
    }
    const search = this.shadowRoot.querySelector(".search");
    const searching = search && this.shadowRoot.activeElement === search;
    try {
      this._setData(await this._hass.callWS({ type: `${DOMAIN}/overview` }));
      this._allBadges = null;
      this._stale = false;
      if (searching) this._fillGrid();
      else this._render();
    } catch (err) {
      /* Keep showing the last good data. */
    }
  }

  async _load() {
    this._error = null;
    this._render();
    try {
      this._setData(await this._hass.callWS({ type: `${DOMAIN}/overview` }));
    } catch (err) {
      this._error = "Stern Insider Family could not load.";
    }
    this._render();
  }

  _games() {
    const games = new Map();
    const artKeys = ["backglass", "backglass_edition", "logo", "gradient_start", "gradient_stop"];
    for (const entry of this._data.catalog || []) {
      games.set(entry.title_id, { ...entry, id: entry.title_id, name: entry.game, players: [], comingSoon: entry.coming_soon });
    }
    for (const person of this._data.people) {
      for (const game of person.games) {
        if (!games.has(game.title_id)) games.set(game.title_id, { id: game.title_id, name: game.game, players: [] });
        const item = games.get(game.title_id);
        item.players.push({ person, game });
        for (const key of artKeys) item[key] = item[key] || game[key];
        item.hasProgress = item.hasProgress || game.has_progress;
      }
    }
    return [...games.values()].map((game) => ({ ...game, backglass: this._backglasses[game.id] || game.backglass }));
  }

  _entries(game) {
    return game.players.filter((p) => this._person === "all" || p.person.entry_id === this._person);
  }

  _matchesFilter(game, filter = this._gameFilter) {
    const entries = this._entries(game);
    if (filter === "played") return entries.length > 0;
    if (filter === "unplayed") return entries.length === 0;
    if (filter === "progress") return entries.some((p) => p.game.has_progress);
    if (filter === "almost") return entries.some((p) => p.game.percent >= 75 && p.game.percent < 100);
    return true;
  }

  _visibleGames() {
    const query = this._query.trim().toLowerCase();
    const games = this._games().filter((game) => (!query || game.name.toLowerCase().includes(query)) && this._matchesFilter(game));
    const percent = (game) => (this._entries(game).length ? Math.max(...this._entries(game).map((p) => p.game.percent)) : -1);
    const open = (game) => (this._entries(game).length ? Math.min(...this._entries(game).map((p) => p.game.open)) : -1);
    return games.sort((a, b) =>
      this._sort === "name" ? a.name.localeCompare(b.name)
        : this._sort === "open" ? open(b) - open(a) || a.name.localeCompare(b.name)
          : percent(b) - percent(a) || a.name.localeCompare(b.name));
  }

  _champion() {
    const ranked = this._data.people.map((person) => {
      const scores = this._data.machines.flatMap((machine) => machine.scores).filter((score) => score.member === person.person);
      return { person, rank: scores.filter((score) => score.rank === 1).length * 10 + scores.length, xp: person.stats.xp || 0 };
    });
    ranked.sort((a, b) => b.rank - a.rank || b.xp - a.xp);
    return ranked[0] && (ranked[0].rank || ranked[0].xp) ? ranked[0].person.person : null;
  }

  _navigate(page) {
    const path = window.location.pathname.replace(/[^/]*$/, page);
    window.history.pushState(null, "", path);
    window.dispatchEvent(new CustomEvent("location-changed", { bubbles: true, composed: true }));
  }

  _toggle(key) {
    this._show[key] = !this._show[key];
    storeFlag(key, this._show[key]);
    this._render();
  }

  _switch(key, label) {
    return el("button", { class: "switch", type: "button", role: "switch", "aria-checked": String(this._show[key]), on: () => this._toggle(key) }, el("i", {}), label);
  }

  _initial(person) {
    return (person.person || "?").trim().charAt(0).toUpperCase();
  }

  _marker(person) {
    const avatar = safeImage(person.avatar_url);
    const image = avatar ? el("img", { src: avatar, alt: "", loading: "lazy" }) : null;
    image?.addEventListener("error", () => image.remove());
    return el("span", { class: "player-marker" }, image, el("b", {}, this._initial(person)));
  }

  _tile(game) {
    const art = safeImage(game.backglass);
    const start = safeColor(game.gradient_start);
    const stop = safeColor(game.gradient_stop);
    const players = this._entries(game);
    const selected = this._person !== "all" ? players[0] : null;
    return el(
      "button",
      { class: `tile ${players.length ? "" : "unplayed"}`, type: "button", style: `${start ? `--a:${start};` : ""}${stop ? `--b:${stop};` : ""}`, "aria-label": `Open ${game.name}`, on: () => this._openGame(game.id) },
      el("span", { class: "tile-art" },
        art && el("img", { class: "art", src: art, alt: "", loading: "lazy" }),
        (game.comingSoon || game.hasProgress) && el("span", { class: "tag" }, game.comingSoon ? "Coming soon" : "Progress"),
      ),
      el("span", { class: "tile-info" },
        el("span", { class: "tile-title" }, game.name),
        selected
          ? [
              el("span", { class: "solo" }, el("span", {}, `${selected.game.earned}/${selected.game.total} achievements`), el("b", {}, `${selected.game.percent}%`)),
              el("span", { class: "meter", style: `--c:${this._colors[selected.person.entry_id]}` }, el("i", { style: `width:${selected.game.percent}%` }))
            ]
          : !players.length
            ? el("span", { class: "tile-line" }, game.comingSoon ? "Coming soon" : "Not played yet")
            : el("span", { class: "rings" }, players.map(({ person, game: played }) =>
                el("span", { class: "ring-item" },
                  el("span", { class: "ring", style: `--c:${this._colors[person.entry_id]};--p:${played.percent}` }, el("span", {}, this._marker(person))),
                  el("span", { class: "ring-name" }, person.person),
                  el("b", {}, `${played.percent}%`)))))
    );
  }

  async _openBadge(name) {
    if (!this._allBadges) {
      const lists = await Promise.all(this._data.people.map(async (person) => {
        try {
          return [person, (await this._hass.callWS({ type: `${DOMAIN}/badges`, entry_id: person.entry_id })).badges];
        } catch (err) {
          return [person, []];
        }
      }));
      this._allBadges = lists;
    }
    const matches = this._allBadges.flatMap(([person, badges]) => {
      const found = badges.filter((badge) => badge.name === name);
      const badge = found.find((item) => item.earned) || found[0];
      return badge ? [{ person, badge }] : [];
    });
    if (!matches.length) return;
    const first = matches.find((match) => match.badge.earned) || matches[0];
    showBadgeDialog(this.shadowRoot, {
      ...first.badge,
      owners: matches.map(({ person, badge }) => ({ person: person.person, earned: badge.earned, date: badge.date }))
    });
  }

  _questStatus(quest) {
    const now = Date.now();
    const start = Date.parse(quest.start);
    const end = Date.parse(quest.end);
    if (!Number.isFinite(end) && quest.upcoming) return { key: "upcoming", order: 1, days: null, label: "Coming soon" };
    if (!Number.isFinite(end)) return { key: "active", order: 0, days: null, label: "Available now" };
    if (start > now) return { key: "upcoming", order: 1, days: Math.ceil((start - now) / 86400000), label: `Starts ${new Date(start).toLocaleDateString(undefined, { month: "short", day: "numeric" })}` };
    if (end <= now) return { key: "ended", order: 2, days: 0, label: "Ended" };
    const days = Math.ceil((end - now) / 86400000);
    if (days > 365) return { key: "active", order: 0, days: null, label: "Available now" };
    return { key: "active", order: 0, days, label: days <= 1 ? "Ends today" : `${days} days left` };
  }

  _questGames(quest, full = false) {
    const ids = [...new Set(quest.titles || [])];
    if (!ids.length) return "";
    const catalog = this._data.catalog || [];
    const released = catalog.filter((game) => !game.coming_soon);
    if (released.length && released.every((game) => ids.includes(game.title_id))) return "All connected games";
    const names = ids.map((id) => catalog.find((game) => game.title_id === id)?.game).filter(Boolean).sort((a, b) => a.localeCompare(b));
    if (names.length === ids.length && (full || names.length <= 2)) return names.join(", ");
    return plural(ids.length, "game");
  }

  _openQuest(event, quest) {
    const status = this._questStatus(quest);
    const games = this._questGames(quest, true);
    showBadgeDialog(this.shadowRoot, {
      kicker: event.listed ? "Stern quest" : quest.zone ? `${event.name} · ${quest.zone}` : event.name,
      name: quest.name,
      description: quest.description,
      image: quest.image,
      gallery: quest.gallery,
      help: quest.help,
      link: quest.url ? `https://insider.sternpinball.com${quest.url}` : (event.url ? `https://insider.sternpinball.com${event.url}` : null),
      facts: [
        ["Status", status.label],
        games && ["Games", games],
        quest.start && ["Starts", longDate(quest.start)],
        quest.end && status.days !== null && ["Ends", longDate(quest.end)],
        !event.listed && !event.page && ["Players earned", number(quest.players)]
      ].filter(Boolean),
      owners: quest.tracked === false ? [] : quest.owners.map((owner) => ({ person: owner.person, earned: owner.earned, date: owner.date }))
    });
  }

  _questCard(event, quest) {
    const status = this._questStatus(quest);
    const image = safeImage(quest.image);
    const art = (quest.gallery || []).map((item) => safeImage(item.image)).filter(Boolean).slice(0, 4);
    const games = this._questGames(quest);
    const owners = quest.tracked === false ? [] : quest.owners.filter((owner) => this._person === "all" || owner.entry_id === this._person);
    const missing = owners.filter((owner) => !owner.earned);
    const need = !owners.length ? "" : !missing.length ? "Earned" : this._person !== "all" ? "Still needed" : missing.length === owners.length ? "Everyone still needs it" : `${missing.length} still ${missing.length === 1 ? "needs" : "need"} it`;
    const urgent = status.key === "active" && status.days !== null && status.days <= 3 && missing.length > 0;
    return makeClickable(el("article", { class: `quest ${status.key} ${urgent ? "urgent" : ""}` },
      art.length > 1 ? el("span", { class: "quest-stack" }, art.map((url) => el("img", { src: url, alt: "", loading: "lazy" }))) : image ? el("img", { src: image, alt: "", loading: "lazy" }) : el("span", {}),
      el("div", {}, el("div", { class: "quest-name" }, quest.name), el("span", { class: `quest-state ${status.key}` }, status.label),
        games && el("div", { class: "quest-games" }, games),
        need && el("div", { class: "quest-need" }, need),
        el("div", { class: "quest-people" }, owners.map((owner) => {
          const person = this._peopleById[owner.entry_id];
          return el("span", { class: `quest-person ${owner.earned ? "done" : ""}`, style: `--c:${this._colors[owner.entry_id]}`, title: `${owner.person}: ${owner.earned ? "earned" : "still needed"}` }, person ? this._marker(person) : owner.person.charAt(0).toUpperCase());
        })))), quest.name, () => this._openQuest(event, quest));
  }

  _zones(event) {
    const zones = new Map();
    for (const quest of event.quests) {
      if (this._questStatus(quest).key === "ended") continue;
      const key = quest.zone || "";
      if (!zones.has(key)) zones.set(key, { name: quest.zone, order: quest.zone_order ?? 0, quests: [] });
      zones.get(key).quests.push(quest);
    }
    return [...zones.values()].sort((a, b) => a.order - b.order).map((zone) => ({ ...zone, status: this._questStatus(zone.quests[0]) }));
  }

  _zoneProgress(quests) {
    const people = this._selectedPeople();
    return people.map((person) => ({ person, done: quests.filter((quest) => quest.owners.some((owner) => owner.entry_id === person.entry_id && owner.earned)).length,
      known: quests.some((quest) => quest.owners.some((owner) => owner.entry_id === person.entry_id)) })).filter((item) => item.known);
  }

  _pageTile(event, zone) {
    const art = zone.quests.map((quest) => safeImage(quest.image)).filter(Boolean).slice(0, 4);
    const progress = this._zoneProgress(zone.quests);
    const total = zone.quests.length;
    const need = this._person !== "all" && progress.length ? `${progress[0].done} of ${total} earned` : plural(total, "quest");
    return makeClickable(el("article", { class: `quest ${zone.status.key}` },
      art.length > 1 ? el("span", { class: "quest-stack" }, art.map((url) => el("img", { src: url, alt: "", loading: "lazy" }))) : art.length ? el("img", { src: art[0], alt: "", loading: "lazy" }) : el("span", {}),
      el("div", {}, el("div", { class: "quest-name" }, event.name), el("span", { class: `quest-state ${zone.status.key}` }, zone.status.label),
        zone.name && el("div", { class: "quest-games" }, zone.name),
        el("div", { class: "quest-need" }, need),
        this._person === "all" && el("div", { class: "quest-people" }, progress.map(({ person, done }) => el("span", { class: `quest-person ${done === total ? "done" : ""}`, style: `--c:${this._colors[person.entry_id]}`, title: `${person.person}: ${done} of ${total} earned` }, this._marker(person)))))),
      `${event.name} ${zone.name || ""}`, () => this._showQuests(event.id));
  }

  _pageTiles(event) {
    const zones = this._zones(event);
    const active = zones.filter((zone) => zone.status.key === "active");
    return (active.length ? active : zones.slice(0, 1)).map((zone) => this._pageTile(event, zone));
  }

  _questsSection() {
    const events = this._data.quests || [];
    const current = (event) => event.quests
      .filter((quest) => this._questStatus(quest).key !== "ended")
      .sort((a, b) => this._questStatus(a).order - this._questStatus(b).order || Date.parse(a.end) - Date.parse(b.end));
    const allButton = el("button", { class: "text-button", type: "button", on: () => this._showQuests() }, "All quests ›");
    const section = (name, cards, extra) => el("section", { class: "quests", "aria-label": name },
      el("div", { class: "section-head" }, el("h2", {}, name), extra),
      el("div", { class: "quest-row" }, cards));
    const sections = events.filter((event) => !event.listed && !event.page).flatMap((event) => {
      const quests = current(event);
      return quests.length ? [section(event.name, quests.map((quest) => this._questCard(event, quest)))] : [];
    });
    const more = events.flatMap((event) => event.page ? this._pageTiles(event) : event.listed ? current(event).map((quest) => this._questCard(event, quest)) : []);
    if (more.length) sections.push(section("More from Stern", more));
    if (sections.length) sections[0].querySelector(".section-head").append(allButton);
    return sections;
  }

  _showQuests(groupId = null) {
    this._view = "quests";
    this._questTarget = groupId;
    this._render();
    const target = groupId && [...this.shadowRoot.querySelectorAll("[data-group]")].find((node) => node.dataset.group === groupId);
    (target || this.shadowRoot.querySelector(".quests-page"))?.scrollIntoView({ block: "start" });
  }

  _renderQuests() {
    const people = this._data.people;
    const needed = this._questFilter === "needed";
    const wanted = (quest) => !needed || quest.tracked === false || quest.owners.some((owner) => !owner.earned && (this._person === "all" || owner.entry_id === this._person));
    const sorted = (quests) => quests.filter((quest) => this._questStatus(quest).key !== "ended" && wanted(quest))
      .sort((a, b) => this._questStatus(a).order - this._questStatus(b).order || (a.order ?? 0) - (b.order ?? 0));
    const range = (event) => {
      const fmt = (value) => new Date(value).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" });
      return event.start && event.end && Number.isFinite(Date.parse(event.start)) && Number.isFinite(Date.parse(event.end)) && Date.parse(event.end) - Date.now() < 365 * 86400000 ? `${fmt(event.start)} – ${fmt(event.end)}` : "";
    };
    const groups = (this._data.quests || []).map((event) => {
      const blocks = event.page
        ? this._zones(event).map((zone) => {
          const quests = sorted(zone.quests);
          if (!quests.length) return null;
          const progress = this._zoneProgress(zone.quests);
          return el("div", { class: "zone" }, el("div", { class: "zone-head" }, el("h3", {}, zone.name || "Quests"), el("span", { class: `quest-state ${zone.status.key}` }, zone.status.label),
            el("span", { class: "zone-count" }, progress.length ? progress.map(({ person, done }) => `${person.person} ${done}/${zone.quests.length}`).join(" · ") : plural(zone.quests.length, "quest"))),
            el("div", { class: "quest-row" }, quests.map((quest) => this._questCard(event, quest))));
        }).filter(Boolean)
        : (() => { const quests = sorted(event.quests); return quests.length ? [el("div", { class: "quest-row" }, quests.map((quest) => this._questCard(event, quest)))] : []; })();
      if (!blocks.length) return null;
      const link = event.url && el("a", { class: "text-button", href: `https://insider.sternpinball.com${event.url}`, target: "_blank", rel: "noopener noreferrer" }, "Open on Stern ›");
      return el("section", { class: "quest-group", "data-group": event.id },
        el("div", { class: "group-head" }, el("div", {}, event.kicker && el("div", { class: "eyebrow" }, event.kicker), el("h2", {}, event.name), range(event) && el("div", { class: "muted" }, range(event))), link),
        event.description && el("p", { class: "group-desc" }, event.description), blocks);
    }).filter(Boolean);
    return [
      el("button", { class: "back-link", type: "button", on: () => { this._view = "home"; this._render(); if (this._stale) this._refresh(); } }, "‹ Games"),
      el("header", { class: "quests-page" }, el("div", { class: "eyebrow" }, "Stern Insider"), el("h1", {}, "Quests"), el("div", { class: "muted" }, "Every current and upcoming quest Stern lists. Ended quests are hidden.")),
      el("nav", { class: "toolbar", "aria-label": "Quest filters" },
        el("div", { class: "pills", role: "group", "aria-label": "Family member" }, el("button", { class: "pill", type: "button", "aria-pressed": String(this._person === "all"), on: () => { this._person = "all"; this._render(); } }, "Everyone"),
          people.map((person) => el("button", { class: "pill", type: "button", "aria-pressed": String(this._person === person.entry_id), on: () => { this._person = person.entry_id; this._render(); } }, person.person))),
        el("div", { class: "filters", role: "group", "aria-label": "Show" }, [["all", "All quests"], ["needed", "Still needed"]].map(([key, label]) =>
          el("button", { class: "filter", type: "button", "aria-pressed": String((this._questFilter || "all") === key), on: () => { this._questFilter = key; this._render(); } }, label)))),
      groups.length ? groups : el("div", { class: "empty" }, needed ? "Nothing left to earn right now." : "Stern isn't listing any current or upcoming quests.")
    ];
  }

  _selectedPeople() {
    return this._data.people.filter((person) => this._person === "all" || person.entry_id === this._person);
  }

  _suggestions() {
    const people = this._selectedPeople();
    const quests = (this._data.quests || []).flatMap((event) => event.quests.flatMap((quest) => {
      const status = this._questStatus(quest);
      if (status.key !== "active" || status.days === null || status.days > 14 || quest.tracked === false) return [];
      if (quest.zone && !(quest.titles || []).some((id) => people.some((person) => person.games.some((game) => game.title_id === id)))) return [];
      const owners = quest.owners.filter((owner) => !owner.earned && people.some((person) => person.entry_id === owner.entry_id));
      return owners.length ? [{ type: "quest", event, quest, owners, status }] : [];
    })).sort((a, b) => a.status.days - b.status.days).slice(0, 2);
    const perPerson = people.map((person) => {
      const games = person.games.filter((game) => game.total > 0 && game.open > 0).map((game) => {
        const target = [25, 50, 75, 100].find((value) => game.earned * 100 < value * game.total);
        return { type: "game", person, game, target, need: Math.ceil((target * game.total) / 100) - game.earned };
      }).sort((a, b) => a.need - b.need || b.game.percent - a.game.percent);
      const track = person.tracks.filter((item) => item.next && item.next > item.best).map((item) => ({ type: "track", person, track: item, need: item.next - item.best })).sort((a, b) => a.need - b.need)[0];
      return { games, track };
    });
    const picks = [...quests];
    const limit = 4;
    for (let round = 0; picks.length < limit && round < 3; round += 1) {
      for (const entry of perPerson) if (entry.games[round] && picks.length < limit) picks.push(entry.games[round]);
    }
    for (const entry of perPerson) if (entry.track && picks.length < limit) picks.push(entry.track);
    return picks.slice(0, limit);
  }

  _nextCard(item) {
    const gameArt = item.type === "game" ? this._games().find((game) => game.id === item.game.title_id)?.backglass : null;
    const image = safeImage(item.type === "quest" ? item.quest.image : gameArt);
    let kicker, title, detail, open, label;
    if (item.type === "quest") {
      kicker = item.owners.length === 1 ? `${item.owners[0].person} needs this` : `${item.owners.length} players need this`;
      title = item.quest.name;
      detail = item.status.label;
      open = () => this._openQuest(item.event, item.quest);
      label = title;
    } else if (item.type === "game") {
      kicker = item.person.person;
      title = item.game.game;
      detail = `${plural(item.need, "achievement")} from ${item.target}%`;
      open = () => this._openGame(item.game.title_id, item.person.entry_id);
      label = title;
    } else {
      kicker = item.person.person;
      title = item.track.name;
      detail = `${number(item.need)} to reach ${number(item.track.next)}`;
      open = () => this._navigate("badges");
      label = `${item.person.person} ${title}`;
    }
    return makeClickable(el("article", { class: `next-card ${item.type}-next` }, image ? el("img", { src: image, alt: "", loading: "lazy" }) : el("span", { class: "blank" }),
      el("div", {}, el("div", { class: "next-kicker" }, kicker), el("div", { class: "next-title" }, title), el("div", { class: "muted" }, detail))), label, open);
  }

  _keepPlaying() {
    const items = this._suggestions();
    return items.length ? el("section", { class: "keep-playing", "aria-label": "Keep playing" },
      el("div", { class: "section-head" }, el("h2", {}, "Keep playing"), el("span", { class: "muted" }, "Closest wins and deadlines")),
      el("div", { class: "next-row" }, items.map((item) => this._nextCard(item)))) : null;
  }

  _familyPanel() {
    return el("section", { class: "panel" }, el("h2", {}, "Family stats"), el("div", { class: "family" }, this._data.people.map((person) => {
      return el("article", { class: "person-card", style: `--c:${this._colors[person.entry_id]}` },
        el("div", { class: "who-line" }, el("span", { class: "avatar" }, this._marker(person)),
          el("span", {}, el("div", { class: "strong" }, person.person), el("div", { class: "muted" }, `${person.badge_count} badges · ${person.milestone_badge_count} milestones`))),
        el("div", { class: "mini-stats" }, [["XP", person.stats.xp], ["Plays", person.stats.plays], ["Achievements", person.stats.achievements]].map(([label, value]) =>
          el("span", {}, el("b", {}, number(value)), el("span", { class: "muted" }, label)))),
        person.tracks.map((track) => el("div", { class: "track" }, el("div", {}, el("span", {}, track.name), el("span", {}, track.next ? `${number(track.current)} / ${number(track.next)}` : "Complete")),
          el("span", { class: "meter" }, el("i", { style: `width:${track.percent}%` })))),
        el("div", { class: "badge-row" }, person.recent_badges.map((badge) => safeImage(badge.image) &&
          el("button", { type: "button", title: `View ${badge.name}`, "aria-label": `View ${badge.name}`, on: () => this._openBadge(badge.name) }, el("img", { src: safeImage(badge.image), alt: "", loading: "lazy" })))));
    })));
  }

  _scoreRows(machine) {
    return machine.scores.map((score) => el("div", { class: `score ${score.member ? "family-score" : ""}` }, el("span", {}, score.rank === 1 ? "👑" : score.rank - 1),
      el("span", {}, score.member ? `${score.initials || ""} · ${score.member}` : score.initials || score.user || "—"), el("span", {}, number(score.score))));
  }

  _scoresPanel() {
    return el("section", { class: "panel" }, el("h2", {}, "High scores"), el("div", { class: "score-grid" }, this._data.machines.map((machine) =>
      el("article", { class: "score-card" }, el("div", { class: "strong" }, machine.name), this._scoreRows(machine)))));
  }

  _mastheadFacts(people) {
    const achievements = people.reduce((sum, p) => sum + (p.stats.achievements || 0), 0);
    return el("div", { class: "totals" }, el("div", { class: "total" }, el("b", { style: "grid-column:1/-1" }, number(achievements)), el("span", { style: "grid-column:1/-1" }, "Achievements")));
  }

  _paintRefresh() {
    const busy = Boolean(this._updating || this._data?.refreshing);
    if (this._refreshButton) {
      this._refreshButton.disabled = busy;
      this._refreshButton.textContent = busy ? "Updating…" : "Refresh";
    }
    if (this._updatedLine) {
      const when = this._data?.updated ? new Date(this._data.updated) : null;
      const label = when && !Number.isNaN(when.getTime())
        ? `Updated ${when.toLocaleString(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}`
        : "";
      this._updatedLine.textContent = busy ? "Getting the latest from Stern…" : this._updateNote || label;
    }
  }

  async _updateNow() {
    if (this._updating || this._data?.refreshing) return;
    this._updating = true;
    this._updateNote = "";
    this._paintRefresh();
    try {
      const result = await this._hass.callWS({ type: `${DOMAIN}/refresh` });
      if (result.failed.length) this._updateNote = `Could not update ${result.failed.join(", ")}`;
    } catch (err) {
      this._updateNote = "Could not confirm the update. Try again in a few minutes.";
    }
    this._updating = false;
    await this._refresh();
    this._paintRefresh();
  }

  _viewMenu() {
    const sort = el("select", { class: "sort", "aria-label": "Sort games" }, [["progress", "Most progress"], ["open", "Most open"], ["name", "A to Z"]].map(([value, label]) => el("option", { value }, label)));
    sort.value = this._sort;
    sort.addEventListener("change", () => { this._sort = sort.value; this._fillGrid(); });
    const menu = el("details", { class: "view-menu" }, el("summary", { class: "summary-button" }, "View"),
      el("div", { class: "view-panel" }, el("label", {}, "Sort games", sort), this._switch("family", "Family stats"), this._switch("scores", "High scores")));
    menu.open = this._viewOpen;
    menu.addEventListener("toggle", () => { this._viewOpen = menu.open; });
    return menu;
  }

  _renderHome() {
    const people = this._data.people;
    const games = this._games();
    const feature = games.filter((game) => game.players.length).sort((a, b) => Math.max(...b.players.map((p) => p.game.percent)) - Math.max(...a.players.map((p) => p.game.percent))).find((game) => safeImage(game.backglass));
    const champion = this._champion();
    this._grid = el("div", { class: "games" });
    this._filterBar = el("div", { class: "filters", role: "group", "aria-label": "Filter games" });
    this._gamesCount = el("h2", {}, "Games");
    this._updatedLine = el("div", { class: "updated", role: "status" });
    this._refreshButton = el("button", { class: "summary-button refresh-button", type: "button", on: () => this._updateNow() }, "Refresh");
    this._paintRefresh();
    const masthead = el("header", { class: "masthead" }, feature && el("img", { class: "mast-art", src: safeImage(feature.backglass), alt: "" }),
      el("div", {}, el("div", { class: "eyebrow" }, "Stern Insider"), el("h1", {}, this._config.title || "Family Pinball"), champion && el("div", { class: "champ" }, "Reigning champ ", el("b", {}, champion)), this._updatedLine),
      this._mastheadFacts(this._selectedPeople()));
    const search = el("input", { class: "search", type: "search", placeholder: "Find a game", "aria-label": "Find a game", value: this._query });
    search.addEventListener("input", () => { this._query = search.value; this._fillGrid(); });
    const toolbar = el("nav", { class: "toolbar", "aria-label": "Dashboard controls" },
      el("div", { class: "toolbar-row primary" },
        el("div", { class: "nav-tabs" }, el("button", { class: "nav-tab", type: "button", "aria-current": "page" }, "Games"), el("button", { class: "nav-tab", type: "button", on: () => this._showQuests() }, "Quests"), el("button", { class: "nav-tab", type: "button", on: () => this._navigate("badges") }, "All badges"), el("button", { class: "nav-tab", type: "button", on: () => this._navigate("progress") }, "Game progress")),
        el("div", { class: "tools" }, search, this._refreshButton, this._viewMenu())),
      el("div", { class: "pills", role: "group", "aria-label": "Family member" }, el("button", { class: "pill", type: "button", "aria-pressed": String(this._person === "all"), on: () => { this._person = "all"; this._render(); } }, "Everyone"),
        people.map((person) => el("button", { class: "pill", type: "button", "aria-pressed": String(this._person === person.entry_id), on: () => { this._person = person.entry_id; this._render(); } }, person.person))));
    this._fillGrid();
    return [masthead, toolbar, this._keepPlaying(), this._questsSection(), this._show.family && this._familyPanel(), this._show.scores && this._scoresPanel(),
      el("section", { "aria-label": "Games" }, el("div", { class: "games-head" }, this._gamesCount, this._filterBar), this._grid)];
  }

  _fillGrid() {
    const games = this._visibleGames();
    const all = this._games().filter((game) => !this._query.trim() || game.name.toLowerCase().includes(this._query.trim().toLowerCase()));
    const filters = [["all", "All"], ["played", "Played"], ["unplayed", "Not played"], ["progress", "Has progress"], ["almost", "Almost complete"]];
    this._filterBar.replaceChildren(...filters.map(([key, label]) => el("button", {
      class: "filter", type: "button", "aria-pressed": String(this._gameFilter === key), on: () => { this._gameFilter = key; this._fillGrid(); }
    }, `${label} (${all.filter((game) => this._matchesFilter(game, key)).length})`)));
    this._gamesCount.textContent = `Games (${games.length})`;
    this._grid.replaceChildren(...(games.length ? games.map((game) => this._tile(game)) : [el("div", { class: "empty" }, "No games match these filters.")]));
  }

  _openGame(id, person = null) {
    this._gameId = id;
    this._detailPerson = person;
    this._tab = "achievements";
    this._render();
    this.scrollIntoView({ block: "start" });
  }

  _tabBody(game) {
    this._child = null;
    if (this._tab === "scores") {
      const machines = this._data.machines.filter((machine) => machine.name.toLowerCase() === game.name.toLowerCase());
      return machines.length ? el("div", { class: "score-grid" }, machines.map((machine) => el("article", { class: "score-card" }, el("div", { class: "strong" }, machine.name), this._scoreRows(machine))))
        : el("div", { class: "empty" }, "None of your machines have this game.");
    }
    if (!game.players.length) return el("div", { class: "empty" }, "No family member has achievements for this game yet.");
    const child = el(this._tab === "progress" ? "stern-progress-card" : "stern-achievements-card");
    child.setConfig({ game_id: game.id, person: this._detailPerson || (this._person === "all" ? undefined : this._person) });
    child.hass = this._hass;
    this._child = child;
    return child;
  }

  _renderGame(game) {
    const art = safeImage(game.backglass);
    const logo = safeImage(game.logo);
    const tabs = [["achievements", "Achievements"], game.hasProgress && ["progress", "Progress"], ["scores", "High scores"]].filter(Boolean);
    return [
      el("button", { class: "back-link", type: "button", on: () => { this._gameId = null; this._detailPerson = null; this._child = null; this._render(); if (this._stale) this._refresh(); } }, "‹ All games"),
      el("header", { class: "detail-hero" }, art && el("img", { class: "detail-glow", src: art, alt: "" }), art ? el("img", { class: "detail-art", src: art, alt: `${game.name} backglass` }) : el("div", {}),
        el("div", { class: "detail-copy" }, logo && el("img", { class: "logo", src: logo, alt: "" }), el("div", { class: "eyebrow" }, game.backglass_edition ? `${game.backglass_edition} backglass` : "Game"), el("h1", {}, game.name),
          game.players.length > 0 && el("div", { class: "family-summary" }, `Family: ${number(game.players.reduce((sum, p) => sum + p.game.earned, 0))} of ${number(game.players.reduce((sum, p) => sum + p.game.total, 0))} complete`),
          !game.players.length && el("div", { class: "champ" }, game.comingSoon ? "Coming soon" : "Not played yet"),
          game.players.map(({ person, game: played }) => el("div", { class: "player-line", style: `--c:${this._colors[person.entry_id]}` }, el("div", {}, el("span", {}, person.person), el("span", {}, `${played.earned}/${played.total}`)), el("span", { class: "meter" }, el("i", { style: `width:${played.percent}%` })))))),
      el("div", { class: "tabs", role: "tablist" }, tabs.map(([key, label]) => el("button", { class: "tab", type: "button", role: "tab", "aria-selected": String(this._tab === key), on: () => { this._tab = key; this._render(); } }, label))),
      el("section", { class: "tab-body" }, this._tabBody(game))
    ];
  }

  _render() {
    let content;
    if (this._error) content = el("div", { class: "message", role: "alert" }, el("h2", {}, "We couldn't load your games"), el("div", { class: "muted" }, "Check that Stern Insider Family is running, then try again."), el("button", { class: "retry", type: "button", on: () => this._load() }, "Try again"));
    else if (!this._data) content = [el("div", { class: "skeleton hero" }), el("div", { class: "skeleton bar" }), el("div", { class: "games", "aria-label": "Loading games" }, Array.from({ length: 8 }, () => el("div", { class: "skeleton game" })))];
    else if (!this._data.people.length) content = el("div", { class: "message" }, el("h2", {}, "Add your first player"), el("div", { class: "muted" }, "Go to Settings → Devices & services → Stern Insider Family."));
    else {
      const game = this._gameId && this._games().find((item) => item.id === this._gameId);
      content = game ? this._renderGame(game) : this._view === "quests" ? this._renderQuests() : this._renderHome();
    }
    this.shadowRoot.replaceChildren(el("style", {}, HOME_STYLE), el("ha-card", {}, el("main", { class: "home" }, content)));
  }
}

if (!customElements.get("stern-home-card")) {
  customElements.define("stern-home-card", SternHomeCard);
}

if (!customElements.get("stern-progress-card")) {
  customElements.define("stern-progress-card", SternProgressCard);
}

if (!customElements.get("stern-badges-card")) {
  customElements.define("stern-badges-card", SternBadgesCard);
}

if (!customElements.get("stern-achievements-card")) {
  customElements.define("stern-achievements-card", SternAchievementsCard);
}
window.customCards = window.customCards || [];
if (!window.customCards.some((card) => card.type === "stern-achievements-card")) {
  window.customCards.push({
    type: "stern-achievements-card",
    name: "Stern achievements",
    description: "Browse earned and open Stern achievements by game and family member."
  });
}
if (!window.customCards.some((card) => card.type === "stern-home-card")) {
  window.customCards.push({
    type: "stern-home-card",
    name: "Stern family home",
    description: "A game-first home page for the Stern family dashboard."
  });
}
if (!window.customCards.some((card) => card.type === "stern-progress-card")) {
  window.customCards.push({
    type: "stern-progress-card",
    name: "Stern game progress",
    description: "Browse Stern game progress pages by family member."
  });
}
if (!window.customCards.some((card) => card.type === "stern-badges-card")) {
  window.customCards.push({
    type: "stern-badges-card",
    name: "Stern badges",
    description: "Browse every Stern badge by family member."
  });
}
