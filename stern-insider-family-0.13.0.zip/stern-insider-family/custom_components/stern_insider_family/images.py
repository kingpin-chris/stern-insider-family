"""Keep Stern's expiring image links working between daily updates."""
from __future__ import annotations

import asyncio
from hashlib import sha256
import logging
import os
from pathlib import Path
import shutil
import time
from typing import Any
from urllib.parse import parse_qs, urlsplit

import aiohttp

from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .const import DOMAIN, IMAGE_URL

_LOGGER = logging.getLogger(__name__)
_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}
_HOSTS = (".amazonaws.com", ".cloudfront.net", ".sternpinball.io", ".sternpinball.com")
_MAX_BYTES = 5 * 1024 * 1024
_MAX_AGE = 30 * 24 * 3600  # Pick up artwork Stern replaces under the same name.
_TIMEOUT = aiohttp.ClientTimeout(total=30)


def _file_name(url: str) -> str | None:
    """Return the saved file name for an expiring Stern image link."""
    if "Signature=" not in url:
        return None
    parts = urlsplit(url)
    host = parts.hostname or ""
    extension = Path(parts.path).suffix.lower()
    query = parse_qs(parts.query)
    if (
        parts.scheme != "https"
        or not host.endswith(_HOSTS)
        or extension not in _EXTENSIONS
        or not ({"Signature", "X-Amz-Signature"} & query.keys())
    ):
        return None
    # The signature changes daily, so only the image's address identifies it.
    return sha256(f"{host}{parts.path}".encode()).hexdigest()[:32] + extension


def _links(value: Any) -> set[str]:
    if isinstance(value, str):
        return {value} if _file_name(value) else set()
    if isinstance(value, dict):
        value = value.values()
    elif not isinstance(value, list):
        return set()
    return {link for item in value for link in _links(item)}


class ImageCache:
    """Save images once and serve them from Home Assistant."""

    def __init__(self, hass: HomeAssistant) -> None:
        self._hass = hass
        cache = Path(hass.config.path(".cache", DOMAIN))
        self.directory = cache / "badge-images"
        self._damaged = cache / "images"  # Version 0.12.0 could save partial files.
        self._files: dict[str, float] = {}
        self._active: set[str] = set()

    def _scan(self) -> dict[str, float]:
        shutil.rmtree(self._damaged, ignore_errors=True)
        self.directory.mkdir(parents=True, exist_ok=True)
        return {
            path.name: path.stat().st_mtime
            for path in self.directory.iterdir()
            if path.is_file() and not path.name.startswith(".")
        }

    async def async_load(self) -> None:
        """Find images saved by earlier runs."""
        self._files = await self._hass.async_add_executor_job(self._scan)

    def localize(self, value: Any) -> Any:
        """Replace expiring links that have a saved copy."""
        if isinstance(value, str):
            name = _file_name(value)
            return f"{IMAGE_URL}/{name}" if name in self._files else value
        if isinstance(value, dict):
            return {key: self.localize(item) for key, item in value.items()}
        if isinstance(value, list):
            return [self.localize(item) for item in value]
        return value

    def _write(self, name: str, body: bytes) -> float:
        target = self.directory / name
        temporary = self.directory / f".{name}.tmp"
        temporary.write_bytes(body)
        os.replace(temporary, target)
        return target.stat().st_mtime

    async def _save(self, name: str, url: str) -> bool:
        try:
            async with async_get_clientsession(self._hass).get(
                url, timeout=_TIMEOUT, allow_redirects=False
            ) as resp:
                kind = resp.headers.get("Content-Type", "")
                if resp.status != 200 or not kind.startswith("image/") or "svg" in kind:
                    return False
                body = bytearray()
                async for chunk in resp.content.iter_chunked(65536):
                    body.extend(chunk)
                    if len(body) > _MAX_BYTES:
                        return False
        except (aiohttp.ClientError, asyncio.TimeoutError) as err:
            _LOGGER.debug("Could not save a Stern image: %s", type(err).__name__)
            return False
        if not body:
            return False
        self._files[name] = await self._hass.async_add_executor_job(
            self._write, name, bytes(body)
        )
        return True

    async def async_store(self, data: Any) -> bool:
        """Save new images and return True if the dashboard can use any."""
        now = time.time()
        wanted = {
            name: url
            for url in _links(data)
            if (name := _file_name(url))
            and name not in self._active
            and now - self._files.get(name, 0) >= _MAX_AGE
        }
        if not wanted:
            return False
        new = set(wanted) - set(self._files)
        self._active.update(wanted)
        limit = asyncio.Semaphore(4)

        async def save(name: str, url: str) -> tuple[str, bool]:
            async with limit:
                return name, await self._save(name, url)

        try:
            results = await asyncio.gather(*(save(n, u) for n, u in wanted.items()))
        finally:
            self._active.difference_update(wanted)
        return any(saved and name in new for name, saved in results)
