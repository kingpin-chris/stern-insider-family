"""Data coordinator for one Stern Insider account."""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import datetime, time, timedelta, tzinfo
from hashlib import sha256
import logging
import time as monotonic_time
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.dispatcher import async_dispatcher_send
from homeassistant.helpers.event import async_track_point_in_utc_time
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed
from homeassistant.util import dt as dt_util

from .api import SternApiError, SternAuthError, SternClient
from .const import (
    CONF_DISPLAY_NAME,
    CONF_REFRESH_TOKEN,
    DETAIL_CONCURRENCY,
    DETAIL_MAX_AGE,
    DOMAIN,
    EVENT_NEW_BADGE,
    EVENT_NEW_HIGH_SCORE,
    HIGH_SCORE_COUNT,
    PROGRESS_RECHECK,
    QUEST_PAGE_MAX_AGE,
    SIGNAL_UPDATED,
    UPDATE_HOUR,
    UPDATE_RETRY_SECONDS,
    UPDATE_SPREAD_MINUTES,
    UPDATE_TIME_ZONE,
)
from .parsers import (
    SternParseError,
    build_quest_groups,
    build_tracks,
    find_avatar,
    flight_text,
    parse_achievements,
    parse_badges,
    parse_game_catalog,
    parse_game_achievements,
    parse_game_backglass,
    parse_game_progress,
    parse_high_scores,
    parse_machines,
    parse_profile,
    parse_quest_cards,
    parse_quest_event_ids,
)
from .quest_pages import (
    build_page_groups,
    is_quest_page,
    parse_action_id,
    parse_chunk_paths,
    parse_cms_access,
    parse_quest_page_rows,
    parse_user_badges,
)

_LOGGER = logging.getLogger(__name__)
_ERRORS = (SternApiError, SternParseError)


def next_daily_update(now: datetime, zone: tzinfo, minute: int) -> datetime:
    """Return the next scheduled update time in UTC."""
    local = now.astimezone(zone)
    target = datetime.combine(local.date(), time(UPDATE_HOUR, minute), zone)
    if target <= local:
        target = datetime.combine(
            local.date() + timedelta(days=1), time(UPDATE_HOUR, minute), zone
        )
    return dt_util.as_utc(target)


class SternCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Fetch one person's profile and any machines this entry looks after."""

    config_entry: ConfigEntry

    def __init__(
        self, hass: HomeAssistant, entry: ConfigEntry, client: SternClient
    ) -> None:
        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=f"{DOMAIN}_{entry.entry_id}",
            update_interval=None,
        )
        self.client = client
        self.last_updated: datetime | None = None
        self._update_lock = asyncio.Lock()
        self._cancel_daily: Callable[[], None] | None = None
        self._zone: tzinfo = dt_util.DEFAULT_TIME_ZONE
        digest = sha256(entry.entry_id.encode()).digest()
        self._minute = digest[0] % UPDATE_SPREAD_MINUTES

    @property
    def person(self) -> str:
        """Name shown for this account."""
        return self.config_entry.data.get(CONF_DISPLAY_NAME) or self.config_entry.title

    async def async_start_daily_updates(self) -> Callable[[], None]:
        """Start the daily schedule and return its cancel function."""
        self._zone = await dt_util.async_get_time_zone(UPDATE_TIME_ZONE) or self._zone
        self._schedule_daily()

        def cancel() -> None:
            if self._cancel_daily:
                self._cancel_daily()
                self._cancel_daily = None

        return cancel

    def _schedule_daily(self, retry: bool = False) -> None:
        now = dt_util.utcnow()
        when = next_daily_update(now, self._zone, self._minute)
        if retry:
            when = min(when, now + timedelta(seconds=UPDATE_RETRY_SECONDS))
        self._cancel_daily = async_track_point_in_utc_time(
            self.hass, self._daily_update, when
        )

    async def _daily_update(self, _now: datetime) -> None:
        self._cancel_daily = None
        await self.async_refresh()
        self._schedule_daily(
            not self.last_update_success
            and not isinstance(self.last_exception, ConfigEntryAuthFailed)
        )

    async def _access_token(self) -> str:
        entry = self.config_entry
        try:
            tokens = await self.client.refresh(entry.data[CONF_REFRESH_TOKEN])
        except SternAuthError as err:
            raise ConfigEntryAuthFailed("Stern sign-in has expired") from err
        except SternApiError as err:
            raise UpdateFailed(str(err)) from err
        # Stern retires the old refresh token, so save the new one first.
        self.hass.config_entries.async_update_entry(
            entry, data={**entry.data, CONF_REFRESH_TOKEN: tokens.refresh_token}
        )
        return tokens.access_token

    async def _fetch_player(self, token: str, old: dict[str, Any]) -> dict[str, Any]:
        player = dict(old)
        errors: list[str] = []
        try:
            text = flight_text(await self.client.badges_page(token))
            profile = parse_profile(text)
            badges = parse_badges(text)
            if not profile.get("avatar_url"):
                try:
                    profile["avatar_url"] = find_avatar(await self.client.user_detail(token))
                except _ERRORS as err:
                    _LOGGER.debug("Could not read avatar: %s", err)
            player.update(profile=profile, badges=badges)
            player["tracks"] = build_tracks(profile, badges)
        except _ERRORS as err:
            errors.append(f"badges: {err}")
        try:
            body = await self.client.achievements_page(token)
            player["games"] = parse_achievements(body)
        except _ERRORS as err:
            errors.append(f"achievements: {err}")
        player["errors"] = errors
        for error in errors:
            _LOGGER.warning("%s: could not update %s", self.person, error)
        return player

    async def _fetch_details(self, token: str, player: dict[str, Any]) -> None:
        """Refresh per-game achievements that changed or have old image links."""
        old: dict[str, Any] = player.get("details", {})
        now = dt_util.utcnow().timestamp()
        limit = asyncio.Semaphore(DETAIL_CONCURRENCY)

        def stale(game: dict[str, Any]) -> bool:
            known = old.get(game["title_id"])
            return (
                not known
                or now - known["fetched"] >= DETAIL_MAX_AGE
                or any(known[k] != game[k] for k in ("earned", "total", "xp"))
            )

        async def load(game: dict[str, Any]) -> tuple[str, dict[str, Any] | None]:
            async with limit:
                try:
                    page = await self.client.game_achievements_page(
                        token, game["title_id"]
                    )
                    text = flight_text(page)
                    groups = parse_game_achievements(text)
                    backglass = parse_game_backglass(text)
                except _ERRORS as err:
                    _LOGGER.debug("Details failed for %s: %s", game["game"], err)
                    return game["title_id"], None
            return game["title_id"], {
                "fetched": now,
                "earned": game["earned"],
                "total": game["total"],
                "xp": game["xp"],
                "groups": groups,
                "backglass": backglass,
            }

        games = player.get("games", [])
        player["changed_titles"] = [
            game["title_id"]
            for game in games
            if game["title_id"] in old
            and any(old[game["title_id"]][k] != game[k] for k in ("earned", "total", "xp"))
        ]
        results = await asyncio.gather(*(load(g) for g in games if stale(g)))
        current = {g["title_id"] for g in games}
        details = {k: v for k, v in old.items() if k in current}
        failed = 0
        for title_id, detail in results:
            if detail:
                details[title_id] = detail
            else:
                failed += 1
        player["details"] = details
        if failed:
            message = f"game details: {failed} games could not be read"
            player["errors"] = [*player.get("errors", []), message]
            _LOGGER.warning("%s: %s", self.person, message)

    async def _fetch_quests(self, token: str, player: dict[str, Any]) -> None:
        """Refresh every quest group Stern lists, keeping good data on errors."""
        previous = {event["id"]: event for event in player.get("quests", [])}
        try:
            page = await self.client.quests_page(token)
            text = flight_text(page)
            cards = parse_quest_cards(text)
            event_ids = parse_quest_event_ids(page)
            if not cards and not event_ids and "View Past Quests" not in text:
                raise SternParseError("quest list not found")
        except _ERRORS as err:
            self._quest_problem(player, str(err))
            return
        results = await asyncio.gather(
            *(self.client.quest_event(token, event_id) for event_id in event_ids),
            return_exceptions=True,
        )
        payloads: dict[str, dict[str, Any]] = {}
        failed = 0
        for event_id, result in zip(event_ids, results, strict=True):
            if isinstance(result, _ERRORS):
                failed += 1
            elif isinstance(result, BaseException):
                raise result
            else:
                payloads[event_id] = result
        groups = build_quest_groups(
            cards, event_ids, payloads, previous, player.get("badges", [])
        )
        pages = await self._quest_pages(token, cards, player)
        if pages is not None:
            by_id = {group["id"]: group for group in pages}
            groups = [by_id.pop(group["id"], group) for group in groups]
            groups.extend(by_id.values())
        player["quests"] = groups
        if failed:
            self._quest_problem(player, f"{failed} quest groups could not be read")

    async def _quest_pages(
        self, token: str, cards: list[dict[str, Any]], player: dict[str, Any]
    ) -> list[dict[str, Any]] | None:
        """Read every quest on Stern's quest pages, or None to keep the tiles."""
        shared: dict[str, Any] = self.hass.data[DOMAIN].setdefault("quest_pages", {})
        paths = [card["path"] for card in cards if is_quest_page(card["path"])]
        try:
            rows = await self._quest_rows(token, paths, shared)
        except _ERRORS as err:
            self._quest_problem(player, f"quest pages: {err}")
            return None
        if rows is None:
            return None
        try:
            earned = await self._earned_quest_badges(token, shared)
            player["quest_badges"] = earned
        except _ERRORS as err:
            self._quest_problem(player, f"earned quest badges: {err}")
            earned = player.get("quest_badges")
        return build_page_groups(
            rows, cards, player.get("catalog", []), earned, dt_util.utcnow()
        )

    async def _quest_rows(
        self, token: str, paths: list[str], shared: dict[str, Any]
    ) -> list[dict[str, Any]] | None:
        now = monotonic_time.monotonic()
        if "rows" in shared and now - shared["fetched"] < QUEST_PAGE_MAX_AGE:
            return shared["rows"]
        if not paths:
            return shared.get("rows")
        try:
            html = await self.client.quest_page(token, paths[0])
            access = parse_cms_access(html)
            rows = parse_quest_page_rows(await self.client.quest_pages(*access))
        except _ERRORS:
            if "rows" in shared:
                _LOGGER.debug("Using the last quest pages")
                return shared["rows"]
            raise
        chunks = parse_chunk_paths(html)
        if chunks != shared.get("chunks"):
            shared.pop("action", None)
        shared.update(rows=rows, fetched=now, chunks=chunks, page=paths[0])
        return rows

    async def _earned_quest_badges(
        self, token: str, shared: dict[str, Any]
    ) -> dict[str, str | None]:
        page = shared.get("page")
        if not page:
            raise SternParseError("no quest page")
        for attempt in range(2):
            action = shared.get("action") or await self._find_badge_action(shared)
            try:
                text = await self.client.earned_quest_badges(token, page, action)
                return parse_user_badges(text)
            except _ERRORS:
                shared.pop("action", None)
                if attempt:
                    raise
        raise SternParseError("earned quest badges not found")

    async def _find_badge_action(self, shared: dict[str, Any]) -> str:
        for path in shared.get("chunks", []):
            try:
                action = parse_action_id(await self.client.page_script(path))
            except SternApiError:
                continue
            if action:
                shared["action"] = action
                return action
        raise SternParseError("earned quest badge request not found")

    def _quest_problem(self, player: dict[str, Any], message: str) -> None:
        """Record a quest problem without hiding the last good quests."""
        player["errors"] = [*player.get("errors", []), f"quests: {message}"]
        _LOGGER.warning("%s: could not update quests: %s", self.person, message)

    async def _fetch_progress(self, token: str, player: dict[str, Any]) -> None:
        """Refresh games with progress pages and look for new ones."""
        progress: dict[str, Any] = dict(player.get("progress", {}))
        checked: dict[str, float] = dict(player.get("progress_checked", {}))
        now = dt_util.utcnow().timestamp()
        limit = asyncio.Semaphore(DETAIL_CONCURRENCY)

        async def load(game: dict[str, Any]) -> None:
            title_id = game["title_id"]
            async with limit:
                try:
                    page = await self.client.game_progress_page(token, title_id)
                    blocks = parse_game_progress(flight_text(page))
                except _ERRORS as err:
                    _LOGGER.debug("Progress failed for %s: %s", game["game"], err)
                    return
            checked[title_id] = now
            if blocks:
                progress[title_id] = blocks
            else:
                progress.pop(title_id, None)

        games = player.get("games", [])
        changed = set(player.get("changed_titles", []))
        await asyncio.gather(
            *(
                load(game)
                for game in games
                if game["title_id"] in progress
                or game["title_id"] in changed
                or now - checked.get(game["title_id"], 0) >= PROGRESS_RECHECK
            )
        )
        current = {game["title_id"] for game in games}
        player["progress"] = {k: v for k, v in progress.items() if k in current}
        player["progress_checked"] = {k: v for k, v in checked.items() if k in current}

    async def _fetch_machines(
        self, token: str, old: dict[str, Any]
    ) -> tuple[dict[str, Any], bool]:
        try:
            listed = parse_machines(await self.client.machines(token))
        except _ERRORS as err:
            _LOGGER.warning("%s: could not update machines: %s", self.person, err)
            return old, False

        owners: dict[str, str] = self.hass.data[DOMAIN]["machine_owners"]
        mine = [
            m
            for m in listed
            if owners.setdefault(m["id"], self.config_entry.entry_id)
            == self.config_entry.entry_id
        ]
        limit = asyncio.Semaphore(3)

        async def load(machine: dict[str, Any]) -> dict[str, Any]:
            previous = old.get(machine["id"], {}).get("scores", [])
            async with limit:
                try:
                    payload = await self.client.high_scores(token, machine["id"])
                    scores = parse_high_scores(payload, HIGH_SCORE_COUNT)
                except _ERRORS as err:
                    _LOGGER.debug("Scores failed for %s: %s", machine["name"], err)
                    scores = previous
            return {**machine, "scores": scores}

        loaded = await asyncio.gather(*(load(m) for m in mine))
        return {m["id"]: m for m in loaded}, True

    def _fire_events(self, old: dict[str, Any], new: dict[str, Any]) -> None:
        if not old:
            return
        before = {
            b["name"] for b in old["player"].get("badges", []) if b["earned"]
        }
        if before:
            for badge in new["player"].get("badges", []):
                if badge["earned"] and badge["name"] not in before:
                    self.hass.bus.async_fire(
                        EVENT_NEW_BADGE,
                        {
                            "person": self.person,
                            "badge": badge["name"],
                            "date": badge["date"],
                        },
                    )
        for machine_id, machine in new["machines"].items():
            previous = old["machines"].get(machine_id)
            if not previous:
                continue
            was = {s["rank"]: (s["score"], s["player_id"]) for s in previous["scores"]}
            for score in machine["scores"]:
                if was.get(score["rank"]) == (score["score"], score["player_id"]):
                    continue
                if (score["score"], score["player_id"]) in was.values():
                    continue  # Same score moved down the table.
                self.hass.bus.async_fire(
                    EVENT_NEW_HIGH_SCORE,
                    {
                        "machine_id": machine_id,
                        "machine_name": machine["name"],
                        "rank": score["rank"],
                        "score": score["score"],
                        "player_username": score["player_username"],
                        "player_initials": score["player_initials"],
                    },
                )

    async def _save_images(self, data: dict[str, Any]) -> None:
        if await self.hass.data[DOMAIN]["images"].async_store(data):
            async_dispatcher_send(self.hass, SIGNAL_UPDATED)

    async def _async_update_data(self) -> dict[str, Any]:
        # Stern replaces the sign-in token, so updates must never overlap.
        async with self._update_lock:
            return await self._update()

    async def _update(self) -> dict[str, Any]:
        old = self.data or {}
        token = await self._access_token()
        player = await self._fetch_player(token, old.get("player", {}))
        machines, machines_ok = await self._fetch_machines(
            token, old.get("machines", {})
        )
        if "profile" not in player and not machines_ok:
            raise UpdateFailed("Stern profile and machine data are unavailable")
        try:
            page = await self.client.games_page(token)
            player["catalog"] = parse_game_catalog(flight_text(page))
        except _ERRORS as err:
            _LOGGER.debug("Could not update the game list: %s", err)
        await self._fetch_quests(token, player)
        await self._fetch_details(token, player)
        await self._fetch_progress(token, player)
        new = {"player": player, "machines": machines}
        self._fire_events(old, new)
        self.last_updated = dt_util.utcnow()
        self.config_entry.async_create_background_task(
            self.hass, self._save_images(new), f"{DOMAIN} images"
        )
        return new
