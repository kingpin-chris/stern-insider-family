"""Config flow: each person signs in at Stern and pastes the result."""
from __future__ import annotations

from typing import Any

import voluptuous as vol

from homeassistant.config_entries import (
    ConfigFlow,
    ConfigFlowResult,
)
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.helpers.selector import (
    TextSelector,
    TextSelectorConfig,
    TextSelectorType,
)

from .api import (
    CallbackError,
    SternApiError,
    SternAuthError,
    SternClient,
    Tokens,
    authorize_url,
    code_from_callback,
    new_pkce,
    token_subject,
)
from .const import (
    CONF_CALLBACK_URL,
    CONF_DISPLAY_NAME,
    CONF_REFRESH_TOKEN,
    CONF_USER_ID,
    DOMAIN,
)
from .parsers import SternParseError, flight_text, parse_profile

_URL = TextSelector(TextSelectorConfig(type=TextSelectorType.URL))


class SternConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle adding and re-authorising a Stern account."""

    VERSION = 1

    def __init__(self) -> None:
        self._verifier = ""
        self._challenge = ""
        self._state = ""

    def _new_sign_in(self) -> None:
        self._verifier, self._challenge, self._state = new_pkce()

    async def _tokens(
        self, pasted: str, errors: dict[str, str]
    ) -> Tokens | None:
        client = SternClient(async_get_clientsession(self.hass))
        try:
            code = code_from_callback(pasted, self._state)
        except CallbackError as err:
            errors[CONF_CALLBACK_URL] = str(err)
            return None
        try:
            return await client.exchange_code(code, self._verifier)
        except SternAuthError:
            errors["base"] = "code_expired"
        except SternApiError:
            errors["base"] = "cannot_connect"
        self._new_sign_in()
        return None

    async def _username(self, tokens: Tokens) -> str | None:
        client = SternClient(async_get_clientsession(self.hass))
        try:
            page = await client.badges_page(tokens.access_token)
            return parse_profile(flight_text(page)).get("username")
        except (SternApiError, SternParseError):
            return None

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Show the sign-in link and accept the pasted address."""
        errors: dict[str, str] = {}
        if not self._verifier:
            self._new_sign_in()
        if user_input is not None:
            tokens = await self._tokens(user_input[CONF_CALLBACK_URL], errors)
            if tokens:
                subject = token_subject(tokens.access_token)
                if not subject:
                    errors["base"] = "cannot_connect"
                else:
                    await self.async_set_unique_id(subject)
                    self._abort_if_unique_id_configured()
                    name = (user_input.get(CONF_DISPLAY_NAME) or "").strip()
                    title = name or await self._username(tokens) or "Stern player"
                    return self.async_create_entry(
                        title=title,
                        data={
                            CONF_USER_ID: subject,
                            CONF_DISPLAY_NAME: title,
                            CONF_REFRESH_TOKEN: tokens.refresh_token,
                        },
                    )
        return self.async_show_form(
            step_id="user",
            data_schema=vol.Schema(
                {
                    vol.Optional(CONF_DISPLAY_NAME): str,
                    vol.Required(CONF_CALLBACK_URL): _URL,
                }
            ),
            errors=errors,
            description_placeholders={
                "auth_url": authorize_url(self._challenge, self._state)
            },
        )

    async def async_step_reauth(
        self, entry_data: dict[str, Any]
    ) -> ConfigFlowResult:
        """Start again when Stern no longer accepts the saved sign-in."""
        self._new_sign_in()
        return await self.async_step_reauth_confirm()

    async def async_step_reauth_confirm(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Sign the same person in again."""
        errors: dict[str, str] = {}
        entry = self._get_reauth_entry()
        if user_input is not None:
            tokens = await self._tokens(user_input[CONF_CALLBACK_URL], errors)
            if tokens:
                await self.async_set_unique_id(token_subject(tokens.access_token))
                self._abort_if_unique_id_mismatch(reason="wrong_account")
                return self.async_update_reload_and_abort(
                    entry,
                    data={**entry.data, CONF_REFRESH_TOKEN: tokens.refresh_token},
                )
        return self.async_show_form(
            step_id="reauth_confirm",
            data_schema=vol.Schema({vol.Required(CONF_CALLBACK_URL): _URL}),
            errors=errors,
            description_placeholders={
                "name": entry.title,
                "auth_url": authorize_url(self._challenge, self._state),
            },
        )
