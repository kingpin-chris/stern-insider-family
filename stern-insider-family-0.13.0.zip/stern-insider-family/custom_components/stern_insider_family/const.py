"""Constants for Stern Insider Family."""

DOMAIN = "stern_insider_family"

PROJECT_ID = "P3HEU9eRz5zrjI8c28n88adIDzyI"
CLIENT_ID = PROJECT_ID
AUTH_BASE = "https://auth.sternpinball.com"
AUTHORIZE_URL = f"{AUTH_BASE}/oauth2/v1/{PROJECT_ID}/authorize"
TOKEN_URL = f"{AUTH_BASE}/oauth2/v1/{PROJECT_ID}/token"
INSIDER_BASE = "https://insider.sternpinball.com"
REDIRECT_URI = f"{INSIDER_BASE}/auth/callback"
CMS_BASE = "https://cms.prd.sternpinball.io/api/v1/portal"
API_BASE = "https://api.prd.sternpinball.io/api/v1/portal"
CMS_DATA_BASE = "https://data.plasmic.app/api/v1/cms/databases"
API_V2_BASE = "https://api.prd.sternpinball.io/api/v2/portal"
TOKEN_COOKIE = "spb-insider-token"
USER_AGENT = "HomeAssistant-SternInsiderFamily/0.1"

CONF_REFRESH_TOKEN = "refresh_token"
CONF_USER_ID = "user_id"
CONF_DISPLAY_NAME = "display_name"
CONF_CALLBACK_URL = "callback_url"

UPDATE_TIME_ZONE = "America/Chicago"
UPDATE_HOUR = 3
UPDATE_SPREAD_MINUTES = 15  # Accounts start at different minutes.
UPDATE_RETRY_SECONDS = 3600
QUEST_PAGE_MAX_AGE = 3600  # Shared by every account in one update.
HIGH_SCORE_COUNT = 5
RECENT_BADGES = 12
DETAIL_CONCURRENCY = 2
PROGRESS_RECHECK = 23 * 3600  # Checked at each daily update.
DETAIL_MAX_AGE = 11 * 3600  # Daily updates reread every played game.
CARD_FILE = "stern-achievements-card.js"
CARD_URL = f"/{DOMAIN}/{CARD_FILE}"
IMAGE_URL = f"/{DOMAIN}/badge-images"
VERSION = "0.13.0"

SIGNAL_UPDATED = f"{DOMAIN}_updated"
EVENT_NEW_HIGH_SCORE = f"{DOMAIN}_new_high_score"
EVENT_NEW_BADGE = f"{DOMAIN}_new_badge"
