"""Quest pages, such as tours and Learn & Earn quests, from Stern's content service."""
from __future__ import annotations

from datetime import datetime
import json
import re
from typing import Any

from homeassistant.util import dt as dt_util

from .parsers import SternParseError, _image, _value

_ACCESS_RE = re.compile(
    r'databaseId:\\?"([A-Za-z0-9]{10,40})\\?",databaseToken:[^,]{0,160}?'
    r'databaseToken:\\?"([A-Za-z0-9]{20,200})\\?"'
)
_TABLE_RE = re.compile(r'table:\\?"([A-Za-z][A-Za-z0-9_]{0,60})\\?"')
_CHUNK_RE = re.compile(r"/_next/static/chunks/[A-Za-z0-9_.~-]+\.js")
_ACTION_RE = re.compile(
    r'createServerReference\)?\(\s*"([0-9a-f]{40,44})"[^;]{0,200}?"getUserBadges"\)'
)
_PAGE_PATH_RE = re.compile(r"^/ic-quests/[a-z0-9-]+$")
DEFAULT_TABLE = "godzillaQuest"


def parse_cms_access(html: str) -> tuple[str, str, str]:
    """Return the content-service database, its page key and the quest table."""
    match = _ACCESS_RE.search(html)
    if not match:
        raise SternParseError("quest page key not found")
    table = _TABLE_RE.search(html)
    return match.group(1), match.group(2), table.group(1) if table else DEFAULT_TABLE


def parse_chunk_paths(html: str) -> list[str]:
    """Return script files the quest page loads."""
    return list(dict.fromkeys(_CHUNK_RE.findall(html)))


def parse_action_id(script: str) -> str | None:
    """Return the id of the page's earned-badge request, if in this script."""
    match = _ACTION_RE.search(script)
    return match.group(1) if match else None


def parse_user_badges(text: str) -> dict[str, str | None]:
    """Return earned badge ids and dates. Locations and links are dropped."""
    for line in text.splitlines():
        _, sep, body = line.partition(":")
        if not sep or not body.startswith("["):
            continue
        try:
            rows = json.loads(body)
        except ValueError:
            continue
        if not all(isinstance(row, dict) and "badge_id" in row for row in rows):
            continue
        earned = {}
        for row in rows:
            if row.get("badge_id") is None:
                continue
            date = _value(row.get("date_awarded"))
            earned[str(row["badge_id"])] = (
                date.replace(" ", "T", 1) if isinstance(date, str) else None
            )
        return earned
    raise SternParseError("earned quest badges not found")


def parse_quest_page_rows(payload: Any) -> list[dict[str, Any]]:
    """Return the quest-page rows from the content service."""
    rows = payload.get("rows") if isinstance(payload, dict) else None
    if not isinstance(rows, list):
        raise SternParseError("quest pages not found")
    return [
        {**row["data"], "identifier": row.get("identifier") or row["data"].get("identifier")}
        for row in rows
        if isinstance(row, dict) and isinstance(row.get("data"), dict)
    ]


def _key(text: Any) -> str:
    words = re.sub(r"[^a-z0-9]+", "", str(text or "").lower())
    return words[3:] if words.startswith("the") else words


def _stem(url_or_name: Any) -> str:
    name = str(url_or_name or "").split("?")[0].rsplit("/", 1)[-1].rsplit(".", 1)[0]
    return re.sub(r"\d+$", "", _key(name))


def _date(value: Any) -> datetime | None:
    return dt_util.parse_datetime(value) if isinstance(value, str) else None


_STOP = {"the", "of", "and", "a", "an", "in", "on", "to", "play", "make"}


def _words(text: Any) -> set[str]:
    words = re.findall(r"[a-z0-9]+", str(text or "").lower())
    return {word[:-1] if len(word) > 3 and word.endswith("s") else word for word in words if len(word) > 1 and word not in _STOP}


def _titles(catalog: list[dict[str, Any]], *texts: Any, loose: bool = False) -> list[str]:
    games = [(game["title_id"], _key(game["game"])) for game in catalog if _key(game.get("game"))]
    for text in texts:
        key = _key(text)
        if not key:
            continue
        exact = [title for title, name in games if name == key]
        if exact:
            return exact
    for text in texts:
        key = _key(text)
        found = [title for title, name in games if len(name) >= 4 and name in key]
        if found:
            # Prefer the longest name, e.g. "Jurassic Park Home Edition".
            return [max(found, key=lambda title: len(dict(games)[title]))]
    if not loose or not texts:
        return []
    # Names on quest pages differ slightly, e.g. "Swords" or "Elvira House".
    wanted = _words(texts[0])
    scored = []
    for game in catalog:
        words = _words(game.get("game"))
        common = len(wanted & words)
        if common and common == min(len(wanted), len(words)):
            scored.append((common, -len(words), game["title_id"]))
    return [max(scored)[2]] if scored else []


def _help(badge: dict[str, Any]) -> list[dict[str, Any]]:
    slides = []
    for item in badge.get("questHelpGuide") or []:
        slide = item.get("questHelpSlide") if isinstance(item, dict) else None
        if not isinstance(slide, dict):
            continue
        image = slide.get("helpImage")
        slides.append(
            {
                "title": slide.get("slideTitle") or slide.get("Slide Title") or "",
                "text": slide.get("helpText") or "",
                "image": _image(image.get("url") if isinstance(image, dict) else None),
            }
        )
    return slides


def _match_card(row: dict[str, Any], cards: list[dict[str, Any]]) -> dict[str, Any] | None:
    names = {_key(row.get("identifier")), _key(row.get("title"))} - {""}
    for card in cards:
        if card["path"].startswith("/ic-quests/") and _key(card["name"]) in names:
            return card
    stems = {
        _stem((badge.get("badge") or {}).get("badgeImage", {}).get("name"))
        for zone in row.get("zones") or []
        for badge in (zone.get("zone") or {}).get("badges") or []
        if isinstance(badge, dict)
    } - {""}
    best, overlap = None, 0
    for card in cards:
        count = len(stems & {_stem(badge["image"]) for badge in card["badges"]})
        if count > overlap:
            best, overlap = card, count
    return best


def build_page_groups(
    rows: list[dict[str, Any]],
    cards: list[dict[str, Any]],
    catalog: list[dict[str, Any]],
    earned: dict[str, str | None] | None,
    now: datetime,
) -> list[dict[str, Any]]:
    """Turn quest pages into quest groups with every current and upcoming quest."""
    groups = []
    for row in rows:
        end = _date(row.get("endDate"))
        if end and end <= now:
            continue
        card = _match_card(row, cards)
        name = (card or {}).get("name") or row.get("identifier") or row.get("title") or "Quest"
        group_id = card["id"] if card else f"page-{_key(name)}"
        page_titles = _titles(catalog, row.get("identifier"), row.get("title"))
        quests = []
        for zone_index, item in enumerate(row.get("zones") or []):
            zone = item.get("zone") if isinstance(item, dict) else None
            if not isinstance(zone, dict):
                continue
            zone_end = _date(zone.get("zoneEndDate"))
            if zone_end and zone_end <= now:
                continue
            for badge_index, entry in enumerate(zone.get("badges") or []):
                badge = entry.get("badge") if isinstance(entry, dict) else None
                if not isinstance(badge, dict) or badge.get("badgeID") is None:
                    continue
                badge_id = str(badge["badgeID"])
                title = badge.get("dialogTitle") or ""
                task = badge.get("badgeDescription") or title or "Quest"
                image = badge.get("badgeImage")
                quests.append(
                    {
                        "id": f"{group_id}:{badge_id}",
                        "name": task,
                        "description": title if title and title != task else "",
                        "image": _image(image.get("url") if isinstance(image, dict) else None),
                        "start": zone.get("zoneStartDate") or row.get("startDate"),
                        "end": zone.get("zoneEndDate") or row.get("endDate"),
                        "earned": earned is not None and badge_id in earned,
                        "date": (earned or {}).get(badge_id),
                        "players": 0,
                        "order": zone_index * 1000 + badge_index,
                        "titles": page_titles or _titles(catalog, title, task, loose=True),
                        "tracked": earned is not None,
                        "zone": zone.get("zoneTitle") or f"Round {zone_index + 1}",
                        "zone_order": zone_index,
                        "help": _help(badge),
                        "url": card["path"] if card else None,
                    }
                )
        if not quests:
            continue
        groups.append(
            {
                "id": group_id,
                "name": name,
                "description": row.get("description") or "",
                "kicker": row.get("title") if row.get("title") != name else None,
                "start": row.get("startDate"),
                "end": row.get("endDate"),
                "url": card["path"] if card else None,
                "page": True,
                "quests": quests,
            }
        )
    return groups


def is_quest_page(path: str) -> bool:
    """Return True for a Stern quest page address."""
    return bool(_PAGE_PATH_RE.match(path))
