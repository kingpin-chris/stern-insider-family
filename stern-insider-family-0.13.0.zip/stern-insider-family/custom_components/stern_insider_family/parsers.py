"""Parse Stern Insider pages and API payloads. No Home Assistant imports."""
from __future__ import annotations

import html
import json
import re
from typing import Any


class SternParseError(Exception):
    """A page did not have the expected structure."""


_DECODER = json.JSONDecoder()
_PUSH_RE = re.compile(r'self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)')
# Page order is not display order, so milestones are identified by name.
# Stern's own names include the spelling "Conecutive".
_MILESTONE_RES = (
    ("Games Played", re.compile(r"^([\d,]+) Games Played$", re.I)),
    ("Days Played", re.compile(r"^([\d,]+) Days Played$", re.I)),
    ("Day Streak", re.compile(r"^([\d,]+) Cons?ecutive Days?(?: Played)?$", re.I)),
    ("Week Streak", re.compile(r"^([\d,]+) Cons?ecutive Weeks?$", re.I)),
)
_CARD_RE = re.compile(r'href="/trophy-room/achievements/(\d+)"')
_COUNT_RE = re.compile(r"<h5[^>]*>\s*([\d,]+)\s*/\s*([\d,]+)\s*</h5>")
_XP_RE = re.compile(r"<h5[^>]*>\s*XP\s*([\d,]+)\s*</h5>")
_ACHIEVEMENT_RE = re.compile(r'"achievement-(?:[^"\\]|\\.)*",\{')
_IMG_ALT_RE = re.compile(r'<img\b[^>]*?\balt="([^"]*)"')

_EDITION_TOKENS = {
    "sle": "Special Limited Edition",
    "le": "Limited Edition",
    "limited": "Limited Edition",
    "60th": "60th Anniversary",
    "premium": "Premium",
    "prem": "Premium",
    "se": "Special Edition",
    "pro": "Pro",
    "homeplus": "Home Edition",
    "home": "Home Edition",
}

_AVATAR_RE = re.compile(r'"avatar_url":"(https://(?:[^"\\]|\\.)*)"')
_QUEST_EVENT_RE = re.compile(r"/ic/events/(\d+)/leaderboards")
_QUEST_LINK_RE = re.compile(
    r'"href":"(/(?:ic-quests/([a-z0-9-]+)|ic/events/(\d+)/leaderboards))"'
)
_QUEST_BADGE_RE = re.compile(
    r'"src":"((?:[^"\\]|\\.)*)","alt":"((?:[^"\\]|\\.)*)","disabled":(?:true|false)'
)
_QUEST_TEXT_RE = re.compile(r'"children":"((?:[^"\\]|\\.)*)"')
_QUEST_TIME_RE = re.compile(r"\b(?:remaining|starts?|left|upcoming|coming soon)\b", re.I)
_QUEST_UPCOMING_RE = re.compile(r"\b(?:upcoming|coming soon)\b", re.I)
_ROW_RE = re.compile(r"^([0-9a-z]+):(.*)$", re.S)
_SKIP_HEADINGS = {"progress"}

TRACKS = ("Games Played", "Days Played", "Day Streak", "Week Streak")


def _value(value: Any) -> Any:
    """Convert the page's undefined marker to None."""
    return None if isinstance(value, str) and value.startswith("$undefined") else value


def _int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return default


def flight_text(body: str) -> str:
    """Return page data from either an RSC response or a full HTML page."""
    if "__next_f.push" not in body:
        return body
    return "".join(json.loads(m.group(1)) for m in _PUSH_RE.finditer(body))


def parse_profile(text: str) -> dict[str, Any]:
    """Return allow-listed stats. Email, location and QR data are never kept."""
    marker = text.find('"player_score"')
    start = text.rfind('"user":{', 0, marker) if marker >= 0 else -1
    if start < 0:
        raise SternParseError("profile stats not found")
    try:
        user, _ = _DECODER.raw_decode(text, start + len('"user":'))
    except ValueError as err:
        raise SternParseError("profile stats unreadable") from err
    avatar = _value(user.get("avatar_url"))
    if not (isinstance(avatar, str) and avatar.startswith("https://")):
        match = _AVATAR_RE.search(text)
        avatar = json.loads(f'"{match.group(1)}"') if match else None
    return {
        "username": _value(user.get("username")),
        "initials": _value(user.get("initials")),
        "avatar_url": avatar,
        "background_color": _value(user.get("background_color")),
        "xp": _int(user.get("player_score")),
        "plays": _int(user.get("games_played")),
        "days_played": _int(user.get("days_played")),
        "day_streak": _int(user.get("consecutive_days_played")),
        "best_day_streak": _int(user.get("max_consecutive_days_played")),
        "weeks_played": _int(user.get("weeks_played")),
        "week_streak": _int(user.get("consecutive_weeks_played")),
        "achievements": _int(user.get("nonverified_achievements")),
        "verified_achievements": _int(user.get("verified_achievements")),
        "is_pro": bool(user.get("is_pro")),
        "date_joined": _iso(_value(user.get("date_joined"))),
    }


def _iso(value: Any) -> str | None:
    return value.replace(" ", "T", 1) if isinstance(value, str) and value else None


def _milestone(name: Any) -> tuple[str | None, int | None]:
    """Return the milestone track and tier for a badge name."""
    for track, pattern in _MILESTONE_RES:
        if match := pattern.match(str(name or "").strip()):
            return track, _int(match.group(1))
    return None, None


def find_avatar(value: Any) -> str | None:
    """Find an avatar address in an account response."""
    if isinstance(value, dict):
        avatar = value.get("avatar_url")
        if isinstance(avatar, str) and avatar.startswith("https://"):
            return avatar
        value = list(value.values())
    if isinstance(value, list):
        for item in value:
            if avatar := find_avatar(item):
                return avatar
    return None


def parse_badges(text: str) -> list[dict[str, Any]]:
    """Return every badge on the badges page, earned or locked."""
    badges: list[dict[str, Any]] = []
    seen: set[tuple[str, Any]] = set()
    pos = -1
    while (pos := text.find('"badgeName":', pos + 1)) >= 0:
        start = text.rfind('{"src":', 0, pos)
        if start < 0:
            continue
        try:
            raw, _ = _DECODER.raw_decode(text, start)
        except ValueError:
            continue
        date = _iso(_value(raw.get("dateAwarded")))
        key = (raw.get("badgeName"), date)
        if key in seen:
            continue
        seen.add(key)
        track, tier = _milestone(raw.get("badgeName"))
        badges.append(
            {
                "name": raw.get("badgeName"),
                "description": _value(raw.get("badgeDescription")) or "",
                "track": track,
                "date": date,
                "earned": raw.get("disabled") is False,
                "image": _value(raw.get("src")),
                "milestone": tier,
            }
        )
    if not badges:
        raise SternParseError("no badges found")
    return badges


def build_tracks(
    profile: dict[str, Any], badges: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Combine profile stats and milestone badges into progress tracks."""
    tracks = []
    values = {
        "Games Played": (profile["plays"], profile["plays"]),
        "Days Played": (profile["days_played"], profile["days_played"]),
        "Day Streak": (profile["day_streak"], profile["best_day_streak"]),
        "Week Streak": (profile["week_streak"], profile["week_streak"]),
    }
    for name in TRACKS:
        tiers = [b for b in badges if b["track"] == name]
        earned = [b["milestone"] for b in tiers if b["earned"]]
        locked = [b["milestone"] for b in tiers if not b["earned"]]
        current, best = values[name]
        tier = max(earned, default=0)
        best = max(best, tier)
        goal = min(locked, default=None)
        if goal:
            percent = min(100, round(best / goal * 100))
        else:
            percent = 100 if tiers else 0
        tracks.append(
            {
                "name": name,
                "current": current,
                "best": best,
                "tier": tier,
                "next": goal,
                "percent": percent,
                # Stern's data has no best week streak, only earned tiers.
                "show_best": name != "Week Streak",
            }
        )
    return tracks


def parse_achievements(body: str) -> list[dict[str, Any]]:
    """Return achievement progress per game from the achievements page."""
    page = body.replace("<!-- -->", "")
    games: dict[str, dict[str, Any]] = {}
    for match in _CARD_RE.finditer(page):
        title_id = match.group(1)
        if title_id in games:
            continue
        after = page[match.start() : match.start() + 1500]
        count, xp = _COUNT_RE.search(after), _XP_RE.search(after)
        if not count or not xp:
            continue
        alts = _IMG_ALT_RE.findall(page[max(0, match.start() - 4000) : match.start()])
        earned, total = _int(count.group(1)), _int(count.group(2))
        games[title_id] = {
            "title_id": title_id,
            "game": html.unescape(alts[-1]).strip() if alts else f"Game {title_id}",
            "earned": earned,
            "total": total,
            "xp": _int(xp.group(1)),
            "percent": round(earned / total * 100) if total else 0,
        }
    if not games:
        raise SternParseError("no achievement cards found")
    return sorted(games.values(), key=lambda g: (-g["percent"], g["game"]))


def parse_game_achievements(text: str) -> list[dict[str, Any]]:
    """Return achievement groups for one game, earned and still open."""
    groups: list[dict[str, Any]] = []
    for match in _ACHIEVEMENT_RE.finditer(text):
        try:
            raw, _ = _DECODER.raw_decode(text, match.end() - 1)
        except ValueError:
            continue
        if not isinstance(raw.get("levels"), list):
            continue
        levels = []
        for level in raw["levels"]:
            user = level.get("user_data")
            user = user if isinstance(user, dict) else {}
            earned = user.get("completed") is True
            levels.append(
                {
                    "name": level.get("name") or "",
                    "description": _value(level.get("description")) or "",
                    "points": _int(level.get("points")),
                    "rarity": round(float(level.get("percentage") or 0) * 100, 2),
                    "earned": earned,
                    "date": _value(user.get("date")) if earned else None,
                    "icon": _value(level.get("icon_url")),
                }
            )
        groups.append(
            {
                "name": raw.get("name") or "",
                "image": _value(raw.get("image")),
                "progressive": bool(raw.get("isProgressive")),
                "progress": _int(raw.get("progressCount")),
                "levels": levels,
            }
        )
    if not groups:
        raise SternParseError("no achievements found")
    return groups


def backglass_edition(url: str | None) -> str | None:
    """Work out the edition from Stern's backglass file name."""
    if not url:
        return None
    name = url.split("?")[0].rsplit("/", 1)[-1].split(".")[0].lower()
    tokens = re.split(r"[-_]", name)
    for token, label in _EDITION_TOKENS.items():
        if token in tokens:
            return label
    return None


def parse_game_backglass(text: str) -> dict[str, str | None]:
    """Return the backglass Stern publishes for the game on this page."""
    for match in _ACHIEVEMENT_RE.finditer(text):
        try:
            raw, _ = _DECODER.raw_decode(text, match.end() - 1)
        except ValueError:
            continue
        info = raw.get("gameInfo")
        if isinstance(info, dict):
            url = _value(info.get("default_backglass_image"))
            return {
                "url": url,
                "edition": backglass_edition(url),
                "logo": _value(info.get("variable_width_logo")),
                "gradient_start": _value(info.get("gradient_start")),
                "gradient_stop": _value(info.get("gradient_stop")),
            }
    return {
        "url": None,
        "edition": None,
        "logo": None,
        "gradient_start": None,
        "gradient_stop": None,
    }


def _flight_rows(text: str) -> tuple[dict[str, Any], dict[str, str]]:
    """Split page data into rows and client component names."""
    rows: dict[str, Any] = {}
    components: dict[str, str] = {}
    for line in text.split("\n"):
        match = _ROW_RE.match(line)
        if not match:
            continue
        key, value = match.groups()
        try:
            if value.startswith("I["):
                module = json.loads(value[1:])
                components[key] = str(module[2])
            elif value[:1] in ('[', '{', '"'):
                rows[key] = json.loads(value)
        except (ValueError, IndexError):
            continue
    return rows, components


def _is_element(value: Any) -> bool:
    return (
        isinstance(value, list)
        and len(value) >= 4
        and value[0] == "$"
        and isinstance(value[1], str)
    )


def _follow_reference(value: Any, rows: dict[str, Any]) -> Any:
    """Follow a reference such as $24:props:children:1:props:stats."""
    if not isinstance(value, str) or not re.fullmatch(r"\$[0-9a-z]+(?::[^:]+)+", value):
        return value
    key, *path = value[1:].split(":")
    current = rows.get(key)
    for part in path:
        if isinstance(current, str) and current.startswith("$L"):
            current = rows.get(current[2:])
        if isinstance(current, list):
            if part == "props" and _is_element(current):
                current = current[3]
            elif part.isdigit() and int(part) < len(current):
                current = current[int(part)]
            else:
                return None
        elif isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current


def _image(value: Any) -> str | None:
    if isinstance(value, dict):
        value = value.get("icon_url")
    value = _value(value)
    return value if isinstance(value, str) and value.startswith("https://") else None


def _strings(value: Any) -> list[str]:
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return []
    result = []
    for item in value:
        item = _value(item)
        if isinstance(item, (int, float)) and not isinstance(item, bool):
            result.append(str(item))
        elif isinstance(item, str) and item.strip() and not item.startswith("$"):
            result.append(item.strip())
    return result


def _number(value: Any) -> Any:
    value = _value(value)
    return value if isinstance(value, (int, float, str)) else None


def _character_block(
    props: dict[str, Any], rows: dict[str, Any]
) -> dict[str, Any] | None:
    character = props.get("character")
    if not isinstance(character, dict):
        return None
    stats = []
    labels = _follow_reference(props.get("stats"), rows)
    for stat in labels if isinstance(labels, list) else []:
        if isinstance(stat, dict) and stat.get("name") in character:
            stats.append(
                {"label": stat.get("label") or stat["name"], "value": _number(character[stat["name"]])}
            )
    level = character.get("level_progress")
    level = level if isinstance(level, dict) else {}
    equipment = [
        {"name": item.get("description") or "", "image": _image(item.get("icon"))}
        for item in character.get("equipment") or []
        if isinstance(item, dict)
    ]
    return {
        "type": "character",
        "title": character.get("name") or "",
        "subtitle": _value(character.get("character_type")) or "",
        "level": _value(character.get("level")) or "",
        "next": _value(level.get("max")) or "",
        "percent": _number(level.get("pct")),
        "locked": bool(character.get("locked")),
        "image": _image(character.get("icon")),
        "stats": stats,
        "equipment": equipment,
    }


def _items_block(props: dict[str, Any]) -> dict[str, Any] | None:
    raw_items = props.get("items")
    if not isinstance(raw_items, list):
        return None
    items = []
    for item in raw_items:
        if isinstance(item, dict) and item.get("name"):
            items.append(
                {
                    "name": item["name"],
                    "description": _value(item.get("description")) or "",
                    "effect": _value(item.get("game_effect")) or "",
                    "count": _int(item.get("count")),
                    "max": _int(item.get("max"), 1),
                    "image": _image(item.get("icon")),
                    "order": _int(item.get("display_sort_order")),
                }
            )
    items.sort(key=lambda item: item["order"])
    return {"type": "items", "items": items} if items else None


def _component_block(
    name: str, props: dict[str, Any], rows: dict[str, Any]
) -> dict[str, Any] | None:
    title = _value(props.get("title")) or ""
    details = _strings(props.get("descriptions")) or _strings(props.get("description"))
    image = _image(props.get("image"))
    images = props.get("images")
    if not image and isinstance(images, list) and images:
        image = _image(images[0])
    if name in ("Character", "FalloutCharacter") or "character" in props:
        return _character_block(props, rows)
    if name == "ItemsList" or "items" in props:
        return _items_block(props)
    if name == "UnlockCard":
        return {
            "type": "unlock",
            "title": title,
            "locked": bool(props.get("locked")),
            "description": " ".join(details),
            "image": image,
        }
    if name == "SpeedRunCard":
        return {
            "type": "pair",
            "title": title,
            "values": [
                {"label": _value(props.get("label")) or "", "value": _number(props.get("value"))},
                {"label": _value(props.get("label2")) or "", "value": _number(props.get("value2"))},
            ],
        }
    if name == "ModeUnlockCard":
        return {
            "type": "mode",
            "title": title,
            "description": details[0] if details else "",
            "cost": _number(props.get("value")),
            "cost_label": details[2] if len(details) > 2 else "",
            "played": _number(props.get("count")),
            "available": bool(props.get("available")),
            "image": image,
        }
    if "currentLevel" in props:
        return {
            "type": "meter",
            "title": f"{title}: {_number(props.get('currentLevel'))}".strip(": "),
            "subtitle": _value(props.get("caption")) or "",
            "current": _number(props.get("currentPoints")),
            "minimum": _number(props.get("prevPoints")),
            "maximum": _number(props.get("nextPoints")),
            "description": " ".join(details),
            "image": image,
        }
    if "current" in props and "nextPoints" in props:
        return {
            "type": "meter",
            "title": title,
            "subtitle": details[-1] if len(details) > 1 else "",
            "current": _number(props.get("current")),
            "minimum": _number(props.get("prevPoints")),
            "maximum": _number(props.get("nextPoints")),
            "description": details[0] if details else "",
            "image": image,
        }
    if title and ("value" in props or details):
        return {
            "type": "stat",
            "title": title,
            "value": _number(props.get("value")),
            "description": " ".join(details),
            "image": image,
        }
    return None


def parse_game_progress(text: str) -> list[dict[str, Any]]:
    """Return allow-listed blocks from a progress page, or [] if it has none."""
    rows, components = _flight_rows(text)
    blocks: list[dict[str, Any]] = []
    seen: set[str] = set()

    def resolve(value: Any) -> Any:
        if isinstance(value, str) and re.fullmatch(r"\$L?[0-9a-z]+", value):
            key = value.lstrip("$").removeprefix("L")
            if key in rows and key not in seen:
                seen.add(key)
                return rows[key]
            return None
        return value

    def walk(value: Any, depth: int = 0) -> None:
        value = resolve(value)
        if depth > 80 or not isinstance(value, list):
            return
        if not _is_element(value):
            for child in value:
                walk(child, depth + 1)
            return
        kind, props = value[1], value[3] if isinstance(value[3], dict) else {}
        if kind.startswith("$L"):
            kind = components.get(kind[2:], kind)
        if kind in ("h1", "h2", "h3", "h4", "h5", "h6", "p"):
            content = " ".join(_strings(props.get("children")))
            if content and content.lower() not in _SKIP_HEADINGS:
                block = "text" if kind == "p" else "subheading" if kind in ("h5", "h6") else "heading"
                blocks.append({"type": block, "text": content})
            return
        if block := _component_block(kind, props, rows):
            blocks.append(block)
            return
        walk(props.get("children"), depth + 1)

    roots = [
        row
        for row in rows.values()
        if isinstance(row, list) and '"children":"Progress"' in json.dumps(row, separators=(",", ":"))
    ]
    if not roots:
        return []
    walk(roots[0])
    return blocks if any(b["type"] not in ("heading", "subheading", "text") for b in blocks) else []


def parse_game_catalog(text: str) -> list[dict[str, Any]]:
    """Return every published Insider Connected game."""
    start = text.find('"games":[')
    if start < 0:
        raise SternParseError("game list not found")
    try:
        games, _ = _DECODER.raw_decode(text, start + len('"games":'))
    except ValueError as err:
        raise SternParseError("game list unreadable") from err
    catalog = []
    for game in games:
        if (
            not isinstance(game, dict)
            or game.get("pk") is None
            or not game.get("name")
            or game.get("published") is False
            or game.get("can_connect") is False
        ):
            continue
        url = _value(game.get("default_backglass_image"))
        catalog.append(
            {
                "title_id": str(game["pk"]),
                "game": game["name"],
                "backglass": url,
                "backglass_edition": backglass_edition(url),
                "logo": _value(game.get("variable_width_logo")),
                "gradient_start": _value(game.get("gradient_start")),
                "gradient_stop": _value(game.get("gradient_stop")),
                "coming_soon": bool(_value(game.get("coming_soon"))),
            }
        )
    if not catalog:
        raise SternParseError("no games found")
    return catalog


def parse_quest_event_ids(body: str) -> list[str]:
    """Return current quest event ids from the quests page."""
    return list(dict.fromkeys(_QUEST_EVENT_RE.findall(body)))


def _title_ids(value: Any) -> list[str]:
    return [str(item) for item in value if item is not None] if isinstance(value, list) else []


def _flight_string(value: str) -> str:
    try:
        return json.loads(f'"{value}"')
    except ValueError:
        return value


def parse_quest_cards(text: str) -> list[dict[str, Any]]:
    """Return every quest group listed on the current quests page."""
    cards: list[dict[str, Any]] = []
    seen: set[str] = set()
    previous = 0
    for link in _QUEST_LINK_RE.finditer(text):
        section = text[previous : link.start()]
        previous = link.end()
        path, slug, event_id = link.groups()
        card_id = event_id or slug
        if card_id in seen:
            continue
        labels = [
            label
            for match in _QUEST_TEXT_RE.finditer(section)
            if (label := _flight_string(match.group(1))) and not label.startswith("$")
        ]
        upcoming = bool(labels and _QUEST_UPCOMING_RE.search(labels[-1]))
        if labels and _QUEST_TIME_RE.search(labels[-1]):
            labels.pop()
        if not labels:
            continue
        seen.add(card_id)
        badges = [
            {"name": _flight_string(match.group(2)), "image": _image(_flight_string(match.group(1)))}
            for match in _QUEST_BADGE_RE.finditer(section)
        ]
        cards.append(
            {
                "id": card_id,
                "event_id": event_id,
                "name": labels[-1],
                "path": path,
                "badges": badges,
                "upcoming": upcoming,
            }
        )
    return cards


def _listed_quest_group(
    card: dict[str, Any],
    data: dict[str, Any],
    earned: dict[str, dict[str, Any]],
    images: dict[str, str],
) -> dict[str, Any]:
    """Show a quest page or event that has no individual quest data."""
    badges = card["badges"]
    award = earned.get(badges[0]["name"].casefold()) if len(badges) == 1 else None
    name = data.get("name") or card["name"]
    image = images.get(name.casefold()) or next(
        (badge["image"] for badge in badges if badge["image"]), None
    )
    start = _value(data.get("start_date"))
    end = _value(data.get("stop_date"))
    url = card["path"]
    return {
        "id": card["id"],
        "name": name,
        "description": _value(data.get("description")) or "",
        "start": start,
        "end": end,
        "url": url,
        "listed": True,
        "quests": [
            {
                "id": card["id"],
                "name": name,
                "description": _value(data.get("description")) or "",
                "image": image,
                "start": start,
                "end": end,
                "earned": award is not None,
                "date": award.get("date") if award else None,
                "players": 0,
                "order": 0,
                "titles": _title_ids(data.get("titles")),
                "tracked": len(badges) == 1,
                "url": url,
                "upcoming": card.get("upcoming", False),
                "gallery": [badge for badge in badges if badge["image"]]
                if len(badges) > 1
                else [],
            }
        ],
    }


def build_quest_groups(
    cards: list[dict[str, Any]],
    event_ids: list[str],
    payloads: dict[str, dict[str, Any]],
    previous: dict[str, dict[str, Any]],
    badges: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Combine Stern's listed quest groups with any event details available."""
    earned = {
        str(badge["name"]).casefold(): badge
        for badge in badges
        if badge.get("earned") and badge.get("name")
    }
    images = {
        str(badge["name"]).casefold(): badge["image"]
        for badge in [*badges, *(item for card in cards for item in card["badges"])]
        if badge.get("name") and badge.get("image")
    }
    by_event = {card["event_id"]: card for card in cards if card["event_id"]}
    order = [card["id"] for card in cards]
    order += [event_id for event_id in event_ids if event_id not in order]
    by_id = {card["id"]: card for card in cards}
    groups = []
    for group_id in order:
        card = by_id.get(group_id)
        payload = payloads.get(group_id)
        event = parse_quest_event(payload) if payload else None
        if event:
            for quest in event["quests"]:
                quest["image"] = quest["image"] or images.get(quest["name"].casefold())
            if group_id in by_event:
                event["url"] = by_event[group_id]["path"]
            groups.append(event)
        elif payload is None and group_id in event_ids and group_id in previous:
            groups.append(previous[group_id])
        elif card:
            data = payload.get("data") if payload else None
            groups.append(
                _listed_quest_group(
                    card, data if isinstance(data, dict) else {}, earned, images
                )
            )
    return groups


def parse_quest_event(payload: dict[str, Any]) -> dict[str, Any] | None:
    """Return allow-listed quest details for one event."""
    data = payload.get("data")
    if not isinstance(data, dict) or data.get("pk") is None:
        return None
    quests = []
    for group in data.get("quest_group") or []:
        for quest in (group.get("quests") or []) if isinstance(group, dict) else []:
            if not isinstance(quest, dict) or quest.get("id") is None:
                continue
            quests.append(
                {
                    "id": str(quest["id"]),
                    "name": quest.get("name") or "",
                    "description": _value(quest.get("description")) or "",
                    "image": _image(quest.get("badge_url")),
                    "start": _value(quest.get("start_date")),
                    "end": _value(quest.get("end_date")),
                    "earned": quest.get("is_quest_earned") is True,
                    "date": _value(quest.get("date_awarded")),
                    "players": _int(quest.get("count")),
                    "order": _int(quest.get("display_sort_order")),
                    "titles": _title_ids(quest.get("titles")),
                    "tracked": True,
                }
            )
    if not quests:
        return None
    quests.sort(key=lambda quest: quest["order"])
    return {
        "id": str(data["pk"]),
        "name": data.get("name") or "Quests",
        "description": _value(data.get("description")) or "",
        "start": _value(data.get("start_date")),
        "end": _value(data.get("stop_date")),
        "quests": quests,
    }


def parse_machines(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Return active machines. Serial numbers and addresses are never kept."""
    user = payload.get("user") or {}
    machines = []
    for item in user.get("machines") or payload.get("machines") or []:
        if item.get("archived") or item.get("id") is None:
            continue
        title = (item.get("model") or {}).get("title") or {}
        machines.append(
            {
                "id": str(item["id"]),
                "name": title.get("name") or f"Machine {item['id']}",
                "online": bool(item.get("online")),
                "active": bool(item.get("active")),
                "out_of_service": bool(item.get("out_of_service")),
                "last_activity": item.get("last_activity"),
                "last_played": item.get("last_played"),
                "square_logo_url": title.get("square_logo"),
                "variable_width_logo_url": title.get("variable_width_logo"),
                "backglass_image_url": title.get("default_backglass_image"),
                "gradient_start": title.get("gradient_start"),
                "gradient_stop": title.get("gradient_stop"),
            }
        )
    return machines


def parse_high_scores(payload: dict[str, Any], limit: int = 5) -> list[dict[str, Any]]:
    """Return ranked high scores for one machine."""
    scores = []
    for rank, item in enumerate((payload.get("high_score") or [])[:limit], start=1):
        user = item.get("user") or {}
        scores.append(
            {
                "rank": rank,
                "score": _int(item.get("score")),
                "player_id": user.get("id"),
                "player_username": user.get("username"),
                "player_initials": user.get("initials"),
                "avatar_url": user.get("avatar_url"),
            }
        )
    return scores
