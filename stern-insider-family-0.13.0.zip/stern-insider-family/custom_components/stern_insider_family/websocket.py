"""Websocket commands used by the achievements card."""
from __future__ import annotations

import asyncio
from typing import Any

import voluptuous as vol

from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.dispatcher import (
    async_dispatcher_connect,
    async_dispatcher_send,
)

from .const import DOMAIN, SIGNAL_UPDATED


@callback
def async_register_commands(hass: HomeAssistant) -> None:
    """Register commands."""
    websocket_api.async_register_command(hass, ws_overview)
    websocket_api.async_register_command(hass, ws_game)
    websocket_api.async_register_command(hass, ws_badges)
    websocket_api.async_register_command(hass, ws_progress)
    websocket_api.async_register_command(hass, ws_subscribe_updates)
    websocket_api.async_register_command(hass, ws_refresh)


def _players(hass: HomeAssistant) -> list[Any]:
    entries = hass.config_entries.async_loaded_entries(DOMAIN)
    return sorted(entries, key=lambda entry: entry.runtime_data.person.lower())


def _send(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
    result: dict[str, Any],
) -> None:
    """Send data using saved images wherever they are available."""
    connection.send_result(msg["id"], hass.data[DOMAIN]["images"].localize(result))


def _last_updated(hass: HomeAssistant) -> str | None:
    times = [
        entry.runtime_data.last_updated
        for entry in _players(hass)
        if entry.runtime_data.last_updated
    ]
    return max(times).isoformat() if times else None


async def _refresh_all(hass: HomeAssistant) -> dict[str, Any]:
    """Update each account in turn."""
    data = hass.data[DOMAIN]
    data["refreshing"] = True
    async_dispatcher_send(hass, SIGNAL_UPDATED)
    failed = []
    try:
        for entry in _players(hass):
            coordinator = entry.runtime_data
            await coordinator.async_refresh()
            if not coordinator.last_update_success:
                failed.append(coordinator.person)
    finally:
        data["refreshing"] = False
        async_dispatcher_send(hass, SIGNAL_UPDATED)
    return {"failed": failed, "updated": _last_updated(hass)}


def _earned_badges(player: dict[str, Any]) -> list[dict[str, Any]]:
    badges = [badge for badge in player.get("badges", []) if badge["earned"]]
    return sorted(badges, key=lambda badge: badge["date"] or "", reverse=True)


def _person(entry: Any) -> dict[str, Any]:
    coordinator = entry.runtime_data
    player = (coordinator.data or {}).get("player", {})
    profile = player.get("profile", {})
    details = player.get("details", {})
    earned = _earned_badges(player)
    regular = [badge for badge in earned if badge["milestone"] is None]
    games = []
    for game in player.get("games", []):
        art = details.get(game["title_id"], {}).get("backglass", {})
        games.append(
            {
                "title_id": game["title_id"],
                "game": game["game"],
                "earned": game["earned"],
                "total": game["total"],
                "open": max(game["total"] - game["earned"], 0),
                "xp": game["xp"],
                "percent": game["percent"],
                "has_details": game["title_id"] in details,
                "has_progress": game["title_id"] in player.get("progress", {}),
                "backglass": art.get("url"),
                "backglass_edition": art.get("edition"),
                "logo": art.get("logo"),
                "gradient_start": art.get("gradient_start"),
                "gradient_stop": art.get("gradient_stop"),
            }
        )
    return {
        "entry_id": entry.entry_id,
        "person": coordinator.person,
        "username": profile.get("username"),
        "initials": profile.get("initials"),
        "avatar_url": profile.get("avatar_url"),
        "status": "partial" if player.get("errors") else "connected",
        "stats": {
            key: profile.get(key)
            for key in ("xp", "plays", "days_played", "achievements")
        },
        "badge_count": len(regular),
        "milestone_badge_count": len(earned) - len(regular),
        "recent_badges": [
            {"name": badge["name"], "image": badge["image"], "date": badge["date"]}
            for badge in regular[:8]
        ],
        "tracks": player.get("tracks", []),
        "games": games,
    }


def _machines(hass: HomeAssistant, people: list[dict[str, Any]]) -> list[dict[str, Any]]:
    names = {
        person["username"].lower(): person["person"]
        for person in people
        if person["username"]
    }
    machines: dict[str, dict[str, Any]] = {}
    for entry in _players(hass):
        for machine_id, machine in (entry.runtime_data.data or {}).get("machines", {}).items():
            machines[machine_id] = {
                "id": machine_id,
                "name": machine["name"],
                "logo": machine.get("square_logo_url"),
                "online": machine.get("online"),
                "last_activity": machine.get("last_activity"),
                "scores": [
                    {
                        "rank": score["rank"],
                        "score": score["score"],
                        "initials": score["player_initials"],
                        "user": score["player_username"],
                        "member": names.get((score["player_username"] or "").lower()),
                    }
                    for score in machine.get("scores", [])
                ],
            }
    return sorted(machines.values(), key=lambda machine: machine["name"].lower())


def _quests(hass: HomeAssistant) -> list[dict[str, Any]]:
    events: dict[str, dict[str, Any]] = {}
    for entry in _players(hass):
        coordinator = entry.runtime_data
        player = (coordinator.data or {}).get("player", {})
        for source in player.get("quests", []):
            event = events.setdefault(
                source["id"], {**source, "quests": [], "_by_id": {}}
            )
            for quest in source["quests"]:
                target = event["_by_id"].get(quest["id"])
                if target is None:
                    target = {
                        key: value
                        for key, value in quest.items()
                        if key not in ("earned", "date")
                    }
                    target["owners"] = []
                    target["tracked"] = False
                    event["_by_id"][quest["id"]] = target
                    event["quests"].append(target)
                target["players"] = max(target["players"], quest["players"])
                if quest.get("tracked") is False:
                    continue
                target["tracked"] = True
                target["owners"].append(
                    {
                        "entry_id": entry.entry_id,
                        "person": coordinator.person,
                        "earned": quest["earned"],
                        "date": quest["date"],
                    }
                )
    return [
        {key: value for key, value in event.items() if key != "_by_id"}
        for event in events.values()
    ]


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/overview"})
@callback
def ws_overview(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Return everything the family home page needs."""
    people = [_person(entry) for entry in _players(hass)]
    score_avatars = {
        (score["player_username"] or "").lower(): score["avatar_url"]
        for entry in _players(hass)
        for machine in (entry.runtime_data.data or {}).get("machines", {}).values()
        for score in machine.get("scores", [])
        if score.get("avatar_url")
    }
    for person in people:
        if not person["avatar_url"] and person["username"]:
            person["avatar_url"] = score_avatars.get(person["username"].lower())
    catalog: dict[str, dict[str, Any]] = {}
    for entry in _players(hass):
        player = (entry.runtime_data.data or {}).get("player", {})
        for game in player.get("catalog", []):
            catalog.setdefault(game["title_id"], game)
    _send(
        hass,
        connection,
        msg,
        {
            "people": people,
            "machines": _machines(hass, people),
            "quests": _quests(hass),
            "catalog": sorted(catalog.values(), key=lambda game: game["game"].lower()),
            "refreshing": hass.data[DOMAIN].get("refreshing", False),
            "updated": _last_updated(hass),
        },
    )


@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/game",
        vol.Required("entry_id"): str,
        vol.Required("title_id"): str,
    }
)
@callback
def ws_game(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Return one person's achievements for one game."""
    for entry in _players(hass):
        if entry.entry_id == msg["entry_id"]:
            player = (entry.runtime_data.data or {}).get("player", {})
            detail = player.get("details", {}).get(msg["title_id"])
            if detail:
                _send(hass, connection, msg, {"groups": detail["groups"]})
                return
            break
    connection.send_error(msg["id"], "not_found", "Achievements are not available yet")


@websocket_api.websocket_command(
    {vol.Required("type"): f"{DOMAIN}/badges", vol.Required("entry_id"): str}
)
@callback
def ws_badges(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Return every earned and locked badge for one person."""
    for entry in _players(hass):
        if entry.entry_id == msg["entry_id"]:
            player = (entry.runtime_data.data or {}).get("player", {})
            if "badges" in player:
                _send(hass, connection, msg, {"badges": player["badges"]})
                return
            break
    connection.send_error(msg["id"], "not_found", "Badges are not available yet")


@websocket_api.websocket_command(
    {
        vol.Required("type"): f"{DOMAIN}/progress",
        vol.Required("entry_id"): str,
        vol.Required("title_id"): str,
    }
)
@callback
def ws_progress(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Return one person's progress page for one game."""
    for entry in _players(hass):
        if entry.entry_id == msg["entry_id"]:
            player = (entry.runtime_data.data or {}).get("player", {})
            blocks = player.get("progress", {}).get(msg["title_id"])
            if blocks:
                _send(hass, connection, msg, {"blocks": blocks})
                return
            break
    connection.send_error(msg["id"], "not_found", "Progress is not available yet")


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/refresh"})
@websocket_api.async_response
async def ws_refresh(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Update every account now, joining an update already running."""
    data = hass.data[DOMAIN]
    task = data.get("refresh_task")
    if task is None or task.done():
        task = hass.async_create_background_task(
            _refresh_all(hass), f"{DOMAIN} refresh"
        )
        data["refresh_task"] = task
    connection.send_result(msg["id"], await asyncio.shield(task))


@websocket_api.websocket_command({vol.Required("type"): f"{DOMAIN}/subscribe_updates"})
@callback
def ws_subscribe_updates(
    hass: HomeAssistant,
    connection: websocket_api.ActiveConnection,
    msg: dict[str, Any],
) -> None:
    """Tell open dashboards when new Stern data has arrived."""

    @callback
    def updated() -> None:
        connection.send_message(websocket_api.event_message(msg["id"], {"updated": True}))

    connection.subscriptions[msg["id"]] = async_dispatcher_connect(
        hass, SIGNAL_UPDATED, updated
    )
    connection.send_result(msg["id"])
