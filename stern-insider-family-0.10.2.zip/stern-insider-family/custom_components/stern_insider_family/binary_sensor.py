"""Machine online status."""
from __future__ import annotations

from typing import Any

from homeassistant.components.binary_sensor import (
    BinarySensorDeviceClass,
    BinarySensorEntity,
)
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import SternConfigEntry
from .coordinator import SternCoordinator
from .entity import SternMachineEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: SternConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Add a status sensor for each machine."""
    coordinator = entry.runtime_data
    known: set[str] = set()

    @callback
    def add_new() -> None:
        new = set(coordinator.data["machines"]) - known
        known.update(new)
        if new:
            async_add_entities(SternMachineOnline(coordinator, m) for m in new)

    add_new()
    entry.async_on_unload(coordinator.async_add_listener(add_new))


class SternMachineOnline(SternMachineEntity, BinarySensorEntity):
    """Whether Stern reports the machine as online."""

    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY
    _attr_name = "Online"
    _unrecorded_attributes = frozenset(
        {
            "square_logo_url",
            "variable_width_logo_url",
            "backglass_image_url",
            "gradient_start",
            "gradient_stop",
        }
    )

    def __init__(self, coordinator: SternCoordinator, machine_id: str) -> None:
        super().__init__(coordinator, machine_id, "online")

    @property
    def is_on(self) -> bool:
        """Return Stern's reported online state."""
        return bool(self.machine.get("online"))

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return machine details."""
        machine = self.machine
        return {
            "kind": "machine_status",
            **self.machine_attributes(),
            "last_activity": machine.get("last_activity"),
            "last_played": machine.get("last_played"),
            "out_of_service": machine.get("out_of_service"),
        }
