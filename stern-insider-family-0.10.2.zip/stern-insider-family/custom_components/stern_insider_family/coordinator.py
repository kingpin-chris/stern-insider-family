"""Data coordinator for one Stern Insider account."""
from __future__ import annotations

import asyncio
from datetime import timedelta
import logging
from typing import Any

from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryAuthFailed
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed
from homeassistant.util import dt as dt_util

from .api import SternApiError, SternAuthError, SternClient
from .const import (
    CONF_DISPLAY_NAME,
    CONF_REFRESH_TOKEN,
    CONF_SCAN_HOURS,
    DEFAULT_SCAN_HOURS,
    DETAIL_CONCURRENCY,
    DETAIL_MAX_AGE,
    DOMAIN,
    EVENT_NEW_BADGE,
    EVENT_NEW_HIGH_SCORE,
    HIGH_SCORE_COUNT,
    PROGRESS_RECHECK,
)
from .parsers import (
    SternParseError,
    build_tracks,
    find_avatar,
    flight_text,
    parse_achievements,
    parse_badges,
    parse_game_catalog,
    parse_game_achievements,
    parse_game_backglass,
    parse_game_progress,
    parse_high_scores,
    parse_machines,
    parse_profile,
    parse_quest_event,
    parse_quest_event_ids,
)

_LOGGER = logging.getLogger(__name__)
_ERRORS = (SternApiError, SternParseError)


class SternCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Fetch one person's profile and any machines this entry looks after."""

    config_entry: ConfigEntry

    def __init__(
        self, hass: HomeAssistant, entry: ConfigEntry, client: SternClient
    ) -> None:
        self.scan_hours = entry.options.get(CONF_SCAN_HOURS, DEFAULT_SCAN_HOURS)
        super().__init__(
            hass,
            _LOGGER,
            config_entry=entry,
            name=f"{DOMAIN}_{entry.entry_id}",
            update_interval=timedelta(hours=self.scan_hours),
        )
        self.client = client

    @property
    def person(self) -> str:
        """Name shown for this account."""
        return self.config_entry.data.get(CONF_DISPLAY_NAME) or self.config_entry.title

    async def _access_token(self) -> str:
        entry = self.config_entry
        try:
            tokens = await self.client.refresh(entry.data[CONF_REFRESH_TOKEN])
        except SternAuthError as err:
            raise ConfigEntryAuthFailed("Stern sign-in has expired") from err
        except SternApiError as err:
            raise UpdateFailed(str(err)) from err
        # Stern retires the old refresh token, so save the new one first.
        self.hass.config_entries.async_update_entry(
            entry, data={**entry.data, CONF_REFRESH_TOKEN: tokens.refresh_token}
        )
        return tokens.access_token

    async def _fetch_player(self, token: str, old: dict[str, Any]) -> dict[str, Any]:
        player = dict(old)
        errors: list[str] = []
        try:
            text = flight_text(await self.client.badges_page(token))
            profile = parse_profile(text)
            badges = parse_badges(text)
            if not profile.get("avatar_url"):
                try:
                    profile["avatar_url"] = find_avatar(await self.client.user_detail(token))
                except _ERRORS as err:
                    _LOGGER.debug("Could not read avatar: %s", err)
            player.update(profile=profile, badges=badges)
            player["tracks"] = build_tracks(profile, badges)
        except _ERRORS as err:
            errors.append(f"badges: {err}")
        try:
            body = await self.client.achievements_page(token)
            player["games"] = parse_achievements(body)
        except _ERRORS as err:
            errors.append(f"achievements: {err}")
        player["errors"] = errors
        for error in errors:
            _LOGGER.warning("%s: could not update %s", self.person, error)
        return player

    async def _fetch_details(self, token: str, player: dict[str, Any]) -> None:
        """Refresh per-game achievements that changed or have old image links."""
        old: dict[str, Any] = player.get("details", {})
        now = dt_util.utcnow().timestamp()
        limit = asyncio.Semaphore(DETAIL_CONCURRENCY)

        def stale(game: dict[str, Any]) -> bool:
            known = old.get(game["title_id"])
            return (
                not known
                or now - known["fetched"] >= DETAIL_MAX_AGE
                or any(known[k] != game[k] for k in ("earned", "total", "xp"))
            )

        async def load(game: dict[str, Any]) -> tuple[str, dict[str, Any] | None]:
            async with limit:
                try:
                    page = await self.client.game_achievements_page(
                        token, game["title_id"]
                    )
                    text = flight_text(page)
                    groups = parse_game_achievements(text)
                    backglass = parse_game_backglass(text)
                except _ERRORS as err:
                    _LOGGER.debug("Details failed for %s: %s", game["game"], err)
                    return game["title_id"], None
            return game["title_id"], {
                "fetched": now,
                "earned": game["earned"],
                "total": game["total"],
                "xp": game["xp"],
                "groups": groups,
                "backglass": backglass,
            }

        games = player.get("games", [])
        player["changed_titles"] = [
            game["title_id"]
            for game in games
            if game["title_id"] in old
            and any(old[game["title_id"]][k] != game[k] for k in ("earned", "total", "xp"))
        ]
        results = await asyncio.gather(*(load(g) for g in games if stale(g)))
        current = {g["title_id"] for g in games}
        details = {k: v for k, v in old.items() if k in current}
        failed = 0
        for title_id, detail in results:
            if detail:
                details[title_id] = detail
            else:
                failed += 1
        player["details"] = details
        if failed:
            message = f"game details: {failed} games could not be read"
            player["errors"] = [*player.get("errors", []), message]
            _LOGGER.warning("%s: %s", self.person, message)

    async def _fetch_quests(self, token: str, player: dict[str, Any]) -> None:
        """Refresh current quests and this person's earned status."""
        try:
            page = await self.client.quests_page(token)
            event_ids = parse_quest_event_ids(page)
            payloads = await asyncio.gather(
                *(self.client.quest_event(token, event_id) for event_id in event_ids)
            )
        except _ERRORS as err:
            _LOGGER.debug("Could not update quests: %s", err)
            return
        player["quests"] = [
            event for payload in payloads if (event := parse_quest_event(payload))
        ]

    async def _fetch_progress(self, token: str, player: dict[str, Any]) -> None:
        """Refresh games with progress pages and look for new ones."""
        progress: dict[str, Any] = dict(player.get("progress", {}))
        checked: dict[str, float] = dict(player.get("progress_checked", {}))
        now = dt_util.utcnow().timestamp()
        limit = asyncio.Semaphore(DETAIL_CONCURRENCY)

        async def load(game: dict[str, Any]) -> None:
            title_id = game["title_id"]
            async with limit:
                try:
                    page = await self.client.game_progress_page(token, title_id)
                    blocks = parse_game_progress(flight_text(page))
                except _ERRORS as err:
                    _LOGGER.debug("Progress failed for %s: %s", game["game"], err)
                    return
            checked[title_id] = now
            if blocks:
                progress[title_id] = blocks
            else:
                progress.pop(title_id, None)

        games = player.get("games", [])
        changed = set(player.get("changed_titles", []))
        await asyncio.gather(
            *(
                load(game)
                for game in games
                if game["title_id"] in progress
                or game["title_id"] in changed
                or now - checked.get(game["title_id"], 0) >= PROGRESS_RECHECK
            )
        )
        current = {game["title_id"] for game in games}
        player["progress"] = {k: v for k, v in progress.items() if k in current}
        player["progress_checked"] = {k: v for k, v in checked.items() if k in current}

    async def _fetch_machines(
        self, token: str, old: dict[str, Any]
    ) -> tuple[dict[str, Any], bool]:
        try:
            listed = parse_machines(await self.client.machines(token))
        except _ERRORS as err:
            _LOGGER.warning("%s: could not update machines: %s", self.person, err)
            return old, False

        owners: dict[str, str] = self.hass.data[DOMAIN]["machine_owners"]
        mine = [
            m
            for m in listed
            if owners.setdefault(m["id"], self.config_entry.entry_id)
            == self.config_entry.entry_id
        ]
        limit = asyncio.Semaphore(3)

        async def load(machine: dict[str, Any]) -> dict[str, Any]:
            previous = old.get(machine["id"], {}).get("scores", [])
            async with limit:
                try:
                    payload = await self.client.high_scores(token, machine["id"])
                    scores = parse_high_scores(payload, HIGH_SCORE_COUNT)
                except _ERRORS as err:
                    _LOGGER.debug("Scores failed for %s: %s", machine["name"], err)
                    scores = previous
            return {**machine, "scores": scores}

        loaded = await asyncio.gather(*(load(m) for m in mine))
        return {m["id"]: m for m in loaded}, True

    def _fire_events(self, old: dict[str, Any], new: dict[str, Any]) -> None:
        if not old:
            return
        before = {
            b["name"] for b in old["player"].get("badges", []) if b["earned"]
        }
        if before:
            for badge in new["player"].get("badges", []):
                if badge["earned"] and badge["name"] not in before:
                    self.hass.bus.async_fire(
                        EVENT_NEW_BADGE,
                        {
                            "person": self.person,
                            "badge": badge["name"],
                            "date": badge["date"],
                        },
                    )
        for machine_id, machine in new["machines"].items():
            previous = old["machines"].get(machine_id)
            if not previous:
                continue
            was = {s["rank"]: (s["score"], s["player_id"]) for s in previous["scores"]}
            for score in machine["scores"]:
                if was.get(score["rank"]) == (score["score"], score["player_id"]):
                    continue
                if (score["score"], score["player_id"]) in was.values():
                    continue  # Same score moved down the table.
                self.hass.bus.async_fire(
                    EVENT_NEW_HIGH_SCORE,
                    {
                        "machine_id": machine_id,
                        "machine_name": machine["name"],
                        "rank": score["rank"],
                        "score": score["score"],
                        "player_username": score["player_username"],
                        "player_initials": score["player_initials"],
                    },
                )

    async def _async_update_data(self) -> dict[str, Any]:
        old = self.data or {}
        token = await self._access_token()
        player = await self._fetch_player(token, old.get("player", {}))
        machines, machines_ok = await self._fetch_machines(
            token, old.get("machines", {})
        )
        if "profile" not in player and not machines_ok:
            raise UpdateFailed("Stern profile and machine data are unavailable")
        try:
            page = await self.client.games_page(token)
            player["catalog"] = parse_game_catalog(flight_text(page))
        except _ERRORS as err:
            _LOGGER.debug("Could not update the game list: %s", err)
        await self._fetch_quests(token, player)
        await self._fetch_details(token, player)
        await self._fetch_progress(token, player)
        new = {"player": player, "machines": machines}
        self._fire_events(old, new)
        return new
