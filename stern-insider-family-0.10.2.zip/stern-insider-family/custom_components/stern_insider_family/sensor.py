"""Sensors for players and machine high scores."""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from homeassistant.components.sensor import (
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.const import PERCENTAGE
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from . import SternConfigEntry
from .const import HIGH_SCORE_COUNT, RECENT_BADGES
from .coordinator import SternCoordinator
from .entity import SternMachineEntity, SternPlayerEntity

RANK_NAMES = {
    1: "Grand Champion",
    2: "High Score 1",
    3: "High Score 2",
    4: "High Score 3",
    5: "High Score 4",
}


def earned(player: dict[str, Any]) -> list[dict[str, Any]]:
    """Return earned badges, newest first."""
    badges = [b for b in player.get("badges", []) if b["earned"]]
    return sorted(badges, key=lambda b: b["date"] or "", reverse=True)


def collection(player: dict[str, Any]) -> list[dict[str, Any]]:
    """Return earned badges that are not milestone tiers."""
    return [b for b in earned(player) if b["milestone"] is None]


def overall_progress(player: dict[str, Any]) -> int | None:
    """Return achievement completion across all games."""
    games = player.get("games")
    if not games:
        return None
    total = sum(g["total"] for g in games)
    return round(sum(g["earned"] for g in games) / total * 100) if total else 0


@dataclass(frozen=True, kw_only=True)
class SternStat(SensorEntityDescription):
    """A numeric player statistic."""

    value: Callable[[dict[str, Any]], int | None]


def _stat(field: str) -> Callable[[dict[str, Any]], int | None]:
    return lambda player: player.get("profile", {}).get(field)


STATS = (
    SternStat(key="xp", name="Stern XP", icon="mdi:star-four-points", value=_stat("xp")),
    SternStat(key="plays", name="Plays", icon="mdi:gamepad-variant", value=_stat("plays")),
    SternStat(key="days_played", name="Days played", icon="mdi:calendar-check", value=_stat("days_played")),
    SternStat(key="day_streak", name="Day streak", icon="mdi:fire", value=_stat("day_streak")),
    SternStat(key="week_streak", name="Week streak", icon="mdi:calendar-week", value=_stat("week_streak")),
    SternStat(key="achievements", name="Achievements", icon="mdi:trophy-award", value=_stat("achievements")),
    SternStat(key="badges", name="Badges", icon="mdi:medal", value=lambda p: len(collection(p)) if "badges" in p else None),
    SternStat(key="milestone_badges", name="Milestone badges", icon="mdi:flag-checkered", value=lambda p: len(earned(p)) - len(collection(p)) if "badges" in p else None),
    SternStat(key="game_progress", name="Game progress", icon="mdi:progress-star", native_unit_of_measurement=PERCENTAGE, value=overall_progress),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: SternConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Add player sensors, and score sensors as machines appear."""
    coordinator = entry.runtime_data
    async_add_entities(
        [
            SternProfileSensor(coordinator),
            *(SternStatSensor(coordinator, stat) for stat in STATS),
        ]
    )
    known: set[str] = set()

    @callback
    def add_machines() -> None:
        new = set(coordinator.data["machines"]) - known
        known.update(new)
        if new:
            async_add_entities(
                SternHighScoreSensor(coordinator, machine_id, rank)
                for machine_id in new
                for rank in range(1, HIGH_SCORE_COUNT + 1)
            )

    add_machines()
    entry.async_on_unload(coordinator.async_add_listener(add_machines))


class SternStatSensor(SternPlayerEntity, SensorEntity):
    """One numeric player statistic."""

    _attr_state_class = SensorStateClass.MEASUREMENT
    entity_description: SternStat

    def __init__(self, coordinator: SternCoordinator, stat: SternStat) -> None:
        super().__init__(coordinator, stat.key)
        self.entity_description = stat

    @property
    def native_value(self) -> int | None:
        """Return the statistic."""
        return self.entity_description.value(self.player)


class SternProfileSensor(SternPlayerEntity, SensorEntity):
    """Connection state plus everything the dashboard shows for a person."""

    _attr_name = "Insider profile"
    _attr_icon = "mdi:account-star"
    _unrecorded_attributes = frozenset(
        {"avatar_url", "stats", "recent_badges", "tracks", "games", "problems"}
    )

    def __init__(self, coordinator: SternCoordinator) -> None:
        super().__init__(coordinator, "profile")

    @property
    def native_value(self) -> str:
        """Return connected, or partial when a page could not be read."""
        return "partial" if self.player.get("errors") else "connected"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return dashboard data. Contains no email, address or tokens."""
        player, profile = self.player, self.profile
        owned = collection(player)
        return {
            "kind": "player",
            "person": self.coordinator.person,
            "username": profile.get("username"),
            "initials": profile.get("initials"),
            "avatar_url": profile.get("avatar_url"),
            "stats": {
                key: profile.get(key)
                for key in (
                    "xp", "plays", "days_played", "day_streak", "best_day_streak",
                    "weeks_played", "week_streak", "achievements",
                )
            },
            "badge_count": len(owned),
            "milestone_badge_count": len(earned(player)) - len(owned),
            "recent_badges": [
                {k: b[k] for k in ("name", "date", "image")}
                for b in owned[:RECENT_BADGES]
            ],
            "tracks": player.get("tracks", []),
            "game_progress": overall_progress(player),
            "games": player.get("games", []),
            "problems": player.get("errors", []),
        }


class SternHighScoreSensor(SternMachineEntity, SensorEntity):
    """One leaderboard position on a machine."""

    _attr_icon = "mdi:trophy"
    _attr_state_class = SensorStateClass.MEASUREMENT
    _unrecorded_attributes = frozenset(
        {
            "avatar_url",
            "square_logo_url",
            "variable_width_logo_url",
            "backglass_image_url",
            "gradient_start",
            "gradient_stop",
        }
    )

    def __init__(
        self, coordinator: SternCoordinator, machine_id: str, rank: int
    ) -> None:
        super().__init__(coordinator, machine_id, f"high_score_{rank}")
        self.rank = rank
        self._attr_name = RANK_NAMES[rank]

    @property
    def score(self) -> dict[str, Any] | None:
        """Return the score at this rank."""
        scores = self.machine.get("scores", [])
        return next((s for s in scores if s["rank"] == self.rank), None)

    @property
    def native_value(self) -> int | None:
        """Return the score."""
        return self.score["score"] if self.score else None

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        """Return score and machine details."""
        attributes = {
            "kind": "high_score",
            "rank": self.rank,
            **self.machine_attributes(),
        }
        if score := self.score:
            attributes.update(
                player_username=score["player_username"],
                player_initials=score["player_initials"],
                avatar_url=score["avatar_url"],
            )
        return attributes
