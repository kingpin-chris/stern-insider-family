"""Shared entity helpers."""
from __future__ import annotations

from typing import Any

from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import SternCoordinator


class SternEntity(CoordinatorEntity[SternCoordinator]):
    """Base entity."""

    _attr_has_entity_name = True


class SternPlayerEntity(SternEntity):
    """Entity on a person's device."""

    def __init__(self, coordinator: SternCoordinator, key: str) -> None:
        super().__init__(coordinator)
        entry = coordinator.config_entry
        self._attr_unique_id = f"{entry.unique_id}_{key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"player_{entry.unique_id}")},
            name=f"{coordinator.person} Stern Insider",
            manufacturer="Stern Pinball",
            model="Insider Connected player",
        )

    @property
    def player(self) -> dict[str, Any]:
        """Current player data."""
        return (self.coordinator.data or {}).get("player", {})

    @property
    def profile(self) -> dict[str, Any]:
        """Current profile stats."""
        return self.player.get("profile", {})


class SternMachineEntity(SternEntity):
    """Entity on a pinball machine's device."""

    def __init__(
        self, coordinator: SternCoordinator, machine_id: str, key: str
    ) -> None:
        super().__init__(coordinator)
        self.machine_id = machine_id
        self._attr_unique_id = f"machine_{machine_id}_{key}"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, f"machine_{machine_id}")},
            name=self.machine.get("name"),
            manufacturer="Stern Pinball",
            model=self.machine.get("name"),
        )

    @property
    def machine(self) -> dict[str, Any]:
        """Current machine data."""
        return (self.coordinator.data or {}).get("machines", {}).get(self.machine_id, {})

    @property
    def available(self) -> bool:
        """Available while the machine is still listed."""
        return super().available and bool(self.machine)

    def machine_attributes(self) -> dict[str, Any]:
        """Attributes used by the dashboard."""
        machine = self.machine
        return {
            "machine_id": self.machine_id,
            "game_title": machine.get("name"),
            "square_logo_url": machine.get("square_logo_url"),
            "variable_width_logo_url": machine.get("variable_width_logo_url"),
            "backglass_image_url": machine.get("backglass_image_url"),
            "gradient_start": machine.get("gradient_start"),
            "gradient_stop": machine.get("gradient_stop"),
        }
