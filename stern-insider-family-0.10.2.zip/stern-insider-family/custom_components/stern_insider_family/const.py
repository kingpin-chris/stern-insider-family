"""Constants for Stern Insider Family."""

DOMAIN = "stern_insider_family"

PROJECT_ID = "P3HEU9eRz5zrjI8c28n88adIDzyI"
CLIENT_ID = PROJECT_ID
AUTH_BASE = "https://auth.sternpinball.com"
AUTHORIZE_URL = f"{AUTH_BASE}/oauth2/v1/{PROJECT_ID}/authorize"
TOKEN_URL = f"{AUTH_BASE}/oauth2/v1/{PROJECT_ID}/token"
INSIDER_BASE = "https://insider.sternpinball.com"
REDIRECT_URI = f"{INSIDER_BASE}/auth/callback"
CMS_BASE = "https://cms.prd.sternpinball.io/api/v1/portal"
API_BASE = "https://api.prd.sternpinball.io/api/v1/portal"
API_V2_BASE = "https://api.prd.sternpinball.io/api/v2/portal"
TOKEN_COOKIE = "spb-insider-token"
USER_AGENT = "HomeAssistant-SternInsiderFamily/0.1"

CONF_REFRESH_TOKEN = "refresh_token"
CONF_USER_ID = "user_id"
CONF_DISPLAY_NAME = "display_name"
CONF_CALLBACK_URL = "callback_url"
CONF_SCAN_HOURS = "scan_hours"

DEFAULT_SCAN_HOURS = 3
MIN_SCAN_HOURS = 1
MAX_SCAN_HOURS = 12  # Badge image links expire after about 20 hours.
HIGH_SCORE_COUNT = 5
RECENT_BADGES = 12
DETAIL_CONCURRENCY = 2
PROGRESS_RECHECK = 24 * 3600  # Look for newly available progress pages.
DETAIL_MAX_AGE = 11 * 3600  # Refresh image links before they expire.
CARD_FILE = "stern-achievements-card.js"
CARD_URL = f"/{DOMAIN}/{CARD_FILE}"
VERSION = "0.10.2"

SIGNAL_UPDATED = f"{DOMAIN}_updated"
EVENT_NEW_HIGH_SCORE = f"{DOMAIN}_new_high_score"
EVENT_NEW_BADGE = f"{DOMAIN}_new_badge"
