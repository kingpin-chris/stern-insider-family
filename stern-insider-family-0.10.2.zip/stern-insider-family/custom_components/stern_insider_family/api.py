"""Client for Stern's sign-in service, Insider pages and portal API."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import secrets
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse

import aiohttp

from .const import (
    API_BASE,
    API_V2_BASE,
    AUTHORIZE_URL,
    CLIENT_ID,
    CMS_BASE,
    INSIDER_BASE,
    REDIRECT_URI,
    TOKEN_COOKIE,
    TOKEN_URL,
    USER_AGENT,
)

_TIMEOUT = aiohttp.ClientTimeout(total=45)


class SternApiError(Exception):
    """Stern could not be reached or answered unexpectedly."""


class SternAuthError(SternApiError):
    """The sign-in is no longer valid."""


class CallbackError(ValueError):
    """The pasted address is not a usable sign-in result."""


@dataclass(frozen=True)
class Tokens:
    """Tokens returned by Stern's sign-in service."""

    access_token: str
    refresh_token: str


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def new_pkce() -> tuple[str, str, str]:
    """Return verifier, challenge and state for one sign-in."""
    verifier = _b64(secrets.token_bytes(48))
    challenge = _b64(hashlib.sha256(verifier.encode()).digest())
    return verifier, challenge, _b64(secrets.token_bytes(16))


def authorize_url(challenge: str, state: str) -> str:
    """Build the link a person opens to sign in."""
    query = urlencode(
        {
            "client_id": CLIENT_ID,
            "redirect_uri": REDIRECT_URI,
            "response_type": "code",
            "scope": "openid",
            "state": state,
            "code_challenge": challenge,
            "code_challenge_method": "S256",
        }
    )
    return f"{AUTHORIZE_URL}?{query}"


def code_from_callback(url: str, expected_state: str) -> str:
    """Validate the pasted address and return its one-time code."""
    parsed = urlparse(url.strip())
    if parsed.scheme != "https" or parsed.netloc != urlparse(REDIRECT_URI).netloc:
        raise CallbackError("invalid_url")
    if parsed.path != urlparse(REDIRECT_URI).path:
        raise CallbackError("invalid_url")
    query = parse_qs(parsed.query)
    if query.get("state", [None])[0] != expected_state:
        raise CallbackError("state_mismatch")
    code = query.get("code", [None])[0]
    if not code:
        raise CallbackError("invalid_url")
    return code


def token_subject(access_token: str) -> str | None:
    """Read the stable account id from a token received over TLS."""
    try:
        payload = access_token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload)).get("sub")
    except (IndexError, ValueError, AttributeError):
        return None


class SternClient:
    """Small async client. It never logs tokens or page contents."""

    def __init__(self, session: aiohttp.ClientSession) -> None:
        self._session = session

    async def _token(self, form: dict[str, str]) -> Tokens:
        try:
            async with self._session.post(
                TOKEN_URL,
                data={"client_id": CLIENT_ID, **form},
                headers={"User-Agent": USER_AGENT},
                timeout=_TIMEOUT,
            ) as resp:
                data = await resp.json(content_type=None)
                status = resp.status
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as err:
            raise SternApiError("sign-in service unavailable") from err
        if status in (400, 401, 403):
            raise SternAuthError(str((data or {}).get("error") or status))
        if status != 200 or not data.get("access_token") or not data.get("refresh_token"):
            raise SternApiError(f"sign-in service returned {status}")
        return Tokens(data["access_token"], data["refresh_token"])

    async def exchange_code(self, code: str, verifier: str) -> Tokens:
        """Exchange a one-time code for tokens."""
        return await self._token(
            {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
                "code_verifier": verifier,
            }
        )

    async def refresh(self, refresh_token: str) -> Tokens:
        """Get new tokens. Stern replaces the refresh token every time."""
        return await self._token(
            {"grant_type": "refresh_token", "refresh_token": refresh_token}
        )

    async def _page(self, path: str, token: str) -> str:
        headers = {"Cookie": f"{TOKEN_COOKIE}={token}", "User-Agent": USER_AGENT}
        try:
            async with self._session.get(
                f"{INSIDER_BASE}{path}",
                headers=headers,
                allow_redirects=False,
                timeout=_TIMEOUT,
            ) as resp:
                if resp.status != 200:
                    raise SternApiError(f"{path} returned {resp.status}")
                return await resp.text()
        except (aiohttp.ClientError, asyncio.TimeoutError) as err:
            raise SternApiError(f"{path} unavailable") from err

    async def badges_page(self, token: str) -> str:
        """Fetch page data containing profile stats and badges."""
        return await self._page("/trophy-room/badges", token)

    async def achievements_page(self, token: str) -> str:
        """Fetch the rendered per-game achievements page."""
        return await self._page("/trophy-room/achievements", token)

    async def game_achievements_page(self, token: str, title_id: str) -> str:
        """Fetch every achievement for one game."""
        if not title_id.isdigit():
            raise SternApiError("invalid game id")
        return await self._page(f"/trophy-room/achievements/{title_id}", token)

    async def games_page(self, token: str) -> str:
        """Fetch Stern's list of Insider Connected games."""
        return await self._page("/games", token)

    async def game_progress_page(self, token: str, title_id: str) -> str:
        """Fetch one game's progress page."""
        if not title_id.isdigit():
            raise SternApiError("invalid game id")
        return await self._page(f"/trophy-room/games/progress/{title_id}", token)

    async def quests_page(self, token: str) -> str:
        """Fetch the page listing current quests."""
        return await self._page("/playnow/quests", token)

    async def quest_event(self, token: str, event_id: str) -> dict[str, Any]:
        """Fetch a quest event with this account's earned status."""
        if not event_id.isdigit():
            raise SternApiError("invalid event id")
        return await self._json(f"{API_BASE}/events/{event_id}/", token)

    async def user_detail(self, token: str) -> dict[str, Any]:
        """Fetch account details used to find the player's avatar."""
        return await self._json(f"{API_V2_BASE}/user_detail/", token)

    async def _cms(self, path: str, token: str) -> dict[str, Any]:
        return await self._json(f"{CMS_BASE}/{path}", token)

    async def _json(self, url: str, token: str) -> dict[str, Any]:
        try:
            async with self._session.get(
                url,
                headers={"Authorization": f"Bearer {token}", "User-Agent": USER_AGENT},
                timeout=_TIMEOUT,
            ) as resp:
                if resp.status in (401, 403):
                    raise SternApiError(f"portal API refused access ({resp.status})")
                if resp.status != 200:
                    raise SternApiError(f"portal API returned {resp.status}")
                return await resp.json(content_type=None)
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as err:
            raise SternApiError("portal API unavailable") from err

    async def machines(self, token: str) -> dict[str, Any]:
        """Fetch machines registered to the account."""
        return await self._cms("user_registered_machines/?group_type=home", token)

    async def high_scores(self, token: str, machine_id: str) -> dict[str, Any]:
        """Fetch a machine's leaderboard."""
        return await self._cms(
            f"game_machine_high_scores/?machine_id={machine_id}", token
        )
